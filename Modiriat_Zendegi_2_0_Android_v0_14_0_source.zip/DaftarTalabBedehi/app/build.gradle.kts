plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.kambiz.daftar"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.kambiz.daftar"
        minSdk = 23
        targetSdk = 35
        versionCode = 23
        versionName = "0.14.0"
    }
}
