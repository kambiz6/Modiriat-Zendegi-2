# Build Guide — Management Life 2.0 (SOURCE-31-TEST)

## Build identity

- Android applicationId: `ir.modiriyatzendegi.test`
- Main applicationId reserved separately: `ir.modiriyatzendegi.app`
- Display name: `مدیریت زندگی آزمایشی`
- Version name/code: `1.0.0` / `82`
- Database schema version: `18`
- The distinct applicationId gives Android a separate app identity and private data directory. This source does not merge or share a database with the main app.

## Toolchain

- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android Gradle Plugin 8.6.1
- Kotlin Android plugin 2.0.20
- Gradle 8.7

## SQLCipher and database migration

The source includes SQLCipher for Android 4.20.0, a 256-bit database key protected by AES-GCM with Android Keystore, one-way legacy SQLite migration, and encrypted backup/restore integration. SOURCE-31-TEST adds row-content fingerprints, AUTOINCREMENT sequence preservation, WAL checkpoint gating, a crash-recovery restore journal, and bounded ZIP extraction. These are source-level implementation facts, not device-test proof. Android build, migration on a copy of a real version-18 database, Keystore failure behavior, rollback, and second-device restore must pass before using the test app with important data.

## GitHub Actions

The workflow is `.github/workflows/build-apk.yml`. It builds a debug APK for the test application only, verifies the APK's actual applicationId/versionName/versionCode using `aapt`, and applies the canonical filename:

`Modiriat-Zendegi_ir.modiriyatzendegi.test_v1.0.0_build82_debug.apk`

The artifact is named `management-life-2-SOURCE-31-TEST-v1.0.0-debug-apk`. No repository operation has been performed here.

## Local build

```bash
./tools/run_source_checks.sh
gradle --no-daemon clean assembleDebug
```

This package does not include Gradle Wrapper files.

## Remaining acceptance gates

- Run Gradle Sync and `assembleDebug` with JDK 17 and Android SDK 35.
- Install on API 23+ and a recent Android device.
- Migrate a copy of a version-18 plaintext database; compare schema, row fingerprints, row counts, sqlite_sequence, integrity and foreign keys.
- Verify the live `ledger.db` cannot be opened by ordinary SQLite and opens only with SQLCipher and the correct key.
- Test missing/wrong Keystore key, process interruption, low storage and rollback.
- Test encrypted backup and restore on a second device with correct and incorrect passwords, including the legacy backup import path.
- Complete functional acceptance of all 14 requirements.

This is a test-source package, not a release build. Do not treat source-level PASS results as proof of production-ready security.


SOURCE-31-TEST also adds the V44 master-reference copy of the complete 14-item product addendum, a detailed Kotlin traceability registry, and acceptance/test mapping. The 14 product features remain PARTIAL until each criterion passes its required runtime acceptance.
