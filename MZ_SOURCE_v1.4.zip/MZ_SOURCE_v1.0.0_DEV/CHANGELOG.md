## SOURCE-31-TEST — V44 master-reference integration for 14 product requirements (1.0.0 / code 82)
- Based on SOURCE-30-TEST; the previous source package remains unchanged.
- Added the complete historical 14-requirement addendum with an explicit current-master reference to `MZ_MASTER_v44.txt`; the original V39 addendum identity and content remain preserved.
- Added detailed Kotlin traceability for all 14 requirements: owner branch/data ownership, functional scope, dependencies, security controls, acceptance criteria, test references and known gaps.
- Added a source-level traceability matrix mapping each requirement to existing code entry points and remaining acceptance work.
- Added Python and Kotlin/JVM regression checks for all 14 requirement records and their document lineage.
- 21 Python and 9 standalone Kotlin/JVM tests passed; SQLCipher static checks passed 22/22. Android build and device validation remain pending.
- All 14 functional requirements remain `PARTIAL`; this release integrates detailed specifications and traceability, not full runtime feature completion.

## SOURCE-30-TEST — SQLCipher migration hardening and APK workflow (1.0.0 / code 82)
- Based on SOURCE-29-TEST; the previous source package remains unchanged.
- Audited the SQLCipher/Android Keystore integration already present in SOURCE-29-TEST and corrected stale readiness documentation.
- Added typed row-content SHA-256 fingerprints and sqlite_sequence preservation/verification to legacy database migration.
- Added a durable restore journal that snapshots the previous encrypted database and wrapped key, rolls back interrupted restores at next startup, and commits only after validation.
- Added WAL checkpoint gating and best-effort cleanup of temporary key copies.
- Bounded backup archive and ZIP entry sizes, rejected duplicate/unknown entries and cleared decrypted payload buffers.
- Updated GitHub Actions to run the consolidated source checks, compare source metadata with Gradle, verify APK metadata with aapt and name the APK from actual app identity/version/build type.
- 20 Python and 8 standalone Kotlin/JVM tests passed; Android build and device validation remain pending.

## SOURCE-29-TEST — independent test application identity (1.0.0 / code 82)
- Created a separate working copy based on SOURCE-28; the base source remains untouched.
- Assigned test applicationId `ir.modiriyatzendegi.test` and display name `مدیریت زندگی آزمایشی`.
- Kept the main applicationId `ir.modiriyatzendegi.app` reserved and separate.
- Added source identity checks and a debug-only GitHub Actions build workflow.
- APK was not built in the preparation environment; Android runtime and final acceptance remain pending.

## SOURCE-28 — engineering/package preparation (app 0.23.48 / versionCode 80)
- Prepared an independent engineering source package and retained the previous source.
- See `CHANGELOG_SOURCE_28_FA.txt` for the detailed source history.

## SOURCE-28 UI Appearance Stage — app 0.23.49 / versionCode 81
- Added the appearance profile and schedule work while preserving the previous source baseline.
