مدیریت زندگی ۲.۰ — راهنمای ساخت APK در GitHub Actions
شناسه سورس: SOURCE-31-TEST
نسخه برنامه: 1.0.0 | versionCode: 82 | پایگاه داده: 18

۱) بارگذاری سورس
- ZIP را استخراج کنید؛ ریشه مخزن باید مستقیماً شامل settings.gradle.kts، build.gradle.kts، app/، tools/ و .github/ باشد.
- یک مخزن GitHub بسازید؛ برای سورس شخصی، مخزن Private انتخاب امن‌تری است.
- شاخه‌های ثابت پروژه را حفظ کنید: main برای مرجع پایدار و build-new-apk برای ساخت و آزمون.
- این بسته را فقط روی build-new-apk قرار دهید. هیچ تغییری در main بدون تأیید صریح انجام نشود.

۲) اجرای ساخت
- در GitHub وارد تب Actions شوید و workflow با نام Build Android APK را انتخاب کنید.
- Run workflow را روی شاخه build-new-apk اجرا کنید؛ push تغییرات کد به همین شاخه نیز workflow را اجرا می‌کند.
- workflow از JDK 17، Android SDK Platform 35، Build Tools 35.0.0 و Gradle 8.7 استفاده می‌کند.
- ابتدا مجموعه آزمون‌های منبع و ممیزی‌ها اجرا می‌شوند؛ سپس assembleDebug.
- پس از ساخت، applicationId و versionName و versionCode داخل APK با aapt بررسی می‌شوند.

۳) دریافت APK
- پس از موفقیت job، همان اجرای workflow را باز کنید و از بخش Artifacts فایل زیر را دریافت کنید:
  `management-life-2-SOURCE-31-TEST-v1.0.0-debug-apk`
- نام APK درون artifact:
  `Modiriat-Zendegi_ir.modiriyatzendegi.test_v1.0.0_build82_debug.apk`
- فایل BUILD_OUTPUT_INFO.txt شناسه commit، مشخصات build و SHA-256 خروجی را ثبت می‌کند.

۴) محدودیت‌های مهم
- workflow فقط APK آزمایشی Debug می‌سازد؛ Release APK و امضای انتشار نهایی تنظیم نشده است.
- موفقیت ساخت APK به معنی تأیید نصب، عملکرد کامل ۱۴ قابلیت یا پذیرش امنیتی روی دستگاه نیست.
- سورس شامل SQLCipher و Android Keystore است، اما مهاجرت واقعی، خطاهای Keystore و بازیابی روی دستگاه دوم باید عملاً آزمایش شوند.
- قبل از نصب روی گوشی دارای اطلاعات واقعی، پشتیبان مستقل بگیرید و ابتدا با داده آزمایشی کار کنید.
- کلید امضای Release، رمزها، توکن‌ها، دیتابیس واقعی، پشتیبان شخصی و local.properties را به GitHub اضافه نکنید.

۵) ساخت محلی
پیش‌نیاز: JDK 17، Android SDK Platform 35، Build Tools 35.0.0 و Gradle 8.7.

    ./tools/run_source_checks.sh
    gradle --no-daemon clean assembleDebug

در این بسته Gradle Wrapper قرار ندارد.
