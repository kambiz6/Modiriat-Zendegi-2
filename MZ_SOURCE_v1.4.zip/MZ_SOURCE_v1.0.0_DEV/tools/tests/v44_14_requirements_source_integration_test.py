from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
master_spec = ROOT / "APP_REQUIREMENTS_14_MASTER_V44_FA.txt"
trace = ROOT / "APP_REQUIREMENTS_14_V44_TRACEABILITY_FA.md"
registry = ROOT / "app/src/main/java/ir/kambiz/daftar/ProductRequirementsV39.kt"
source_version = (ROOT / "SOURCE_VERSION.txt").read_text(encoding="utf-8")
assert master_spec.is_file() and trace.is_file() and registry.is_file()
master_text = master_spec.read_text(encoding="utf-8")
trace_text = trace.read_text(encoding="utf-8")
registry_text = registry.read_text(encoding="utf-8")
for token in ["MZ_MASTER_v44.txt", "MZ-ADDENDUM-14-APP-NEEDS-001", "۳-۱.", "۳-۱۱.", "۴. قواعد مشترک", "۵. قواعد جدید شیوه همکاری", "۶. وضعیت"]:
    assert token in master_text, f"missing full approved requirement content: {token}"
for app_id in [f"APP-{i:02d}" for i in range(1,15)]:
    assert app_id in registry_text and app_id in trace_text, f"missing traceability for {app_id}"
assert 'MASTER_VERSION = "v44"' in registry_text
assert 'ADDENDUM_ORIGIN_VERSION = "v39"' in registry_text
assert "SOURCE_ID=SOURCE-31-TEST" in source_version
print("V44 14-requirement source integration audit: PASS (full master appendix, 14 detailed records, source lineage)")
