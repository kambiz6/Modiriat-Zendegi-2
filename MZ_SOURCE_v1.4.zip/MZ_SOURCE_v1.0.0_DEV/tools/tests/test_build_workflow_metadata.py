#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
version = (ROOT / "SOURCE_VERSION.txt").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/build-apk.yml").read_text(encoding="utf-8")

checks = {
    "source generation is SOURCE-31-TEST": "SOURCE_ID=SOURCE-31-TEST" in version,
    "source base is SOURCE-30-TEST": "BASE_SOURCE=SOURCE-30-TEST" in version,
    "test application ID matches Gradle": 'APP_ID=ir.modiriyatzendegi.test' in version and 'applicationId = "ir.modiriyatzendegi.test"' in gradle,
    "versionName matches Gradle": 'APP_VERSION_NAME=1.0.0' in version and 'versionName = "1.0.0"' in gradle,
    "versionCode matches Gradle": 'APP_VERSION_CODE=82' in version and 'versionCode = 82' in gradle,
    "database version matches source metadata": 'DATABASE_VERSION=18' in version and 'const val DATABASE_VERSION = 18' in (ROOT / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt").read_text(encoding="utf-8"),
    "workflow runs consolidated source tests": 'bash tools/run_source_checks.sh' in workflow,
    "workflow verifies actual APK package/version metadata": 'aapt" dump badging' in workflow and 'versionCode=' in workflow and 'versionName=' in workflow,
    "workflow names APK with app id, version, code and build type": 'Modiriat-Zendegi_${app_id}_v${version_name}_build${version_code}_debug.apk' in workflow,
    "workflow artifact identifies current source generation": 'management-life-2-SOURCE-31-TEST-v1.0.0-debug-apk' in workflow,
}
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {label}")
failed = [label for label, ok in checks.items() if not ok]
print(f"Build workflow metadata test: {'PASS' if not failed else 'FAIL'} ({len(checks)-len(failed)}/{len(checks)})")
raise SystemExit(1 if failed else 0)
