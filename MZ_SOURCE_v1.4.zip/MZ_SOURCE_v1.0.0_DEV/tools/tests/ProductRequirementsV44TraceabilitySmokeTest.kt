package ir.kambiz.daftar

fun main() {
    check(ProductRequirementsV39.MASTER_VERSION == "v44")
    check(ProductRequirementsV39.ADDENDUM_ORIGIN_VERSION == "v39")
    check(ProductRequirementsV39.SOURCE_ADDENDUM_ID == "MZ-ADDENDUM-14-APP-NEEDS-001")
    check(ProductRequirementsV39.all.size == 14)
    check(ProductRequirementsV39.hasUniqueIds())
    check(ProductRequirementsV39.hasCompleteTraceability())
    check(ProductRequirementsV39.all.all { it.implementationState == "PARTIAL" })
    check(ProductRequirementsV39.find("APP-05")!!.ownerBranches == listOf(1,18,22))
    check(ProductRequirementsV39.find("APP-14")!!.securityControls.any { it.contains("تأیید") })
    check(ProductRequirementsV39.find("APP-03")!!.acceptanceCriteria.any { it.contains("تراکنش") })
    println("ProductRequirementsV44TraceabilitySmokeTest: PASS (14 requirements, detailed traceability, master/addendum lineage)")
}
