#!/usr/bin/env python3
"""Static regression gate for the SQLCipher/Android Keystore integration.

This does not replace Android runtime, migration, or device testing.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAIN = (ROOT / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt").read_text(encoding="utf-8")
SECURITY = (ROOT / "app/src/main/java/ir/kambiz/daftar/DatabaseSecurity.kt").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
BACKUP_CRYPTO = (ROOT / "app/src/main/java/ir/kambiz/daftar/BackupCrypto.kt").read_text(encoding="utf-8")

checks = {
    "SQLCipher Android dependency and AndroidX SQLite dependency are pinned":
        'net.zetetic:sqlcipher-android:4.20.0@aar' in GRADLE and 'androidx.sqlite:sqlite:2.7.0' in GRADLE,
    "application database helper is SQLCipher, not framework SQLite":
        'import net.zetetic.database.sqlcipher.SQLiteOpenHelper' in MAIN and
        'SQLiteOpenHelper(ctx, "ledger.db", databaseKey' in MAIN,
    "native SQLCipher library is loaded before helper construction and migration":
        'constructor(ctx: Context) : this(ctx, loadDatabaseKey(ctx))' in MAIN and
        'private fun loadDatabaseKey(ctx: Context): ByteArray' in MAIN and
        'System.loadLibrary("sqlcipher")' in MAIN and 'LegacyDatabaseMigrator.migrateIfNeeded(ctx, databaseKey)' in MAIN,
    "database key is random 256-bit material":
        'ByteArray(32).also { SecureRandom().nextBytes(it) }' in SECURITY,
    "database key is wrapped with AES-GCM and Android Keystore":
        'KeyStore.getInstance("AndroidKeyStore")' in SECURITY and
        'Cipher.getInstance("AES/GCM/NoPadding")' in SECURITY and
        'GCMParameterSpec(GCM_TAG_BITS' in SECURITY,
    "encrypted database with missing key fails closed":
        'if (live.exists() && isSqlCipherFile(live))' in SECURITY and
        'هیچ پایگاه تازه‌ای ساخته نشد' in SECURITY,
    "legacy conversion is isolated to framework SQLite source reader":
        'AndroidSQLiteDatabase.openDatabase' in SECURITY and
        'TempCipherHelper' in SECURITY and
        'Os.rename(candidate.absolutePath, live.absolutePath)' in SECURITY,
    "migration validates row counts and typed content fingerprints":
        'sourceCounts == targetCounts' in SECURITY and
        'tableFingerprints(source) == tableFingerprints(target)' in SECURITY,
    "migration preserves AUTOINCREMENT sequence values":
        'copySqliteSequence(source, target)' in SECURITY and
        'sqliteSequence(source) == sqliteSequence(target)' in SECURITY,
    "migration validates integrity and foreign keys":
        'PRAGMA integrity_check' in SECURITY and 'PRAGMA foreign_key_check' in SECURITY,
    "migration retains encrypted emergency copy before atomic replacement":
        'encryptEmergencyCopy(live, emergency)' in SECURITY and
        'Os.rename(candidate.absolutePath, live.absolutePath)' in SECURITY,
    "backup exports SQLCipher database and password-protected key envelope":
        '"format_version",2' in MAIN and '"db_key.enc"' in MAIN and
        'BackupCrypto.encrypt(backupKey,keyPassword)' in MAIN,
    "backup inspection opens v2 database with SQLCipher key":
        'SQLiteDatabase.openDatabase(dbFile.absolutePath,packageDbKey!!' in MAIN,
    "restore replaces key and database inside a durable recovery journal":
        'DatabaseKeyStore.beginRestore(this)' in MAIN and 'DatabaseKeyStore.replace(this,restoreKey)' in MAIN and
        'DatabaseKeyStore.commitRestore(this)' in MAIN,
    "pending restore journal is recovered before the database key is opened":
        'recoverPendingRestore(context)' in SECURITY and 'fun rollbackRestore(context: Context)' in SECURITY,
    "restore journal snapshots the previous encrypted database and wrapped key":
        'database.before' in SECURITY and 'key.before' in SECURITY and 'status", "pending"' in SECURITY,
    "restore has a committed marker to make crash recovery idempotent":
        'status", "committed"' in SECURITY and '"committed" ->' in SECURITY,
    "restore opens the candidate with the supplied key without triggering rollback":
        'LedgerDb.openForRestore(this,restoreDatabaseKey)' in MAIN and 'fun openForRestore(ctx: Context, key: ByteArray)' in MAIN,
    "restore and migration require a successful WAL checkpoint and remove stale sidecars":
        'checkpoint.getInt(0)!=0' in MAIN and 'wal.exists() && !wal.delete()' in SECURITY and 'shm.exists() && !shm.delete()' in SECURITY,
    "backup export also requires complete WAL checkpoint and removes sidecars":
        'تثبیت کامل WAL پیش از پشتیبان‌گیری ناموفق بود' in MAIN and 'sidecar.exists()&&!sidecar.delete()' in MAIN,
    "backup import and export enforce archive and per-entry size limits":
        'readBackupBytesBounded(input,512L*1024*1024+64L)' in MAIN and 'copyBackupEntryBounded(zip,it,entryLimit)' in MAIN and 'temp.length()>512L*1024*1024' in MAIN,
    "backup crypto clears PBKDF2 output and password spec on a best-effort basis":
        'bytes.fill(0)' in BACKUP_CRYPTO and 'spec.clearPassword()' in BACKUP_CRYPTO and 'JCA provider internals cannot be explicitly zeroed' in BACKUP_CRYPTO,
}

failed = []
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'} | {label}")
    if not ok:
        failed.append(label)

print(f"SQLCipher static regression test: {'PASS' if not failed else 'FAIL'} ({len(checks)-len(failed)}/{len(checks)})")
raise SystemExit(1 if failed else 0)
