#!/usr/bin/env bash
# Reproducible source-level regression suite for the standalone test app.
# This does not build or install the Android application.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

printf '%s\n' '=== Management Life 2.0 — source checks ==='
printf 'Source: '; grep '^SOURCE_ID=' SOURCE_VERSION.txt

python_count=0
for test in tools/tests/*.py; do
  printf '\n===== PYTHON: %s =====\n' "$test"
  python3 "$test"
  python_count=$((python_count + 1))
done
printf '\nPYTHON_RESULT=PASS\nPYTHON_TEST_COUNT=%s\n' "$python_count"

printf '\n===== BANK ACCESS INVENTORY =====\n'
python3 tools/audits/bank_sensitive_access_inventory.py

kotlin_count=0
if command -v kotlinc >/dev/null 2>&1 && command -v kotlin >/dev/null 2>&1; then
  kotlin_jar="${TMPDIR:-/tmp}/mz-source-kotlin-smoke-tests.jar"
  kotlin_sources=(
    app/src/main/java/ir/kambiz/daftar/A024Automation.kt
    app/src/main/java/ir/kambiz/daftar/AppearanceProfileRules.kt
    app/src/main/java/ir/kambiz/daftar/AppearanceReset.kt
    app/src/main/java/ir/kambiz/daftar/AppearanceSchedule.kt
    app/src/main/java/ir/kambiz/daftar/BackupCrypto.kt
    app/src/main/java/ir/kambiz/daftar/CsvSafety.kt
    app/src/main/java/ir/kambiz/daftar/JalaliCalendarRules.kt
    app/src/main/java/ir/kambiz/daftar/MZFeatureRules.kt
    app/src/main/java/ir/kambiz/daftar/ProductRequirementsV39.kt
    tools/tests/A024AutomationSmokeTest.kt
    tools/tests/AppearanceProfileRulesSmokeTest.kt
    tools/tests/AppearanceResetSmokeTest.kt
    tools/tests/AppearanceScheduleSmokeTest.kt
    tools/tests/BackupCryptoSmokeTest.kt
    tools/tests/CsvSafetySmokeTest.kt
    tools/tests/JalaliCalendarRulesSmokeTest.kt
    tools/tests/MZFeatureRulesSmokeTest.kt
    tools/tests/ProductRequirementsV44TraceabilitySmokeTest.kt
  )
  printf '\n===== KOTLIN/JVM: compiling standalone rule tests =====\n'
  kotlinc "${kotlin_sources[@]}" -d "$kotlin_jar"
  for test_class in \
    A024AutomationSmokeTestKt \
    AppearanceProfileRulesSmokeTestKt \
    AppearanceResetSmokeTestKt \
    AppearanceScheduleSmokeTestKt \
    CsvSafetySmokeTestKt \
    JalaliCalendarRulesSmokeTestKt \
    MZFeatureRulesSmokeTestKt \
    ProductRequirementsV44TraceabilitySmokeTestKt; do
      printf '\n===== KOTLIN/JVM: %s =====\n' "$test_class"
      kotlin -classpath "$kotlin_jar" "ir.kambiz.daftar.$test_class"
      kotlin_count=$((kotlin_count + 1))
  done
  # Always run the backup cryptography regression: it is part of the security gate,
  # not an optional performance test. This remains a JVM test, not Android Keystore.
  printf '\n===== KOTLIN/JVM: BackupCryptoSmokeTestKt (PBKDF2/AES-GCM regression) =====\n'
  kotlin -classpath "$kotlin_jar" ir.kambiz.daftar.BackupCryptoSmokeTestKt
  kotlin_count=$((kotlin_count + 1))
  printf '\nKOTLIN_RESULT=PASS\nKOTLIN_TEST_COUNT=%s\n' "$kotlin_count"
else
  printf '\nKOTLIN_RESULT=SKIPPED (kotlinc and kotlin are required)\n'
fi

printf '\n===== ENCRYPTION READINESS (KNOWN RELEASE GATE) =====\n'
python3 tools/audits/bank_encryption_readiness_audit.py || true

printf '\n=== SOURCE CHECK SUMMARY ===\n'
printf 'PYTHON_TEST_COUNT=%s\nKOTLIN_TEST_COUNT=%s\n' "$python_count" "$kotlin_count"
printf '%s\n' 'ANDROID_BUILD=NOT_RUN_BY_THIS_SCRIPT' 'DEVICE_TEST=NOT_RUN_BY_THIS_SCRIPT'
printf '%s\n' 'NOTE=JVM backup crypto tests do not prove Android Keystore or SQLCipher database encryption'
