#!/usr/bin/env python3
"""Static readiness audit for SQLCipher/Android Keystore integration.

Static source evidence is deliberately separated from runtime proof.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAIN = (ROOT / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt").read_text(encoding="utf-8")
SECURITY_PATH = ROOT / "app/src/main/java/ir/kambiz/daftar/DatabaseSecurity.kt"
SECURITY = SECURITY_PATH.read_text(encoding="utf-8") if SECURITY_PATH.exists() else ""
GRADLE = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")

checks = [
    ("SQLCipher dependency is pinned", 'net.zetetic:sqlcipher-android:4.20.0@aar' in GRADLE),
    ("database helper uses SQLCipher", 'import net.zetetic.database.sqlcipher.SQLiteOpenHelper' in MAIN),
    ("SQLCipher native library is explicitly loaded", 'System.loadLibrary("sqlcipher")' in MAIN),
    ("database key uses Android Keystore AES-GCM wrapping", 'AndroidKeyStore' in SECURITY and 'AES/GCM/NoPadding' in SECURITY),
    ("legacy plaintext migration is fail-closed", 'مهاجرت امن پایگاه داده انجام نشد' in SECURITY and 'هیچ پایگاه تازه‌ای ساخته نشد' in SECURITY),
    ("migration checks integrity, foreign keys, row counts and content fingerprints", all(x in SECURITY for x in ('PRAGMA integrity_check', 'PRAGMA foreign_key_check', 'sourceCounts == targetCounts', 'tableFingerprints(source) == tableFingerprints(target)'))),
    ("backup includes SQLCipher database key envelope", '"db_key.enc"' in MAIN and 'BackupCrypto.encrypt(backupKey,keyPassword)' in MAIN),
    ("restore validates SQLCipher backup and supports crash-recovery journal", 'SQLiteDatabase.openDatabase(dbFile.absolutePath,packageDbKey!!' in MAIN and 'DatabaseKeyStore.beginRestore(this)' in MAIN and 'DatabaseKeyStore.commitRestore(this)' in MAIN and 'recoverPendingRestore(context)' in SECURITY),
    ("backup export checkpoints WAL and enforces bounded archive sizes", 'تثبیت کامل WAL پیش از پشتیبان‌گیری ناموفق بود' in MAIN and 'temp.length()>512L*1024*1024' in MAIN),
    ("framework SQLite use is confined to the explicit legacy-backup validation path", MAIN.count('android.database.sqlite.SQLiteDatabase.openDatabase') == 1 and 'else android.database.sqlite.SQLiteDatabase.openDatabase' in MAIN and 'AndroidSQLiteDatabase.openDatabase' in SECURITY),
]

for label, passed in checks:
    print(("PASS" if passed else "BLOCKER") + " | " + label)

missing = [label for label, passed in checks if not passed]
print("REVIEW | Android Gradle build, runtime migration, Keystore behavior and device restore tests are not proven by static inspection")
print("REVIEW | App-private backup staging, restore-journal crash recovery and emergency-copy recovery path require device-level validation")
if missing:
    print(f"READINESS: BLOCKED ({len(missing)} source integration checks failed)")
else:
    print("READINESS: SOURCE_INTEGRATION_PRESENT; RUNTIME_ACCEPTANCE_PENDING")
