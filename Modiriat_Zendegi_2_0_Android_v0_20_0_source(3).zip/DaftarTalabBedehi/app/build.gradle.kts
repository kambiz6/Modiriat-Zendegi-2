plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.kambiz.daftar"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.kambiz.daftar"
        minSdk = 23
        targetSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
        versionCode = 29
        versionName = "0.20.0"
    }
}
