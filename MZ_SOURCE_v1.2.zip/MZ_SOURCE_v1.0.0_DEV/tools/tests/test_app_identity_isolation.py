#!/usr/bin/env python3
"""Guard the test app identity and storage isolation contract."""
from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[2]
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
strings = (ROOT / "app/src/main/res/values/strings.xml").read_text(encoding="utf-8")
version = (ROOT / "SOURCE_VERSION.txt").read_text(encoding="utf-8")
checks = {
    "test applicationId is isolated": 'applicationId = "ir.modiriyatzendegi.test"' in gradle,
    "main applicationId is not reused": 'applicationId = "ir.modiriyatzendegi.app"' not in gradle,
    "app label is test-specific": '<string name="app_name">مدیریت زندگی آزمایشی</string>' in strings,
    "manifest uses test-specific resource label": 'android:label="@string/app_name"' in manifest,
    "Android backup is disabled by default": 'android:allowBackup="false"' in manifest,
    "version metadata records test package": 'APP_ID=ir.modiriyatzendegi.test' in version,
    "main package identity is recorded separately": 'MAIN_APP_ID=ir.modiriyatzendegi.app' in version,
    "version name is consistent": 'versionName = "1.0.0"' in gradle and 'APP_VERSION_NAME=1.0.0' in version,
    "version code is consistent": 'versionCode = 82' in gradle and 'APP_VERSION_CODE=82' in version,
    "database version metadata is present": 'DATABASE_VERSION=18' in version,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + name)
if not all(checks.values()):
    sys.exit(1)
print("TEST APP IDENTITY ISOLATION PASS")
