#!/usr/bin/env python3
"""Ensure the canonical source check runner includes all mandatory JVM tests."""
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[2]
runner = (root / "tools/run_source_checks.sh").read_text(encoding="utf-8")
required = [
    "A024AutomationSmokeTestKt",
    "AppearanceProfileRulesSmokeTestKt",
    "AppearanceResetSmokeTestKt",
    "AppearanceScheduleSmokeTestKt",
    "BackupCryptoSmokeTestKt",
    "CsvSafetySmokeTestKt",
    "JalaliCalendarRulesSmokeTestKt",
    "MZFeatureRulesSmokeTestKt",
]
missing = [name for name in required if name not in runner]
for name in required:
    print(("FAIL" if name in missing else "PASS") + " | runner includes " + name)
if missing:
    print("Missing mandatory tests:", ", ".join(missing))
    sys.exit(1)
if "RUN_SLOW_CRYPTO_TESTS" in runner:
    print("FAIL | backup crypto test must not be optional")
    sys.exit(1)
print("SOURCE CHECK RUNNER COVERAGE PASS")
