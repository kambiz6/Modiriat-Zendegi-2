# Test Report — SOURCE-29-TEST

- Test application ID: `ir.modiriyatzendegi.test`
- Main application ID reserved separately: `ir.modiriyatzendegi.app`
- App version: `1.0.0` (code 82), database schema 18
- Python tests: **17 passed**
- Standalone Kotlin/JVM tests: **8 passed**
- Android Gradle build: **not run** (Gradle, Android SDK and `android.jar` unavailable)
- Bank data-at-rest encryption: **BLOCKED** (8 findings)
- 14 product requirements: static paths exist; final functional/runtime acceptance remains incomplete

See `TEST_REPORT_SOURCE_29_TEST_FA.txt` for detailed results and limitations.
