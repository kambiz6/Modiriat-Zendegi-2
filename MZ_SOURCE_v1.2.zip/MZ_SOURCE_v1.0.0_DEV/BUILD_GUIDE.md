# Build Guide — Management Life 2.0 (SOURCE-29-TEST)

## Build identity

- Android applicationId: `ir.modiriyatzendegi.test`
- Main applicationId reserved separately: `ir.modiriyatzendegi.app`
- Display name: `مدیریت زندگی آزمایشی`
- Version name/code: `1.0.0` / `82`
- Database schema version: `18`
- The distinct applicationId gives Android a separate app identity and private data directory. This source does not merge or share a database with the main app.

## Toolchain

- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android Gradle Plugin 8.6.1
- Kotlin Android plugin 2.0.20
- Gradle 8.7

## GitHub Actions (source only; no repository operation performed here)

The workflow is `.github/workflows/build-apk.yml`. It builds a debug APK for the test application only. Extract the ZIP so `settings.gradle.kts` is at repository root, then upload it to your own repository when ready.

## Local build

```bash
gradle --no-daemon clean assembleDebug
```

This package does not include Gradle Wrapper files.

## Tests and audits

Run the consolidated source-level suite (Python tests, bank-access inventory, and standalone Kotlin/JVM tests when `kotlinc` is installed):

```bash
./tools/run_source_checks.sh
# Include the slower backup encryption test:
RUN_SLOW_CRYPTO_TESTS=1 ./tools/run_source_checks.sh
```

The encryption-readiness audit is reported as a known release gate and does not turn a blocked encryption state into a pass. Python/static and standalone JVM tests do not replace Android compilation or device tests.

## Known release blockers

- The live SQLite database still stores bank account/card/IBAN fields as plaintext. SQLCipher and Android Keystore key wrapping are not implemented.
- Backup/restore has not been validated with an encrypted live database.
- Full acceptance and runtime validation of all 14 requirements remains outstanding.
- This is a test-source package, not a release build. Do not treat it as a production-ready secure app.
