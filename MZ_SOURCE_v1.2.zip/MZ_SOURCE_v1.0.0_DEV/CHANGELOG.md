## SOURCE-28 UI Appearance Stage — app 0.23.49 / versionCode 81
- Expanded appearance customization with custom palette colors, card radius, spacing, font family/weight, scale, line and letter spacing, contrast, reduced motion, one-hand spacing, navigation position, calendar mode and welcome text.
- Added page-specific dashboard/screen wallpapers with alpha, brightness and lightweight blur controls.
- Added drag-and-drop dashboard widget ordering while retaining arrow controls.
- Added a 14-icon Clay preview gallery and an optional Clay icon pack for mapped shortcuts.
- Included new preferences in appearance profiles and safe appearance reset.
- Added static UI/resource wiring test and implementation traceability report.
- Android build/device validation has not yet been performed.

# Changelog — Management Life 2.0

## SOURCE-28 — engineering/package preparation (app 0.23.48 / versionCode 80)
- Preserved the SOURCE-27 application code, app version, versionCode and database schema without runtime code changes.
- Added GitHub Actions workflow for Python regression tests, bank-access inventory, encryption-readiness reporting and Android debug APK build.
- Added Persian GitHub build instructions and refreshed build/test documentation.
- Live SQLite bank identifiers are still plaintext; SQLCipher/Android Keystore migration remains pending.
- No APK was built in the preparation environment; GitHub Actions must be run after upload.

## Source V27 — app 0.23.48 / versionCode 80
- Consolidated the dashboard's legacy SharedPreferences task list into the canonical `mz_tasks` owner table.
- Added an idempotent import map and database migration to preserve legacy tasks without duplicate imports.
- Preserved completed-task timestamps in `completed_at` and retained completed/archived task history.
- Dashboard task add/edit/status/archive actions now operate on the same task records as the task-management screen.
- Removed the second, independent dashboard task CRUD path; legacy preference data is retained as a migration source.

## Source V26 — app 0.23.47 / versionCode 79
- Added safe editing of existing financial obligations.
- Editing now rejects a total below recorded payments and rejects party/direction changes that conflict with linked real ledger transactions.
- Added non-destructive soft archive for obligations; linked payments and installments are preserved.

## Source V25 — app 0.23.46 / versionCode 78
- Masked bank identifiers by default in SMS preview.
- Added explicit confirmation before opening the system SMS composer.
- Enforced per-account SMS_SHARE permission and stable account IDs in the audit trail.

## SOURCE-29-TEST — independent test application identity (1.0.0 / code 82)

- Created a separate working copy based on SOURCE-28; the base source remains untouched.
- Changed Android applicationId to `ir.modiriyatzendegi.test` and app label to `مدیریت زندگی آزمایشی`.
- Kept Kotlin namespace `ir.kambiz.daftar` to preserve existing class/resource references.
- Updated source metadata, current build guide, and Debug workflow artifact identity.
- Added a test-app identity/isolation guard; 17 Python tests and 8 standalone Kotlin/JVM tests pass.
- Android Gradle build and device validation were not possible in the current environment.
- SQLCipher/Android Keystore live database encryption remains blocked; all 14 requirements still require final functional/runtime acceptance.


## 2026-11-25 — Source validation tooling

- Added `tools/run_source_checks.sh` as a repeatable local entry point for the Python regression suite, bank-sensitive-access inventory, and eight standalone Kotlin/JVM smoke tests when the Kotlin compiler is available.
- The runner reports the database-encryption readiness audit as a release gate and explicitly distinguishes source checks from Android build/device validation.
- Updated `BUILD_GUIDE.md` with the consolidated validation command.
