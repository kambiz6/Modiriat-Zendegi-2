package ir.kambiz.daftar

/** قواعد خالص و قابل‌آزمون قابلیت‌های جدید؛ بدون وابستگی به Android. */
object MZFeatureRules {
    private val forbiddenCardFields = setOf("pin", "cvv", "cvv2", "otp", "password", "dynamic_password", "second_password")
    private val shareableCardFields = setOf("bank", "owner", "card", "iban")

    fun maskCardNumber(raw: String): String {
        val digits = raw.filter(Char::isDigit)
        if (digits.isEmpty()) return ""
        // شماره‌های کوتاه/نامعتبر را نیز کامل پنهان کن؛ فقط شماره طولانی چهار رقم آخر را نشان می‌دهد.
        if (digits.length <= 4) return "•".repeat(digits.length)
        val visible = digits.takeLast(4)
        return "•".repeat(digits.length - visible.length) + visible
    }

    /** متن پیامک فقط از فیلدهای مجاز ساخته می‌شود و بدون تأیید صریح خروجی نمی‌دهد. */
    fun buildCardShareMessage(fields: Map<String, String>, selected: Set<String>, explicitlyConfirmed: Boolean): String {
        require(explicitlyConfirmed) { "ارسال اطلاعات کارت نیازمند تأیید صریح است" }
        require(selected.isNotEmpty() && selected.all { it in shareableCardFields && it !in forbiddenCardFields }) { "فیلد انتخاب‌شده مجاز نیست" }
        return selected.sorted().mapNotNull { key ->
            val value = fields[key]?.trim().orEmpty()
            if (value.isBlank()) null else when (key) {
                "card" -> "شماره کارت: ${maskCardNumber(value)}"
                "iban" -> "شبا: $value"
                "bank" -> "بانک: $value"
                "owner" -> "صاحب حساب: $value"
                else -> null
            }
        }.joinToString("\n")
    }

    fun remainingObligation(total: Long, paid: Long): Long {
        require(total > 0 && paid >= 0 && paid <= total)
        return total - paid
    }

    fun obligationStatus(total: Long, paid: Long): String = when (remainingObligation(total, paid)) {
        total -> "OPEN"
        0L -> "SETTLED"
        else -> "PARTIAL"
    }

    fun isValidTaskPriority(priority: Int): Boolean = priority in 1..3
    fun isValidShoppingQuantity(quantity: Double): Boolean = quantity.isFinite() && quantity > 0.0
}
