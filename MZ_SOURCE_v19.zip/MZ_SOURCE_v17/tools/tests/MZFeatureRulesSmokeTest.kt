package ir.kambiz.daftar

fun main() {
    check(MZFeatureRules.maskCardNumber("6037991234567890") == "••••••••••••7890")
    check(runCatching { MZFeatureRules.buildCardShareMessage(mapOf("card" to "6037991234567890"), setOf("card"), false) }.isFailure)
    check(runCatching { MZFeatureRules.buildCardShareMessage(mapOf("cvv2" to "123"), setOf("cvv2"), true) }.isFailure)
    check(runCatching { MZFeatureRules.buildCardShareMessage(mapOf("card" to "1234"), setOf("card", "pin"), true) }.isFailure)
    check(MZFeatureRules.maskCardNumber("6037-9912-3456-7890") == "••••••••••••7890")
    check(MZFeatureRules.maskCardNumber("1234") == "••••")
    check(MZFeatureRules.maskCardNumber("12-3") == "•••")
    check(MZFeatureRules.maskCardNumber("----") == "")
    check(MZFeatureRules.buildCardShareMessage(mapOf("card" to "6037991234567890"), setOf("card"), true).contains("7890"))
    check(MZFeatureRules.remainingObligation(1000, 250) == 750L)
    check(MZFeatureRules.obligationStatus(1000, 0) == "OPEN")
    check(MZFeatureRules.obligationStatus(1000, 500) == "PARTIAL")
    check(MZFeatureRules.obligationStatus(1000, 1000) == "SETTLED")
    check(!MZFeatureRules.isValidTaskPriority(4))
    check(!MZFeatureRules.isValidShoppingQuantity(Double.NaN))
    println("MZFeatureRulesSmokeTest: PASS")
}
