"""SQLite smoke test for the MZ feature foundation DDL embedded in MainActivity.kt."""
from pathlib import Path
import re, sqlite3

root = Path(__file__).resolve().parents[2]
source = (root / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt").read_text(encoding="utf-8")
start = source.index("private fun createMZFeatureFoundation")
end = source.index("private fun createInventoryAndInvoices", start)
block = source[start:end]
statements = []
for match in re.finditer(r'db\.execSQL\("""(.*?)"""\)', block, re.S):
    statements.append(match.group(1).strip())
for match in re.finditer(r'db\.execSQL\("((?:\\.|[^"\\])*)"\)', block):
    statements.append(bytes(match.group(1), "utf-8").decode("unicode_escape"))

con = sqlite3.connect(":memory:")
con.execute("PRAGMA foreign_keys=ON")
con.execute("CREATE TABLE people(id INTEGER PRIMARY KEY)")
con.execute("CREATE TABLE transactions(id INTEGER PRIMARY KEY, amount INTEGER NOT NULL, kind TEXT NOT NULL, is_deleted INTEGER NOT NULL DEFAULT 0)")
for sql in statements:
    con.execute(sql)

expected = {
    "mz_tasks", "mz_shopping_items", "mz_obligations", "mz_obligation_payments",
    "mz_calendar_events", "mz_notification_rules", "mz_app_preferences",
    "mz_dashboard_cards", "mz_share_permissions", "mz_share_audit", "mz_search_index"
}
actual = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
assert expected <= actual, expected - actual

# Owner records and read queries used by the Android screens.
con.execute("INSERT INTO mz_tasks(title,created_at,updated_at) VALUES('تست کار',1,1)")
assert con.execute("SELECT title FROM mz_tasks WHERE is_deleted=0").fetchone()[0] == "تست کار"
con.execute("INSERT INTO mz_shopping_items(name,created_at,updated_at) VALUES('تست خرید',1,1)")
assert con.execute("SELECT name FROM mz_shopping_items WHERE is_deleted=0").fetchone()[0] == "تست خرید"
con.execute("INSERT INTO mz_obligations(title,direction,total_amount,created_at,updated_at) VALUES('تست تعهد','PAYABLE',100,1,1)")
con.execute("INSERT INTO transactions(id,amount,kind) VALUES(1,50,'پرداخت وجه')")
con.execute("INSERT INTO mz_obligation_payments(obligation_id,transaction_id,amount,paid_at) VALUES(1,1,50,2)")
assert con.execute("SELECT SUM(amount) FROM mz_obligation_payments WHERE obligation_id=1").fetchone()[0] == 50
try:
    con.execute("INSERT INTO mz_obligation_payments(obligation_id,transaction_id,amount,paid_at) VALUES(1,1,1,3)")
    raise AssertionError("duplicate transaction allocation was accepted")
except sqlite3.IntegrityError:
    pass
con.execute("INSERT INTO mz_calendar_events(title,event_type,starts_at,created_at,updated_at) VALUES('تست رویداد','قرار',10,1,1)")
con.execute("INSERT INTO mz_app_preferences(pref_key,pref_value,updated_at) VALUES('test','1',1) ON CONFLICT(pref_key) DO UPDATE SET pref_value=excluded.pref_value")
con.execute("INSERT INTO mz_search_index(entity_type,entity_id,searchable_text,updated_at) VALUES('task',1,'تست کار',1)")
assert con.execute("SELECT COUNT(*) FROM mz_search_index WHERE searchable_text LIKE '%کار%'").fetchone()[0] == 1
print(f"MZFeatureSchemaSmokeTest: PASS ({len(statements)} DDL statements; 11 tables)")

# Report aggregates must count only the unpaid remainder, not re-count transactions.
payable = con.execute("SELECT COALESCE(SUM(o.total_amount-COALESCE(p.paid,0)),0) FROM mz_obligations o LEFT JOIN (SELECT obligation_id,SUM(amount) paid FROM mz_obligation_payments GROUP BY obligation_id) p ON p.obligation_id=o.id WHERE o.is_deleted=0 AND o.direction='PAYABLE'").fetchone()[0]
assert payable == 50, payable
con.execute("INSERT INTO mz_obligations(title,direction,total_amount,created_at,updated_at) VALUES('تست طلب','RECEIVABLE',200,1,1)")
receivable = con.execute("SELECT COALESCE(SUM(o.total_amount-COALESCE(p.paid,0)),0) FROM mz_obligations o LEFT JOIN (SELECT obligation_id,SUM(amount) paid FROM mz_obligation_payments GROUP BY obligation_id) p ON p.obligation_id=o.id WHERE o.is_deleted=0 AND o.direction='RECEIVABLE'").fetchone()[0]
assert receivable == 200, receivable
# Soft deletion preserves the row but removes it from active views.
con.execute("UPDATE mz_tasks SET is_deleted=1 WHERE id=1")
assert con.execute("SELECT COUNT(*) FROM mz_tasks WHERE is_deleted=0").fetchone()[0] == 0
print("MZFeatureWorkflowSmokeTest: PASS (partial-payment balance, receivable balance, soft archive)")
