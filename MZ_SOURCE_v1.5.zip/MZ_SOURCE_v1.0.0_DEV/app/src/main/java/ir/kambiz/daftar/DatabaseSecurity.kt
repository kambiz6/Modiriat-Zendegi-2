package ir.kambiz.daftar

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.database.Cursor
import android.system.Os
import android.database.sqlite.SQLiteDatabase as AndroidSQLiteDatabase
import net.zetetic.database.sqlcipher.SQLiteDatabase as CipherSQLiteDatabase
import net.zetetic.database.sqlcipher.SQLiteOpenHelper as CipherSQLiteOpenHelper
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.MessageDigest
import java.nio.ByteBuffer
import java.util.Properties
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Wraps a random 256-bit SQLCipher database key with an AES-GCM key held by Android Keystore.
 * A missing metadata file creates a key only when no database already exists. Existing encrypted
 * databases with missing/unusable key metadata must fail closed; they must never be replaced by an
 * empty database.
 */
internal object DatabaseKeyStore {
    private const val ALIAS = "ir.modiriyatzendegi.test.database.master.v1"
    private const val FILE_NAME = "ledger_db_key.v1"
    private const val FORMAT_VERSION: Byte = 1
    private const val GCM_TAG_BITS = 128
    private const val RESTORE_JOURNAL_DIR = "ledger_restore_transaction.v1"

    @Synchronized
    fun getOrCreate(context: Context): ByteArray {
        recoverPendingRestore(context)
        val file = File(context.noBackupFilesDir, FILE_NAME)
        if (file.exists()) return unwrap(file.readBytes())
        val live = context.getDatabasePath("ledger.db")
        if (live.exists() && isSqlCipherFile(live)) {
            throw IllegalStateException("کلید پایگاه داده موجود نیست؛ برای جلوگیری از نابودی اطلاعات، پایگاه جدید ساخته نشد")
        }
        val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
        try {
            writeWrapped(file, raw)
            return raw.copyOf()
        } finally {
            raw.fill(0)
        }
    }

    @Synchronized
    fun replace(context: Context, rawKey: ByteArray) {
        require(rawKey.size == 32) { "Invalid database key length" }
        writeWrapped(File(context.noBackupFilesDir, FILE_NAME), rawKey)
    }

    @Synchronized
    fun beginRestore(context: Context) {
        recoverPendingRestore(context)
        val journal = File(context.noBackupFilesDir, RESTORE_JOURNAL_DIR)
        if (journal.exists() && !journal.deleteRecursively()) {
            throw IllegalStateException("Cannot clear previous restore journal")
        }
        if (!journal.mkdirs()) throw IllegalStateException("Cannot create restore journal")
        val live = context.getDatabasePath("ledger.db")
        deleteOrThrow(File(live.path + "-wal"))
        deleteOrThrow(File(live.path + "-shm"))
        val keyFile = File(context.noBackupFilesDir, FILE_NAME)
        val dbExisted = live.isFile
        val keyExisted = keyFile.isFile
        if (dbExisted) copyFileSynced(live, File(journal, "database.before"))
        if (keyExisted) copyFileSynced(keyFile, File(journal, "key.before"))
        val state = Properties().apply {
            setProperty("status", "pending")
            setProperty("database_existed", dbExisted.toString())
            setProperty("key_existed", keyExisted.toString())
        }
        writePropertiesSynced(File(journal, "state.properties"), state)
    }

    @Synchronized
    fun commitRestore(context: Context) {
        val journal = File(context.noBackupFilesDir, RESTORE_JOURNAL_DIR)
        val stateFile = File(journal, "state.properties")
        if (!stateFile.isFile) throw IllegalStateException("Restore transaction journal is missing")
        val state = readProperties(stateFile)
        require(state.getProperty("status") == "pending") { "Restore transaction is not pending" }
        state.setProperty("status", "committed")
        writePropertiesSynced(stateFile, state)
        // The committed marker makes a later startup cleanup safe if deletion is interrupted.
        if (journal.exists()) journal.deleteRecursively()
    }

    @Synchronized
    fun rollbackRestore(context: Context) {
        recoverPendingRestore(context)
    }

    @Synchronized
    private fun recoverPendingRestore(context: Context) {
        val journal = File(context.noBackupFilesDir, RESTORE_JOURNAL_DIR)
        if (!journal.exists()) return
        val stateFile = File(journal, "state.properties")
        if (!stateFile.isFile) {
            if (!journal.deleteRecursively()) throw IllegalStateException("Cannot clear incomplete restore journal")
            return
        }
        val state = readProperties(stateFile)
        when (state.getProperty("status")) {
            "committed" -> {
                journal.deleteRecursively()
                return
            }
            "pending" -> Unit
            else -> throw IllegalStateException("Unknown restore journal state; database opening is blocked")
        }
        val databaseExisted = state.getProperty("database_existed")
        val keyExisted = state.getProperty("key_existed")
        require(databaseExisted == "true" || databaseExisted == "false") { "Restore journal database flag is invalid" }
        require(keyExisted == "true" || keyExisted == "false") { "Restore journal key flag is invalid" }
        val live = context.getDatabasePath("ledger.db")
        val keyFile = File(context.noBackupFilesDir, FILE_NAME)
        deleteOrThrow(File(live.path + "-wal"))
        deleteOrThrow(File(live.path + "-shm"))
        if (databaseExisted == "true") {
            val backup = File(journal, "database.before")
            require(backup.isFile) { "Restore rollback database copy is missing" }
            restoreFileAtomically(backup, live)
        } else {
            deleteOrThrow(live)
        }
        if (keyExisted == "true") {
            val backup = File(journal, "key.before")
            require(backup.isFile) { "Restore rollback key copy is missing" }
            restoreFileAtomically(backup, keyFile)
        } else {
            deleteOrThrow(keyFile)
        }
        if (!journal.deleteRecursively()) throw IllegalStateException("Cannot remove completed restore rollback journal")
    }

    private fun copyFileSynced(source: File, destination: File) {
        FileInputStream(source).use { input ->
            FileOutputStream(destination).use { output ->
                input.copyTo(output)
                output.fd.sync()
            }
        }
    }

    private fun restoreFileAtomically(source: File, destination: File) {
        val temp = File(destination.parentFile, destination.name + ".restore-rollback.tmp")
        deleteOrThrow(temp)
        copyFileSynced(source, temp)
        Os.rename(temp.absolutePath, destination.absolutePath)
    }

    private fun deleteOrThrow(file: File) {
        if (file.exists() && !file.delete()) throw IllegalStateException("Cannot remove ${file.name}")
    }

    private fun writePropertiesSynced(file: File, properties: Properties) {
        val temp = File(file.parentFile, file.name + ".tmp")
        deleteOrThrow(temp)
        FileOutputStream(temp).use { output ->
            properties.store(output, null)
            output.fd.sync()
        }
        Os.rename(temp.absolutePath, file.absolutePath)
    }

    private fun readProperties(file: File): Properties = Properties().apply {
        FileInputStream(file).use { load(it) }
    }

    private fun writeWrapped(file: File, raw: ByteArray) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, masterKey())
        val encrypted = cipher.doFinal(raw)
        val bytes = byteArrayOf(FORMAT_VERSION) + cipher.iv + encrypted
        val tmp = File(file.parentFile, file.name + ".tmp")
        val previous = File(file.parentFile, file.name + ".previous")
        try {
            FileOutputStream(tmp).use { it.write(bytes); it.fd.sync() }
            if (previous.exists() && !previous.delete()) throw IllegalStateException("Cannot clear previous key metadata")
            if (file.exists() && !file.renameTo(previous)) throw IllegalStateException("Cannot stage current wrapped key")
            if (!tmp.renameTo(file)) {
                if (previous.exists()) previous.renameTo(file)
                tmp.delete()
                throw IllegalStateException("Cannot commit wrapped database key")
            }
            if (previous.exists() && !previous.delete()) throw IllegalStateException("Cannot clear previous key metadata")
        } finally {
            bytes.fill(0)
            encrypted.fill(0)
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun unwrap(blob: ByteArray): ByteArray {
        try {
            require(blob.size == 1 + 12 + 16 + 32 && blob[0] == FORMAT_VERSION) { "Invalid database key metadata" }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, masterKey(), GCMParameterSpec(GCM_TAG_BITS, blob, 1, 12))
            return cipher.doFinal(blob, 13, blob.size - 13).also {
                require(it.size == 32) { "Invalid database key" }
            }
        } catch (e: Exception) {
            throw IllegalStateException("کلید رمزگذاری پایگاه داده قابل بازیابی نیست؛ هیچ پایگاه تازه‌ای ساخته نشد", e)
        } finally {
            blob.fill(0)
        }
    }

    private fun masterKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun isSqlCipherFile(file: File): Boolean {
        if (file.length() < 16) return false
        val header = ByteArray(16)
        FileInputStream(file).use { if (it.read(header) != header.size) return false }
        return !header.copyOfRange(0, 15).contentEquals("SQLite format 3".toByteArray(Charsets.US_ASCII))
    }
}

/**
 * One-time, fail-closed conversion of the existing plaintext SQLite database to SQLCipher.
 * The old file is not overwritten until the encrypted candidate passes integrity, foreign-key,
 * schema and row-count checks. A device-keystore-encrypted emergency copy is retained.
 */
internal object LegacyDatabaseMigrator {
    private const val TEMP_NAME = "ledger_migration_candidate.db"
    private const val EMERGENCY_NAME = "ledger_pre_sqlcipher_backup.v1"

    @Synchronized
    fun migrateIfNeeded(context: Context, key: ByteArray) {
        val live = context.getDatabasePath("ledger.db")
        if (!live.exists()) return
        val header = ByteArray(16)
        FileInputStream(live).use { if (it.read(header) != 16) return }
        val plaintext = header.copyOfRange(0, 15)
            .contentEquals("SQLite format 3".toByteArray(Charsets.US_ASCII))
        header.fill(0)
        if (!plaintext) return

        val wal = File(live.path + "-wal")
        val shm = File(live.path + "-shm")
        val source = AndroidSQLiteDatabase.openDatabase(
            live.absolutePath, null, AndroidSQLiteDatabase.OPEN_READWRITE
        )
        val candidate = context.getDatabasePath(TEMP_NAME)
        val emergency = File(context.noBackupFilesDir, EMERGENCY_NAME)
        var targetHelper: TempCipherHelper? = null
        var candidateKey: ByteArray? = null
        var sourceClosed = false
        try {
            source.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { checkpoint ->
                require(checkpoint.moveToFirst() && checkpoint.getInt(0) == 0 &&
                    (checkpoint.getInt(1) < 0 || checkpoint.getInt(1) == checkpoint.getInt(2))) {
                    "پایگاه قدیمی در وضعیت WAL قابل تثبیت کامل نیست؛ مهاجرت متوقف شد"
                }
            }
            val sourceVersion = source.version
            require(sourceVersion in 1..18) { "نسخه پایگاه قدیمی ناشناخته است: $sourceVersion" }
            removeSqliteSidecars(candidate)
            if (candidate.exists() && !candidate.delete()) throw IllegalStateException("فایل موقت مهاجرت قبلی حذف نشد")
            candidateKey = key.copyOf()
            targetHelper = TempCipherHelper(context, TEMP_NAME, candidateKey!!, sourceVersion)
            val target = targetHelper.writableDatabase
            target.execSQL("PRAGMA foreign_keys=OFF")

            val schema = mutableListOf<Pair<String, String>>()
            source.rawQuery(
                "SELECT type,sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 WHEN 'trigger' THEN 2 WHEN 'view' THEN 3 ELSE 4 END, name",
                null
            ).use { c ->
                while (c.moveToNext()) schema.add(c.getString(0) to c.getString(1))
            }
            val tables = schema.filter { it.first == "table" }
            require(tables.any { it.second.contains("CREATE TABLE people", true) } &&
                tables.any { it.second.contains("CREATE TABLE transactions", true) }) {
                "ساختار پایگاه داده قدیمی معتبر نیست"
            }

            target.beginTransaction()
            try {
                tables.forEach { (_, ddl) -> target.execSQL(ddl) }
                tables.forEach { (_, ddl) ->
                    val table = Regex("""(?is)CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`"\[]?([A-Za-z0-9_]+)""")
                        .find(ddl)?.groupValues?.get(1) ?: throw IllegalStateException("نام جدول قابل تشخیص نیست")
                    source.rawQuery("SELECT * FROM \"$table\"", null).use { cursor ->
                        val columns = cursor.columnNames
                        while (cursor.moveToNext()) {
                            val values = android.content.ContentValues(columns.size)
                            columns.forEachIndexed { index, column ->
                                when (cursor.getType(index)) {
                                    Cursor.FIELD_TYPE_NULL -> values.putNull(column)
                                    Cursor.FIELD_TYPE_INTEGER -> values.put(column, cursor.getLong(index))
                                    Cursor.FIELD_TYPE_FLOAT -> values.put(column, cursor.getDouble(index))
                                    Cursor.FIELD_TYPE_STRING -> values.put(column, cursor.getString(index))
                                    Cursor.FIELD_TYPE_BLOB -> values.put(column, cursor.getBlob(index))
                                    else -> values.putNull(column)
                                }
                            }
                            target.insertOrThrow(table, null, values)
                        }
                    }
                }
                schema.filter { it.first != "table" }.forEach { (_, ddl) -> target.execSQL(ddl) }
                copySqliteSequence(source, target)
                target.version = sourceVersion
                target.setTransactionSuccessful()
            } finally {
                target.endTransaction()
            }

            val sourceCounts = tableCounts(source)
            val targetCounts = tableCounts(target)
            require(sourceCounts == targetCounts) { "تعداد ردیف‌های جدول‌ها پس از مهاجرت برابر نیست" }
            require(tableFingerprints(source) == tableFingerprints(target)) {
                "محتوای رکوردها پس از مهاجرت با پایگاه مبدأ یکسان نیست"
            }
            require(sqliteSequence(source) == sqliteSequence(target)) {
                "شمارنده شناسه‌های خودافزا پس از مهاجرت حفظ نشده است"
            }
            target.rawQuery("PRAGMA integrity_check", null).use { c ->
                require(c.moveToFirst() && c.getString(0) == "ok") { "SQLCipher integrity_check ناموفق بود" }
            }
            target.rawQuery("PRAGMA foreign_key_check", null).use { c ->
                require(!c.moveToFirst()) { "کنترل ارتباط جدول‌ها ناموفق بود" }
            }
            targetHelper.close()
            targetHelper = null
            removeSqliteSidecars(candidate)
            candidateKey?.fill(0)
            candidateKey = null
            source.close()
            sourceClosed = true

            // Retain a device-keystore-encrypted emergency copy before replacing the source.
            encryptEmergencyCopy(live, emergency)
            if (wal.exists() && !wal.delete()) throw IllegalStateException("فایل WAL قدیمی حذف نشد؛ جایگزینی انجام نشد")
            if (shm.exists() && !shm.delete()) throw IllegalStateException("فایل SHM قدیمی حذف نشد؛ جایگزینی انجام نشد")
            // Atomic replacement avoids a crash window in which the live database path is absent.
            // The encrypted emergency copy is already durable before this single rename operation.
            Os.rename(candidate.absolutePath, live.absolutePath)
        } catch (e: Exception) {
            targetHelper?.close()
            candidateKey?.fill(0)
            if (candidate.exists()) candidate.delete()
            if (!sourceClosed) source.close()
            throw IllegalStateException("مهاجرت امن پایگاه داده انجام نشد؛ فایل اصلی حفظ شد", e)
        }
    }

    fun encryptLegacyBackup(context: Context, plaintextBackup: File, candidateName: String, key: ByteArray): File {
        require(plaintextBackup.isFile) { "Legacy backup database is missing" }
        val source = AndroidSQLiteDatabase.openDatabase(
            plaintextBackup.absolutePath, null, AndroidSQLiteDatabase.OPEN_READONLY
        )
        val sourceVersion = source.version
        if (sourceVersion != 18) {
            source.close()
            throw IllegalArgumentException("این پشتیبان قدیمی متعلق به نسخه پایگاه $sourceVersion است؛ فقط نسخه ۱۸ در این مسیر تبدیل می‌شود")
        }
        val candidate = context.getDatabasePath(candidateName)
        removeSqliteSidecars(candidate)
        if (candidate.exists() && !candidate.delete()) {
            source.close()
            throw IllegalStateException("Cannot clear legacy restore candidate")
        }
        var helper: TempCipherHelper? = null
        var candidateKey: ByteArray? = null
        try {
            candidateKey = key.copyOf()
            helper = TempCipherHelper(context, candidateName, candidateKey!!, sourceVersion)
            val target = helper.writableDatabase
            target.execSQL("PRAGMA foreign_keys=OFF")
            val schema = mutableListOf<Pair<String, String>>()
            source.rawQuery(
                "SELECT type,sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 WHEN 'trigger' THEN 2 WHEN 'view' THEN 3 ELSE 4 END, name",
                null
            ).use { c -> while (c.moveToNext()) schema.add(c.getString(0) to c.getString(1)) }
            val tables = schema.filter { it.first == "table" }
            require(tables.any { it.second.contains("CREATE TABLE people", true) } &&
                tables.any { it.second.contains("CREATE TABLE transactions", true) }) {
                "Legacy backup schema is incomplete"
            }
            target.beginTransaction()
            try {
                tables.forEach { (_, ddl) -> target.execSQL(ddl) }
                tables.forEach { (_, ddl) ->
                    val table = Regex("""(?is)CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`"\[]?([A-Za-z0-9_]+)""")
                        .find(ddl)?.groupValues?.get(1) ?: throw IllegalStateException("Cannot parse table name")
                    source.rawQuery("SELECT * FROM \"$table\"", null).use { cursor ->
                        val columns = cursor.columnNames
                        while (cursor.moveToNext()) {
                            val values = android.content.ContentValues(columns.size)
                            columns.forEachIndexed { index, column ->
                                when (cursor.getType(index)) {
                                    Cursor.FIELD_TYPE_NULL -> values.putNull(column)
                                    Cursor.FIELD_TYPE_INTEGER -> values.put(column, cursor.getLong(index))
                                    Cursor.FIELD_TYPE_FLOAT -> values.put(column, cursor.getDouble(index))
                                    Cursor.FIELD_TYPE_STRING -> values.put(column, cursor.getString(index))
                                    Cursor.FIELD_TYPE_BLOB -> values.put(column, cursor.getBlob(index))
                                    else -> values.putNull(column)
                                }
                            }
                            target.insertOrThrow(table, null, values)
                        }
                    }
                }
                schema.filter { it.first != "table" }.forEach { (_, ddl) -> target.execSQL(ddl) }
                copySqliteSequence(source, target)
                target.version = sourceVersion
                target.setTransactionSuccessful()
            } finally { target.endTransaction() }
            require(tableCounts(source) == tableCounts(target)) { "Legacy backup row counts do not match" }
            require(tableFingerprints(source) == tableFingerprints(target)) { "Legacy backup contents do not match" }
            require(sqliteSequence(source) == sqliteSequence(target)) { "Legacy backup autoincrement state does not match" }
            target.rawQuery("PRAGMA integrity_check", null).use { c ->
                require(c.moveToFirst() && c.getString(0) == "ok") { "Legacy backup integrity check failed" }
            }
            target.rawQuery("PRAGMA foreign_key_check", null).use { c ->
                require(!c.moveToFirst()) { "Legacy backup foreign key check failed" }
            }
            helper.close(); helper = null
            removeSqliteSidecars(candidate)
            candidateKey?.fill(0); candidateKey = null
            source.close()
            return candidate
        } catch (e: Exception) {
            helper?.close()
            candidateKey?.fill(0)
            source.close()
            candidate.delete()
            throw IllegalStateException("Legacy backup conversion failed; current database was not changed", e)
        }
    }

    private fun removeSqliteSidecars(database: File) {
        listOf(File(database.path + "-wal"), File(database.path + "-shm")).forEach { sidecar ->
            if (sidecar.exists() && !sidecar.delete()) {
                throw IllegalStateException("فایل جانبی پایگاه موقت حذف نشد: ${sidecar.name}")
            }
        }
    }

    private fun copySqliteSequence(source: AndroidSQLiteDatabase, target: CipherSQLiteDatabase) {
        val exists = source.rawQuery(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='sqlite_sequence'", null
        ).use { it.moveToFirst() }
        if (!exists) return
        target.execSQL("DELETE FROM sqlite_sequence")
        source.rawQuery("SELECT name,seq FROM sqlite_sequence ORDER BY name", null).use { c ->
            while (c.moveToNext()) {
                target.execSQL(
                    "INSERT INTO sqlite_sequence(name,seq) VALUES(?,?)",
                    arrayOf(c.getString(0), c.getLong(1))
                )
            }
        }
    }

    private fun sqliteSequence(db: AndroidSQLiteDatabase): Map<String, Long> =
        readSqliteSequence { sql -> db.rawQuery(sql, null) }

    private fun sqliteSequence(db: CipherSQLiteDatabase): Map<String, Long> =
        readSqliteSequence { sql -> db.rawQuery(sql, null) }

    private fun readSqliteSequence(openQuery: (String) -> Cursor): Map<String, Long> {
        val exists = openQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sqlite_sequence'")
            .use { it.moveToFirst() }
        if (!exists) return emptyMap()
        val result = linkedMapOf<String, Long>()
        openQuery("SELECT name,seq FROM sqlite_sequence ORDER BY name").use { c ->
            while (c.moveToNext()) result[c.getString(0)] = c.getLong(1)
        }
        return result
    }

    private fun tableFingerprints(db: AndroidSQLiteDatabase): Map<String, String> =
        fingerprintTables({ sql -> db.rawQuery(sql, null) }, tableNames(db))

    private fun tableFingerprints(db: CipherSQLiteDatabase): Map<String, String> =
        fingerprintTables({ sql -> db.rawQuery(sql, null) }, tableNames(db))

    private fun tableNames(db: AndroidSQLiteDatabase): List<String> =
        readTableNames { sql -> db.rawQuery(sql, null) }

    private fun tableNames(db: CipherSQLiteDatabase): List<String> =
        readTableNames { sql -> db.rawQuery(sql, null) }

    private fun readTableNames(openQuery: (String) -> Cursor): List<String> {
        val names = mutableListOf<String>()
        openQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
            .use { c -> while (c.moveToNext()) names.add(c.getString(0)) }
        return names
    }

    /** Hashes every typed cell in stable rowid order, not merely row counts. */
    private fun fingerprintTables(
        openQuery: (String) -> Cursor,
        tables: List<String>
    ): Map<String, String> {
        val result = linkedMapOf<String, String>()
        for (table in tables) {
            require(table.matches(Regex("[A-Za-z0-9_]+"))) { "نام جدول غیرمجاز در ممیزی مهاجرت" }
            val digest = MessageDigest.getInstance("SHA-256")
            updateDigestBytes(digest, table.toByteArray(Charsets.UTF_8))
            openQuery("SELECT * FROM \"$table\" ORDER BY rowid").use { c ->
                digest.update(ByteBuffer.allocate(4).putInt(c.columnCount).array())
                for (column in 0 until c.columnCount) updateDigestBytes(digest, c.getColumnName(column).toByteArray(Charsets.UTF_8))
                while (c.moveToNext()) {
                    digest.update(0x7f.toByte())
                    for (index in 0 until c.columnCount) {
                        digest.update(c.getType(index).toByte())
                        when (c.getType(index)) {
                            Cursor.FIELD_TYPE_NULL -> Unit
                            Cursor.FIELD_TYPE_INTEGER -> digest.update(ByteBuffer.allocate(8).putLong(c.getLong(index)).array())
                            Cursor.FIELD_TYPE_FLOAT -> digest.update(ByteBuffer.allocate(8).putLong(java.lang.Double.doubleToLongBits(c.getDouble(index))).array())
                            Cursor.FIELD_TYPE_STRING -> updateDigestBytes(digest, c.getString(index).toByteArray(Charsets.UTF_8))
                            Cursor.FIELD_TYPE_BLOB -> updateDigestBytes(digest, c.getBlob(index))
                            else -> throw IllegalStateException("نوع داده ناشناخته در مهاجرت")
                        }
                    }
                }
            }
            result[table] = digest.digest().joinToString("") { "%02x".format(it) }
        }
        return result
    }

    private fun updateDigestBytes(digest: MessageDigest, bytes: ByteArray) {
        digest.update(ByteBuffer.allocate(4).putInt(bytes.size).array())
        digest.update(bytes)
    }

    private fun tableCounts(db: AndroidSQLiteDatabase): Map<String, Long> {
        val result = linkedMapOf<String, Long>()
        db.rawQuery(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0)
                db.rawQuery("SELECT COUNT(*) FROM \"$name\"", null).use { count ->
                    if (count.moveToFirst()) result[name] = count.getLong(0)
                }
            }
        }
        return result
    }

    private fun tableCounts(db: CipherSQLiteDatabase): Map<String, Long> {
        val result = linkedMapOf<String, Long>()
        db.rawQuery(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0)
                db.rawQuery("SELECT COUNT(*) FROM \"$name\"", null).use { count ->
                    if (count.moveToFirst()) result[name] = count.getLong(0)
                }
            }
        }
        return result
    }

    private fun encryptEmergencyCopy(source: File, destination: File) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val alias = "ir.modiriyatzendegi.test.database.master.v1"
        val key = store.getKey(alias, null) as? SecretKey
            ?: throw IllegalStateException("کلید محافظ اضطراری موجود نیست")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val tmp = File(destination.parentFile, destination.name + ".tmp")
        try {
            FileOutputStream(tmp).use { fileOut ->
                fileOut.write(byteArrayOf(1))
                fileOut.write(cipher.iv)
                val encrypted = javax.crypto.CipherOutputStream(fileOut, cipher)
                FileInputStream(source).use { input -> input.copyTo(encrypted) }
                encrypted.close()
            }
            java.io.RandomAccessFile(tmp, "rw").use { it.fd.sync() }
            if (destination.exists() && !destination.delete()) throw IllegalStateException("نسخه اضطراری قبلی حذف نشد")
            Os.rename(tmp.absolutePath, destination.absolutePath)
        } catch (e: Exception) {
            if (tmp.exists()) tmp.delete()
            throw e
        }
    }

    private class TempCipherHelper(
        context: Context,
        name: String,
        key: ByteArray,
        version: Int
    ) : CipherSQLiteOpenHelper(context, name, key, null, version, 0, null, null, false) {
        override fun onCreate(db: CipherSQLiteDatabase) {}
        override fun onUpgrade(db: CipherSQLiteDatabase, oldVersion: Int, newVersion: Int) {
            throw IllegalStateException("Unexpected migration candidate version")
        }
    }
}

internal fun cipherLongForQuery(
    db: CipherSQLiteDatabase,
    sql: String,
    selectionArgs: Array<String>?
): Long = db.rawQuery(sql, selectionArgs).use { cursor ->
    if (cursor.moveToFirst()) cursor.getLong(0) else 0L
}
