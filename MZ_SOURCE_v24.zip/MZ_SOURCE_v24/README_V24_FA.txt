مدیریت زندگی ۲.۰ — بسته ممیزی نهایی V24
نسخه برنامه: 0.23.45 | versionCode: 77 | DB: 17

این بسته بر مبنای V23 تهیه شده و شامل سخت‌سازی Android Auto Backup، حفظ اصلاحات دفتر مالی/تقسیم پرداخت، جلوگیری از ویرایش/حذف ناسازگار تراکنش‌های متصل، کنترل مالکیت اشتراک کارت، ۱۲ آزمون Python، ۸ مجموعه Kotlin و گزارش ممیزی نهایی است.

برای جزئیات دامنه آزمون‌ها، محدودیت‌ها و چک‌لیست پیش از انتشار، فایل IMPLEMENTATION_REPORT_FINAL_AUDIT_0_23_45_FA.txt را بخوانید.

آزمون‌های Python:
  python3 tools/tests/<test_file>.py

آزمون‌های Kotlin مستقل با kotlinc اجرا می‌شوند؛ نمونه:
  kotlinc app/src/main/java/ir/kambiz/daftar/MZFeatureRules.kt tools/tests/MZFeatureRulesSmokeTest.kt -include-runtime -d /tmp/mz-test.jar
  java -jar /tmp/mz-test.jar

محدودیت: ساخت APK/AAB و آزمون روی Android در این محیط انجام نشده است. قبل از انتشار باید پروژه در Android Studio با SDK 35 ساخته و روی دستگاه آزمایش شود.
