package ir.kambiz.daftar

/** مدل دامنه و کنترل‌های ایمنی الحاقیه مصوب A-024؛ این لایه به‌تنهایی مجری عملیات حساس نیست. */
object A024Automation {
    const val SPEC_ID = "A-024"
    const val SPEC_REVISION = "V37"
    const val STATUS_DRAFT = "DRAFT"
    const val STATUS_PAUSED = "PAUSED"
    const val STATUS_ACTIVE = "ACTIVE"
    const val STATUS_ERROR = "ERROR"

    enum class Authority { SUGGEST_ONLY, REMINDER_WITH_PERMISSION, PREAUTHORIZED_NON_SENSITIVE, EXPLICIT_CONFIRMATION }
    enum class RunStatus { SUCCESS, FAILED, CANCELLED, PARTIAL, AWAITING_CONFIRMATION }

    data class Rule(
        val id: String,
        val title: String,
        val description: String = "",
        val triggerType: String,
        val triggerJson: String = "{}",
        val conditionsJson: String = "[]",
        val actionsJson: String = "[]",
        val scheduleJson: String = "{}",
        val timezoneId: String,
        val authority: Authority = Authority.SUGGEST_ONLY,
        val enabled: Boolean = false
    )

    data class Validation(val valid: Boolean, val errors: List<String>)

    private val sensitiveActionTokens = listOf(
        "PAYMENT", "TRANSFER", "DELETE", "SEND_MESSAGE", "CALL", "LOCATION", "MEDICATION", "DOSE", "ACCOUNT_CHANGE"
    )

    fun validate(rule: Rule): Validation {
        val errors = mutableListOf<String>()
        if (rule.id.isBlank()) errors += "شناسه قانون الزامی است"
        if (rule.title.isBlank()) errors += "عنوان قانون الزامی است"
        if (rule.triggerType.isBlank()) errors += "محرک قانون مشخص نشده است"
        if (rule.timezoneId.isBlank()) errors += "منطقه زمانی مشخص نشده است"
        if (rule.enabled && rule.authority == Authority.SUGGEST_ONLY) errors += "قانون صرفاً پیشنهادی قابل فعال‌سازی نیست"
        val actions = rule.actionsJson.uppercase()
        if (rule.enabled && sensitiveActionTokens.any { actions.contains(it) } && rule.authority != Authority.EXPLICIT_CONFIRMATION) {
            errors += "اقدام حساس فقط با تأیید صریح کاربر مجاز است"
        }
        return Validation(errors.isEmpty(), errors)
    }

    /** کلید یکتا برای جلوگیری از اثر تکراری؛ اجراکننده باید این کلید را با قید UNIQUE ثبت کند. */
    fun executionKey(ruleId: String, scheduledAtMillis: Long, occurrence: String = "default"): String =
        "$ruleId:$scheduledAtMillis:$occurrence"

    /** پس از بازیابی پشتیبان، هیچ قانون فعالی به‌صورت خودکار فعال نمی‌شود. */
    fun restoredStatus(previousStatus: String): String =
        if (previousStatus == STATUS_ACTIVE) STATUS_PAUSED else previousStatus

    /** فقط وضعیت‌های واقعی مجازند؛ شکست یا انتظار تأیید نباید موفق نمایش داده شود. */
    fun displayStatus(status: String): String = when (status) {
        RunStatus.SUCCESS.name -> "موفق"
        RunStatus.FAILED.name -> "ناموفق"
        RunStatus.CANCELLED.name -> "لغوشده"
        RunStatus.PARTIAL.name -> "نیمه‌تمام"
        RunStatus.AWAITING_CONFIRMATION.name -> "در انتظار تأیید"
        else -> "نامشخص"
    }
}
