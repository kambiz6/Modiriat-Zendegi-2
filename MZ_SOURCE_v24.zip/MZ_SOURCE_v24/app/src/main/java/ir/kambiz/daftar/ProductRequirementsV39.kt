package ir.kambiz.daftar

/**
 * رجیستری ساخت‌یافته ۱۴ نیازمندی مصوب الحاقیه MZ-ADDENDUM-14-APP-NEEDS-001.
 * این رجیستری مرجع ردیابی توسعه است؛ وضعیت PARTIAL به معنی وجود مسیر عملیاتی اولیه است، نه تکمیل یا اثبات نهایی همه معیارهای الحاقیه.
 */
data class ProductRequirementV39(
    val id: String,
    val title: String,
    val ownerBranches: List<Int>,
    val summary: String,
    val implementationState: String,
    val clayIconAsset: String
)

object ProductRequirementsV39 {
    const val SOURCE_ADDENDUM_ID = "MZ-ADDENDUM-14-APP-NEEDS-001"
    const val MASTER_VERSION = "v39"

    val all: List<ProductRequirementV39> = listOf(
        ProductRequirementV39("APP-01", "شخصی‌سازی برنامه", listOf(22), "تم، رنگ، فونت، آیکون، چیدمان، پروفایل تنظیمات، پیش‌نمایش و بازیابی تنظیمات.", "PARTIAL", "clay_app_01"),
        ProductRequirementV39("APP-02", "تنظیمات برنامه", listOf(22), "مرکز تنظیمات عمومی، تقویم، زبان، اعلان‌ها، امنیت و مجوزها.", "PARTIAL", "clay_app_02"),
        ProductRequirementV39("APP-03", "ثبت بدهی‌ها و گزارش‌گیری", listOf(1), "تعهد مالی، طرف‌حساب، سررسید، تسویه مرحله‌ای، مانده و گزارش.", "PARTIAL", "clay_app_03"),
        ProductRequirementV39("APP-04", "تکمیل اشخاص و ارتباطات", listOf(18), "پرونده مرکزی و اشتراک‌گذاری مجاز با حفظ مالکیت داده تخصصی.", "PARTIAL", "clay_app_04"),
        ProductRequirementV39("APP-05", "کارت بانکی و اشتراک‌گذاری پیامکی", listOf(1, 18, 22), "ثبت کارت، اتصال به حساب و مالک، انتخاب فیلدهای مجاز و پیش‌نمایش پیامک.", "PARTIAL", "clay_app_05"),
        ProductRequirementV39("APP-06", "کارهای روزانه و برنامه‌ها", listOf(6, 8), "وظایف زمان‌بندی‌شده و نمای عملیاتی کارهای خانه و بیرون بدون رکورد تکراری.", "PARTIAL", "clay_app_06"),
        ProductRequirementV39("APP-07", "ثبت اقلام موردنیاز خرید", listOf(9, 8), "ثبت اقلام موردنیاز و نمایش عملیاتی خریدهای فوری.", "PARTIAL", "clay_app_07"),
        ProductRequirementV39("APP-08", "یادآوری و اعلان‌ها", listOf(6, 22), "اعلان پیش از موعد، سررسید، تأخیر، تکرار، ساعت سکوت و جلوگیری از تکرار.", "PARTIAL", "clay_app_08"),
        ProductRequirementV39("APP-09", "تقویم و برنامه‌ریزی شمسی", listOf(6), "نمای روزانه، هفتگی و ماهانه متصل به رویدادها و رکوردهای اصلی.", "PARTIAL", "clay_app_09"),
        ProductRequirementV39("APP-10", "داشبورد و دسترسی سریع", listOf(86), "کارت‌های تجمیعی قابل تنظیم با رعایت مالکیت و محرمانگی داده.", "PARTIAL", "clay_app_10"),
        ProductRequirementV39("APP-11", "جست‌وجوی یکپارچه", listOf(32, 87), "جست‌وجوی مجاز و دسته‌بندی‌شده در اشخاص، مالی، کارها، خرید و اسناد.", "PARTIAL", "clay_app_11"),
        ProductRequirementV39("APP-12", "مدیریت فهرست خرید", listOf(9, 8, 1), "تعداد، واحد، قیمت تخمینی، سقف هزینه، اولویت، وضعیت و پیوند پرداخت.", "PARTIAL", "clay_app_12"),
        ProductRequirementV39("APP-13", "مدیریت بدهی‌ها و پرداخت مرحله‌ای", listOf(1, 18), "تعهد، طرف‌حساب، اقساط، مانده و گزارش بدون دوباره‌شماری دفتر مالی.", "PARTIAL", "clay_app_13"),
        ProductRequirementV39("APP-14", "امنیت کارت و تأیید پیامک", listOf(1, 18, 22), "ماسک‌سازی، مجوزهای مستقل، پیش‌نمایش و تأیید صریح پیش از ارسال.", "PARTIAL", "clay_app_14"),
    )

    fun find(id: String): ProductRequirementV39? = all.firstOrNull { it.id == id }
}
