package ir.kambiz.daftar

/** Helpers for deriving Jalali month-grid values from the app's yyyy/MM/dd date label. */
object JalaliCalendarRules {
    fun dayOfMonth(jalaliDate: String): Int? {
        val parts = jalaliDate.split('/')
        if (parts.size != 3) return null
        val year = parts[0].toIntOrNull() ?: return null
        val month = parts[1].toIntOrNull() ?: return null
        val day = parts[2].toIntOrNull() ?: return null
        if (year !in 1200..1600 || month !in 1..12) return null
        val maxDay = when {
            month <= 6 -> 31
            month <= 11 -> 30
            else -> 30 // 30 is possible in a leap year; the date label comes from a valid timestamp.
        }
        return day.takeIf { it in 1..maxDay }
    }

    /** monthEndLabel must be the Jalali label for the final instant of the month. */
    fun monthDayCount(monthEndLabel: String): Int? = dayOfMonth(monthEndLabel)
}
