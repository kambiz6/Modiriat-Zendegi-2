#!/usr/bin/env python3
"""V19 regression checks for global search coverage and bank identifier privacy."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[2]
main=(root/'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'obligation search includes linked counterparty':"LEFT JOIN people p ON p.id=o.person_id WHERE o.is_deleted=0 AND (o.title LIKE ? OR o.note LIKE ? OR p.name LIKE ?)" in main,
 'installments are searchable from their owner obligation':"FROM mz_obligation_installments i JOIN mz_obligations o ON o.id=i.obligation_id" in main,
 'transaction search includes linked person':"LEFT JOIN people p ON p.id=t.person_id" in main and 'OR p.name LIKE ?' in main,
 'account number matching is restricted to last four digits':"substr(replace(account_number,' ',''),-4) LIKE ?" in main,
 'IBAN matching is restricted to last four digits':"substr(replace(iban,' ',''),-4) LIKE ?" in main,
 'card number matching is restricted to last four digits':"substr(replace(card_number,' ',''),-4) LIKE ?" in main,
 'full account identifiers are not searched directly':'OR account_number LIKE ?' not in main and 'OR iban LIKE ?' not in main,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
if not all(checks.values()): sys.exit(1)
print(f'V19 search/privacy smoke test: PASS ({len(checks)} checks)')
