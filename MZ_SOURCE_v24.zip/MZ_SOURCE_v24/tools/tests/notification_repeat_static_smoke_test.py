from pathlib import Path
import re
root=Path(__file__).resolve().parents[2]
s=(root/'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
start=s.index('class MZAppNotificationReceiver')
end=s.index('class MZNotificationRestoreReceiver',start)
block=s[start:end]
assert 'val ownerStillActive=' in block
assert 'if(delta>0 && kind=="یادآوری کار" && ownerStillActive)' in block
assert 'taskStillActive' not in block
print('NotificationRepeatStaticSmokeTest: PASS (repeat scheduling uses validated active-owner state)')
