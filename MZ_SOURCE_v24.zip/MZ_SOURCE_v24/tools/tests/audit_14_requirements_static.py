#!/usr/bin/env python3
"""Static audit for the V39 14-capability addendum; does not claim runtime completeness."""
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[2]
main=(root/'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
rules=(root/'app/src/main/java/ir/kambiz/daftar/MZFeatureRules.kt').read_text(encoding='utf-8')
checks={
 'APP-01 personalization UI/profile':'showAppearanceSettings' in main and 'AppearanceProfileRules' in main,
 'APP-02 settings/dashboard controls':'showHomeSettings' in main and 'showHomeWidgetSettings' in main,
 'APP-03 obligation records/payments':'mz_obligations' in main and 'linkMZObligationPayment' in main,
 'APP-04 people linkage':'owner_person_id' in main and 'personPage' in main,
 'APP-05 card SMS composer':'shareBankCardSms' in main and 'ACTION_SENDTO' in main,
 'APP-06 tasks CRUD/status':'addMZTask' in main and 'setMZTaskStatus' in main,
 'APP-07 shopping list CRUD/status':'addMZShoppingItem' in main and 'setMZShoppingStatus' in main,
 'APP-08 notification rules':'mz_notification_rules' in main and 'scheduleMZNotification' in main,
 'APP-09 Persian calendar views':'showMZCalendar' in main and 'renderMZCalendar' in main,
 'APP-10 dashboard widgets':'showHomeWidgetSettings' in main and 'widget_order' in main,
 'APP-11 unified search path':'searchMZIndex' in main and 'searchable_text' in main,
 'APP-12 shopping status/price':'finalPrice' in main and 'mz_shopping_items' in main,
 'APP-13 obligation installments/report':'mz_obligation_installments' in main and 'mzObligationReport' in main,
 'APP-14 sensitive card sharing guard':'buildCardShareMessage' in rules and 'mz_share_audit' in main,
 'APP-14 card SMS recipient must own account':'isAccountOwnedByPerson(ownerPersonId,it.id)' in main and 'ownerPersonId==null' in main,
 'APP-13 transaction aggregate allocation cap':'WHERE transaction_id=?' in main and 'canAllocateTransactionAmount(tx.first,allocated,amount)' in main,
 'APP-13 strict obligation/transaction party match':'obligation.third==tx.third' in main,
 'APP-13 split allocation schema migration':'migrateObligationPaymentSplits(db)' in main and 'transaction_id INTEGER NOT NULL UNIQUE' not in main,
 'APP-13 available transactions exclude fully allocated rows':'COALESCE((SELECT SUM(p.amount)' in main and 'p.transaction_id=t.id' in main,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' | '+k)
if not all(checks.values()): sys.exit(1)
print('STATIC AUDIT PASS: code paths exist; functionality and Android runtime are not proven.')
