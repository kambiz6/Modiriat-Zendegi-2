#!/usr/bin/env python3
"""Static manifest hardening checks; not a substitute for Android platform testing."""
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[2]
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
checks = {
    'Android automatic app backup is disabled for sensitive local data': 'android:allowBackup="false"' in manifest,
    'cleartext traffic is not explicitly enabled': 'android:usesCleartextTraffic="true"' not in manifest,
    'notification restore receiver is not exported': '<receiver android:name=".MZNotificationRestoreReceiver" android:enabled="true" android:exported="false"' in manifest,
    'person reminder receiver is not exported': '<receiver android:name=".PersonReminderReceiver" android:enabled="true" android:exported="false"' in manifest,
    'app notification receiver is not exported': '<receiver android:name=".MZAppNotificationReceiver" android:enabled="true" android:exported="false"' in manifest,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + name)
if not all(checks.values()):
    sys.exit(1)
print(f'MANIFEST STATIC AUDIT PASS ({len(checks)} checks)')
