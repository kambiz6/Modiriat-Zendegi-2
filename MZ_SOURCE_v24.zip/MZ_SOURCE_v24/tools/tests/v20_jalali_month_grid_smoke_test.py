#!/usr/bin/env python3
"""Regression checks for Jalali month-grid date arithmetic."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[2]
main=(root/'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
rules=(root/'app/src/main/java/ir/kambiz/daftar/JalaliCalendarRules.kt').read_text(encoding='utf-8')
checks={
    'month length comes from final Jalali date':'JalaliCalendarRules.dayOfMonth(jalali(monthEnd-1L))' in main,
    'event day number uses Jalali conversion':'JalaliCalendarRules.dayOfMonth(jalali(c.getLong(0)))' in main,
    'task recurrence day number uses Jalali conversion':'JalaliCalendarRules.dayOfMonth(jalali(cursor))' in main,
    'obligation day number uses Jalali conversion':'JalaliCalendarRules.dayOfMonth(jalali(c.getLong(0)))' in main,
    'selected grid date is converted using Jalali year/month/day':'jalaliToMillis(monthParts.getOrNull(0)?.toIntOrNull()' in main,
    'pure date-label validation exists':'fun dayOfMonth(jalaliDate: String): Int?' in rules,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
if not all(checks.values()): sys.exit(1)
print(f'V20 Jalali month-grid smoke test: PASS ({len(checks)} checks)')
