#!/usr/bin/env python3
"""Regression model and static guards for linked transaction edit/archive integrity."""
from pathlib import Path
import sqlite3, sys
root = Path(__file__).resolve().parents[2]
source = (root/'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
checks = {
    'linked transaction amount cannot fall below allocated payments': 'require(amount>=allocated)' in source,
    'linked transaction kind must remain compatible with obligation direction': 'require(mismatch==0L)' in source,
    'linked transactions cannot be soft-deleted': 'require(linked==0L)' in source,
    'transaction edit is committed atomically': 'val d=writableDatabase;d.beginTransaction()' in source[source.index('fun updateTx('):source.index('fun personOpeningBalance(')],
    'delete UI reports a safe refusal rather than crashing': 'catch(e:Exception){toast(e.message?:"انتقال به سطل بازیابی ناموفق بود")}' in source,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
if not all(checks.values()): sys.exit(1)

con=sqlite3.connect(':memory:')
con.executescript('''CREATE TABLE transactions(id INTEGER PRIMARY KEY,amount INTEGER,kind TEXT,is_deleted INTEGER DEFAULT 0);
CREATE TABLE mz_obligations(id INTEGER PRIMARY KEY,direction TEXT);
CREATE TABLE mz_obligation_payments(id INTEGER PRIMARY KEY,transaction_id INTEGER,obligation_id INTEGER,amount INTEGER);
INSERT INTO transactions VALUES(1,1000,'پرداخت وجه',0);
INSERT INTO mz_obligations VALUES(1,'PAYABLE');
INSERT INTO mz_obligation_payments VALUES(1,1,1,700);''')
amount, allocated = con.execute('SELECT amount,(SELECT SUM(amount) FROM mz_obligation_payments WHERE transaction_id=1) FROM transactions WHERE id=1').fetchone()
assert amount >= allocated
assert allocated-1 < allocated
assert con.execute("SELECT COUNT(*) FROM mz_obligation_payments p JOIN mz_obligations o ON o.id=p.obligation_id WHERE p.transaction_id=1 AND ((o.direction='PAYABLE' AND ? NOT IN ('پرداخت وجه','بدهی')) OR (o.direction='RECEIVABLE' AND ? NOT IN ('دریافت وجه','طلب')))",('دریافت وجه','دریافت وجه')).fetchone()[0] == 1
assert con.execute('SELECT COUNT(*) FROM mz_obligation_payments WHERE transaction_id=1').fetchone()[0] == 1
print('financial_link_integrity_test: PASS (edit/archive guards + SQLite regression model)')
