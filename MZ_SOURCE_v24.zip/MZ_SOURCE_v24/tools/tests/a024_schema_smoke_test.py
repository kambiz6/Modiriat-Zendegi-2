from pathlib import Path
import re
import sqlite3

source = Path(__file__).parents[2] / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt"
text = source.read_text(encoding="utf-8")
section = text.split("private fun createA024AutomationFoundation(db: SQLiteDatabase) {", 1)[1].split("private fun createInventoryAndInvoices", 1)[0]
statements = []
pattern = r'db\.execSQL\(\s*(?:"""(.*?)"""|"((?:\\.|[^"\\])*)")\s*\)'
for match in re.finditer(pattern, section, re.S):
    sql = match.group(1) if match.group(1) is not None else match.group(2)
    statements.append(sql)
connection = sqlite3.connect(":memory:")
for statement in statements:
    connection.execute(statement)
tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
required = {
    "mz_automation_rules", "mz_automation_steps", "mz_automation_runs",
    "mz_automation_permissions", "mz_automation_queue", "mz_automation_versions",
    "mz_automation_event_inbox"
}
assert required.issubset(tables), required - tables
connection.execute("INSERT INTO mz_automation_rules(id,title,trigger_type,timezone_id,created_at,updated_at) VALUES('r','test','MANUAL','Asia/Tehran',1,1)")
connection.execute("INSERT INTO mz_automation_runs(rule_id,execution_key,status) VALUES('r','r:1','SUCCESS')")
try:
    connection.execute("INSERT INTO mz_automation_runs(rule_id,execution_key,status) VALUES('r','r:1','SUCCESS')")
    raise AssertionError("duplicate execution key was accepted")
except sqlite3.IntegrityError:
    pass
print(f"A024SchemaSmokeTest: PASS ({len(statements)} DDL statements; {len(required)} application tables; unique execution key)")
