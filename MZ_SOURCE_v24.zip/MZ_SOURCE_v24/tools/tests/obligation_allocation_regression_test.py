#!/usr/bin/env python3
"""SQLite migration + regression for splitting one real transaction across obligations."""
import sqlite3

con = sqlite3.connect(':memory:')
con.execute('PRAGMA foreign_keys=ON')
con.executescript('''
CREATE TABLE people(id INTEGER PRIMARY KEY);
CREATE TABLE transactions(id INTEGER PRIMARY KEY, amount INTEGER NOT NULL, person_id INTEGER);
CREATE TABLE mz_obligations(id INTEGER PRIMARY KEY, person_id INTEGER, total_amount INTEGER NOT NULL);
CREATE TABLE mz_obligation_payments(
 id INTEGER PRIMARY KEY AUTOINCREMENT, obligation_id INTEGER NOT NULL,
 transaction_id INTEGER NOT NULL UNIQUE, amount INTEGER NOT NULL CHECK(amount>0),
 paid_at INTEGER NOT NULL, note TEXT DEFAULT '', installment_id INTEGER,
 FOREIGN KEY(obligation_id) REFERENCES mz_obligations(id),
 FOREIGN KEY(transaction_id) REFERENCES transactions(id));
INSERT INTO people VALUES(7);
INSERT INTO transactions VALUES(1,1000,7),(2,500,NULL),(3,900,8);
INSERT INTO mz_obligations VALUES(10,7,700),(11,7,500),(12,NULL,500);
INSERT INTO mz_obligation_payments(obligation_id,transaction_id,amount,paid_at,note) VALUES(10,1,600,1,'legacy');
''')

# Exact V17 table rebuild: preserve existing rows and remove the old UNIQUE(transaction_id).
con.executescript('''
CREATE TABLE mz_obligation_payments_v17(
 id INTEGER PRIMARY KEY AUTOINCREMENT, obligation_id INTEGER NOT NULL,
 transaction_id INTEGER NOT NULL, amount INTEGER NOT NULL CHECK(amount>0),
 paid_at INTEGER NOT NULL, note TEXT DEFAULT '', installment_id INTEGER,
 FOREIGN KEY(obligation_id) REFERENCES mz_obligations(id),
 FOREIGN KEY(transaction_id) REFERENCES transactions(id));
INSERT INTO mz_obligation_payments_v17(id,obligation_id,transaction_id,amount,paid_at,note,installment_id)
 SELECT id,obligation_id,transaction_id,amount,paid_at,note,installment_id FROM mz_obligation_payments;
DROP TABLE mz_obligation_payments;
ALTER TABLE mz_obligation_payments_v17 RENAME TO mz_obligation_payments;
CREATE INDEX idx_mz_obligation_payment_tx ON mz_obligation_payments(transaction_id);
''')

# Legacy payment survived migration byte-for-byte in its business fields.
assert con.execute('SELECT id,obligation_id,transaction_id,amount,paid_at,note FROM mz_obligation_payments').fetchone() == (1,10,1,600,1,'legacy')

def allocation_state(tx_id):
    tx = con.execute('SELECT amount,person_id FROM transactions WHERE id=?', (tx_id,)).fetchone()
    allocated = con.execute('SELECT COALESCE(SUM(amount),0) FROM mz_obligation_payments WHERE transaction_id=?', (tx_id,)).fetchone()[0]
    return tx, allocated

def link(obligation_id, tx_id, amount):
    tx, allocated = allocation_state(tx_id)
    person = con.execute('SELECT person_id FROM mz_obligations WHERE id=?', (obligation_id,)).fetchone()
    if tx is None or amount <= 0 or allocated > tx[0] or amount > tx[0]-allocated:
        return False
    if person[0] != tx[1]:
        return False
    con.execute('INSERT INTO mz_obligation_payments(obligation_id,transaction_id,amount,paid_at) VALUES(?,?,?,2)', (obligation_id,tx_id,amount))
    return True

assert link(11,1,400)             # split across a second obligation; reaches exactly 1000
assert allocation_state(1)[1] == 1000
assert not link(12,1,1)           # transaction already fully allocated
assert not link(11,2,1)           # null party does not match person 7
assert not link(10,3,1)           # person 8 does not match person 7
assert not link(12,2,501)         # amount exceeds transaction amount
assert con.execute('SELECT COUNT(*) FROM mz_obligation_payments WHERE transaction_id=1').fetchone()[0] == 2
assert con.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
print('obligation_allocation_regression_test: PASS (v17 migration, legacy preservation, split allocation, cap, party match)')
