#!/usr/bin/env python3
"""Static regression checks for V17 task/shopping edits and connected calendar views."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[2]
main=(root/'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
checks={
    'task editing persists all editable fields':'fun updateMZTask(' in main and 'db.updateMZTask(id,title.text.toString()' in main,
    'task progress is validated and stored':'fun setMZTaskProgress(' in main and 'require(progress in 0..100)' in main and 'پیشرفت ${r[9]}٪' in main,
    'task due/reminder fields can be explicitly disabled':'dueEnabled.isChecked' in main and 'reminderEnabled.isChecked' in main,
    'task reminder edit cancels old alarm before rescheduling':'cancelMZNotification(id,"یادآوری کار");if(remindAt!=null)scheduleMZNotification' in main,
    'shopping editing persists seller and other fields':'fun updateMZShoppingItem(' in main and 'r[13].toString()' in main and 'db.updateMZShoppingItem(' in main,
    'shopping needed date is optional':'dateEnabled.isChecked' in main,
    'calendar reads tasks from owner table':'SELECT id,title,status,due_at,priority,repeat_rule FROM mz_tasks' in main,
    'calendar expands daily and weekly task recurrence':'"DAILY"->dayMs;"WEEKLY"->7L*dayMs' in main,
    'calendar reads obligations from owner table':'SELECT id,title,direction,status,due_at,total_amount FROM mz_obligations' in main,
    'monthly grid includes tasks and obligations':'SELECT due_at,repeat_rule FROM mz_tasks' in main and 'SELECT due_at FROM mz_obligations' in main,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
if not all(checks.values()):sys.exit(1)
print(f'V17 CRUD/calendar smoke test: PASS ({len(checks)} checks)')
