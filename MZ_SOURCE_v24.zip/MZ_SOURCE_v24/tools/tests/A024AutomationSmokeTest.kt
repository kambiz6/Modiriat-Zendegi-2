package ir.kambiz.daftar

fun main() {
    val safeDraft = A024Automation.Rule(
        id = "rule-1", title = "یادآوری پرداخت", triggerType = "SCHEDULE",
        timezoneId = "Asia/Tehran", authority = A024Automation.Authority.SUGGEST_ONLY
    )
    check(A024Automation.validate(safeDraft).valid)
    val invalidActiveSuggestion = safeDraft.copy(enabled = true)
    check(!A024Automation.validate(invalidActiveSuggestion).valid)
    val sensitiveWithoutConfirmation = safeDraft.copy(
        actionsJson = "[{\"type\":\"SEND_MESSAGE\"}]",
        authority = A024Automation.Authority.PREAUTHORIZED_NON_SENSITIVE,
        enabled = true
    )
    check(!A024Automation.validate(sensitiveWithoutConfirmation).valid)
    val sensitiveWithConfirmation = sensitiveWithoutConfirmation.copy(
        authority = A024Automation.Authority.EXPLICIT_CONFIRMATION
    )
    check(A024Automation.validate(sensitiveWithConfirmation).valid)
    check(A024Automation.executionKey("r", 100L) == A024Automation.executionKey("r", 100L))
    check(A024Automation.restoredStatus(A024Automation.STATUS_ACTIVE) == A024Automation.STATUS_PAUSED)
    check(A024Automation.displayStatus("FAILED") == "ناموفق")
    println("A024AutomationSmokeTest: PASS")
}
