"""SQLite and manifest smoke test for reboot alarm restoration sources."""
from pathlib import Path
import re, sqlite3
root = Path(__file__).resolve().parents[2]
src = (root / 'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
assert 'class MZNotificationRestoreReceiver:BroadcastReceiver()' in src
assert 'android.intent.action.BOOT_COMPLETED' in manifest
assert 'android.intent.action.MY_PACKAGE_REPLACED' in manifest
assert 'android.permission.RECEIVE_BOOT_COMPLETED' in manifest
for table, field in [('mz_tasks','reminder_at'),('mz_obligations','due_at'),('mz_shopping_items','needed_at'),('mz_calendar_events','starts_at'),('person_reminders','remind_at')]:
    assert f'FROM {table}' in src and field in src
assert 'while(nextAt<=now)nextAt+=step' in src
assert 'قلم ضروری خرید' in src and 'سررسید تعهد مالی' in src
print('NotificationRestoreSmokeTest: PASS (5 owner sources, reboot/package replacement hooks, recurring alarm catch-up)')
