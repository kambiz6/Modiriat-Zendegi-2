package ir.kambiz.daftar

fun main() {
    check(JalaliCalendarRules.dayOfMonth("1405/01/31") == 31)
    check(JalaliCalendarRules.dayOfMonth("1405/06/31") == 31)
    check(JalaliCalendarRules.dayOfMonth("1405/07/30") == 30)
    check(JalaliCalendarRules.dayOfMonth("1405/11/30") == 30)
    check(JalaliCalendarRules.dayOfMonth("1405/12/29") == 29)
    check(JalaliCalendarRules.dayOfMonth("1404/12/30") == 30)
    check(JalaliCalendarRules.monthDayCount("1405/07/30") == 30)
    check(JalaliCalendarRules.dayOfMonth("1405/13/01") == null)
    check(JalaliCalendarRules.dayOfMonth("1405/02/32") == null)
    check(JalaliCalendarRules.dayOfMonth("invalid") == null)
    println("JalaliCalendarRulesSmokeTest: PASS (10 checks)")
}
