#!/usr/bin/env python3
"""Static safeguards for V18 search-index refresh and owner-row mutation integrity."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[2]
main=(root/'app/src/main/java/ir/kambiz/daftar/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'search rebuilds from source tables before querying':'if(query.isBlank())return emptyList();refreshMZSearchIndex()' in main,
 'index rebuild is transactional':'fun refreshMZSearchIndex()' in main and 'd.beginTransaction()' in main and 'd.setTransactionSuccessful()' in main and 'd.endTransaction()' in main,
 'people index excludes archived records':"FROM people WHERE is_deleted=0" in main,
 'accounts index excludes archived records':"FROM finance_accounts WHERE is_deleted=0" in main,
 'card/account/IBAN indexing masks all but last four': all(x in main for x in ['کارت ****','substr(replace(card_number','substr(replace(account_number','substr(replace(iban']),
 'transactions include person, note, type and account':"'TRANSACTION',t.id" in main and "COALESCE(p.name,'')" in main and "COALESCE(t.note,'')" in main,
 'tasks/shopping/obligations/calendar are indexed':all(x in main for x in ["'TASK',id","'SHOPPING',id","'OBLIGATION',id","'CALENDAR',id"]),
 'task status rejects missing/archived ids':'require(changed==1){"کار پیدا نشد یا بایگانی شده است"}' in main,
 'task progress rejects missing/archived ids':'require(changed==1){"کار پیدا نشد یا بایگانی شده است"}' in main,
 'shopping status rejects missing/archived ids':'require(changed==1){"قلم خرید پیدا نشد یا بایگانی شده است"}' in main,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
if not all(checks.values()): sys.exit(1)
print(f'V18 search/integrity smoke test: PASS ({len(checks)} checks)')
