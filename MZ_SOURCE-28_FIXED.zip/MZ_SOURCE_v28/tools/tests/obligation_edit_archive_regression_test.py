#!/usr/bin/env python3
"""Regression checks for safe obligation edits and non-destructive archive."""
from pathlib import Path
import sqlite3

root = Path(__file__).resolve().parents[2]
source = (root / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt").read_text(encoding="utf-8")
assert "fun updateMZObligation(" in source
assert "fun archiveMZObligation(" in source
assert 'btn("ویرایش تعهد")' in source
assert 'btn("بایگانی تعهد")' in source
assert 'برای این تعهد سررسید ثبت شود' in source
assert "سوابق پرداخت و اقساط حفظ شد" in source

db = sqlite3.connect(":memory:")
db.executescript("""
CREATE TABLE people(id INTEGER PRIMARY KEY);
CREATE TABLE transactions(id INTEGER PRIMARY KEY, person_id INTEGER, kind TEXT, amount INTEGER, is_deleted INTEGER DEFAULT 0);
CREATE TABLE obligations(id INTEGER PRIMARY KEY, person_id INTEGER, title TEXT, direction TEXT, total_amount INTEGER, due_at INTEGER, note TEXT, status TEXT, is_deleted INTEGER DEFAULT 0);
CREATE TABLE payments(id INTEGER PRIMARY KEY, obligation_id INTEGER, transaction_id INTEGER, amount INTEGER);
CREATE TABLE installments(id INTEGER PRIMARY KEY, obligation_id INTEGER, amount INTEGER, paid_amount INTEGER DEFAULT 0);
INSERT INTO people VALUES(1),(2);
INSERT INTO transactions VALUES(10,1,'پرداخت وجه',500,0),(11,2,'دریافت وجه',400,0);
INSERT INTO obligations VALUES(20,1,'اجاره','PAYABLE',500,1000,'','PARTIAL',0);
INSERT INTO payments VALUES(30,20,10,200);
INSERT INTO installments VALUES(40,20,500,200);
""")
paid = db.execute("SELECT COALESCE(SUM(amount),0) FROM payments WHERE obligation_id=20").fetchone()[0]
assert paid == 200

def validate_update(new_total, person_id, direction):
    if new_total < paid:
        raise ValueError("total below paid")
    mismatch = db.execute("""SELECT COUNT(*) FROM payments p JOIN transactions t ON t.id=p.transaction_id
    WHERE p.obligation_id=20 AND (t.person_id IS NOT ? OR (?='PAYABLE' AND t.kind NOT IN ('پرداخت وجه','بدهی')) OR (?='RECEIVABLE' AND t.kind NOT IN ('دریافت وجه','طلب')))""", (person_id, direction, direction)).fetchone()[0]
    if mismatch:
        raise ValueError("linked transaction mismatch")

for args in [(150, 1, 'PAYABLE'), (500, 2, 'PAYABLE'), (500, 1, 'RECEIVABLE')]:
    try:
        validate_update(*args)
        raise AssertionError(f"unsafe edit unexpectedly accepted: {args}")
    except ValueError:
        pass
validate_update(600, 1, 'PAYABLE')
db.execute("UPDATE obligations SET total_amount=600,title='اجاره اصلاح‌شده' WHERE id=20")
db.execute("UPDATE obligations SET is_deleted=1,status='ARCHIVED' WHERE id=20")
assert db.execute("SELECT COUNT(*) FROM payments WHERE obligation_id=20").fetchone()[0] == 1
assert db.execute("SELECT COUNT(*) FROM installments WHERE obligation_id=20").fetchone()[0] == 1
print("obligation_edit_archive_regression_test: PASS")
