#!/usr/bin/env python3
"""Checks one-time migration of legacy dashboard tasks into the canonical task table."""
from pathlib import Path
import sqlite3

root = Path(__file__).resolve().parents[2]
source = (root / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt").read_text(encoding="utf-8")
assert "const val DATABASE_VERSION = 18" in source
assert "ALTER TABLE mz_tasks ADD COLUMN completed_at INTEGER" in source
assert "COALESCE(completed_at,updated_at)" in source
assert "if(oldVersion < 18) migrateToV18(db)" in source
assert "fun importLegacyHomeTask(" in source
assert "migrateLegacyHomeTasksToMZTasks()" in source
assert "addMZTaskDialog(returnHome=true)" in source
assert "editMZTaskDialog(task,returnHome=true)" in source
assert 'private fun readHomeTasks():JSONArray' in source
assert "addHomeTaskDialog" not in source
assert "editHomeTaskDialog" not in source
assert "updateHomeTask" not in source
assert "deleteHomeTask" not in source

home_start = source.index("private fun showHome(requestedPage:Int?=null)")
home_end = source.index("private data class HomeAlert", home_start)
assert "db.mzTasks(includeDone=true)" in source[home_start:home_end]
assert "readHomeTasks()" not in source[home_start:home_end]
alerts_end = source.index("private fun showAlertCenter", source.index("private fun collectHomeAlerts"))
alerts = source[source.index("private fun collectHomeAlerts"):alerts_end]
assert "readHomeTasks()" not in alerts

# SQLite model of the idempotent import map and preservation of completed state.
db = sqlite3.connect(":memory:")
db.executescript("""
CREATE TABLE mz_tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,status TEXT NOT NULL,progress INTEGER NOT NULL,created_at INTEGER NOT NULL,completed_at INTEGER);
CREATE TABLE mz_legacy_import_map(source_key TEXT NOT NULL,source_id TEXT NOT NULL,target_table TEXT NOT NULL,target_id INTEGER NOT NULL,created_at INTEGER NOT NULL,UNIQUE(source_key,source_id,target_table));
""")
def import_task(source_id, title, done, created_at, completed_at=None):
    row = db.execute("SELECT target_id FROM mz_legacy_import_map WHERE source_key=? AND source_id=? AND target_table=?", ("home_dashboard.home_tasks", source_id, "mz_tasks")).fetchone()
    if row:
        return row[0]
    cur = db.execute("INSERT INTO mz_tasks(title,status,progress,created_at,completed_at) VALUES(?,?,?,?,?)", (title, "انجام‌شده" if done else "باز", 100 if done else 0, created_at, (completed_at or created_at) if done else None))
    target_id = cur.lastrowid
    db.execute("INSERT INTO mz_legacy_import_map VALUES(?,?,?,?,?)", ("home_dashboard.home_tasks", source_id, "mz_tasks", target_id, created_at))
    db.commit()
    return target_id

first = import_task("legacy-100", "خرید روزانه", False, 100)
again = import_task("legacy-100", "خرید روزانه", False, 100)
assert first == again
assert db.execute("SELECT COUNT(*) FROM mz_tasks").fetchone()[0] == 1
completed = import_task("legacy-200", "تماس با مدرسه", True, 200, 175)
assert db.execute("SELECT status,progress,completed_at FROM mz_tasks WHERE id=?", (completed,)).fetchone() == ("انجام‌شده", 100, 175)
assert db.execute("SELECT COUNT(*) FROM mz_legacy_import_map").fetchone()[0] == 2
print("legacy_dashboard_task_migration_test: PASS")
