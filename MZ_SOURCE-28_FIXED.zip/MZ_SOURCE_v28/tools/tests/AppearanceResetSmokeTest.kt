package ir.kambiz.daftar

fun main() {
    val keys = AppearanceReset.preferenceKeys
    check(AppearanceReset.shouldReset("theme"))
    check(AppearanceReset.shouldReset("appearance_background_uri"))
    check(AppearanceReset.shouldReset("ticker_messages"))
    check(AppearanceReset.shouldReset("widget_hidden"))
    check(AppearanceReset.shouldReset("appearance_custom_accent"))
    check(AppearanceReset.shouldReset("appearance_backgrounds"))
    check(AppearanceReset.shouldReset("font_family"))
    check(AppearanceReset.shouldReset("font_weight"))
    check(AppearanceReset.shouldReset("letter_spacing"))
    check(AppearanceReset.shouldReset("calendar_mode"))
    check(AppearanceReset.shouldReset("icon_pack"))
    check(!AppearanceReset.shouldReset("appearance_profile_v2_favorite"))
    check(!AppearanceReset.shouldReset("policy_allow_full"))
    check(!AppearanceReset.shouldReset("policy_allow_theme"))
    check(keys.none { it.startsWith("appearance_profile_") })
    check(keys.none { it.startsWith("policy_") })
    check(keys.none { it in setOf("people", "transactions", "finance_accounts", "audit_log") })
    println("PASS: 17 appearance reset safety checks")
}
