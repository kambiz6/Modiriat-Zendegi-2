from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt"
RESET = ROOT / "app/src/main/java/ir/kambiz/daftar/AppearanceReset.kt"
SOURCE = MAIN.read_text(encoding="utf-8")
RESET_SOURCE = RESET.read_text(encoding="utf-8")

required_main = [
    "showAppearanceAdvancedControls",
    "appearance_custom_accent",
    "appearance_custom_background",
    "appearance_custom_card",
    "appearance_custom_text",
    "card_radius",
    "spacing_scale",
    "font_family",
    "font_weight",
    "letter_spacing",
    "line_spacing_extra",
    "high_contrast",
    "reduce_motion",
    "navigation_position",
    "calendar_mode",
    "appearance_backgrounds",
    "ACTION_DROP",
    "showClayIconGallery",
    "R.drawable.clay_app_14",
]
for token in required_main:
    assert token in SOURCE, f"Missing appearance UI integration: {token}"

for token in [
    "appearance_custom_accent",
    "appearance_backgrounds",
    "font_family",
    "high_contrast",
    "reduce_motion",
    "calendar_mode",
    "icon_pack",
]:
    assert token in RESET_SOURCE, f"Appearance reset does not include {token}"

for index in range(1, 15):
    resource = ROOT / f"app/src/main/res/drawable-nodpi/clay_app_{index:02d}.png"
    assert resource.exists(), f"Missing Clay icon resource: {resource.name}"

print("PASS: appearance UI wiring and 14 Clay icon resources")
