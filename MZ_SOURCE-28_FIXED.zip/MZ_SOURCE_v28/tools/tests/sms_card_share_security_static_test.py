#!/usr/bin/env python3
"""Static regression checks for per-account SMS sharing safeguards."""
from pathlib import Path
root = Path(__file__).resolve().parents[2]
main = (root / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt").read_text(encoding="utf-8")
rules = (root / "app/src/main/java/ir/kambiz/daftar/MZFeatureRules.kt").read_text(encoding="utf-8")
start = main.index("private fun shareBankCardSms(accountName:String)")
end = main.index("private fun showMoneySettings()", start)
flow = main[start:end]
checks = {
    "account ID is read from finance_accounts": "SELECT id,bank_name,card_number,account_number,iban,owner_name,owner_person_id" in flow,
    "SMS permission is checked before share flow": 'isSharePermissionAllowed("BANK_ACCOUNT",accountId,"SMS_SHARE")' in flow,
    "preview uses masking helper": "formatCardSharePreview(fieldValues,fields,reveal)" in flow,
    "full identifier reveal defaults off": "revealSensitive=styledCheckBox().apply{text=\"نمایش کامل شماره کارت، حساب و شبا در پیش‌نمایش و پیامک\";isChecked=false}" in flow,
    "final SMS body requires explicit confirmation": "buildCardShareMessage(fieldValues,fields,true,reveal)" in flow,
    "SMS uses system composer rather than direct send": "Intent(Intent.ACTION_SENDTO" in flow and "sendTextMessage" not in flow,
    "audit stores stable account ID": 'put("subject_id",accountId)' in flow,
    "permission can be revoked from account screen": "manageBankSharePermission(item.first)" in main and "setSharePermission(\"BANK_ACCOUNT\",accountId,\"SMS_SHARE\",!allowed)" in main,
    "all sensitive account identifiers have masking logic": all(x in rules for x in ("maskCardNumber", "maskBankIdentifier", '"account" ->', '"iban" ->')),
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " | " + name)
if not all(checks.values()):
    raise SystemExit(1)
print(f"sms_card_share_security_static_test: PASS ({len(checks)} checks)")
