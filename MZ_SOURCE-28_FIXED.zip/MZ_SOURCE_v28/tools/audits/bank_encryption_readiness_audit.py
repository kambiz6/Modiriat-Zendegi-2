#!/usr/bin/env python3
"""Readiness gate for the planned SQLCipher/Keystore migration.

This audit intentionally reports BLOCKED while sensitive bank identifiers are
stored in plaintext SQLite columns or plaintext database staging files exist.
It is a source inspection aid, not proof of runtime encryption.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
MAIN = ROOT / "app/src/main/java/ir/kambiz/daftar/MainActivity.kt"
BACKUP_CRYPTO = ROOT / "app/src/main/java/ir/kambiz/daftar/BackupCrypto.kt"
GRADLE = ROOT / "app/build.gradle.kts"
main = MAIN.read_text(encoding="utf-8")
crypto = BACKUP_CRYPTO.read_text(encoding="utf-8")
gradle = GRADLE.read_text(encoding="utf-8")

checks = {
    "sensitive account fields currently declared as plaintext TEXT columns":
        all(f'"{field}" to "TEXT' in main for field in ("account_number", "card_number", "iban")),
    "account insertion writes sensitive values directly into finance_accounts":
        all(f'put("{field}",' in main for field in ("account_number", "card_number", "iban")),
    "account detail reader directly selects sensitive columns":
        "SELECT bank_name,account_type,account_number,card_number,iban,owner_name,notes FROM finance_accounts" in main,
    "global search reads last digits from plaintext sensitive columns":
        "substr(replace(card_number,' ',''),-4)" in main and "substr(replace(account_number,' ',''),-4)" in main,
    "person-linked account display reads sensitive columns":
        "SELECT bank_name,owner_name,account_number,card_number,iban FROM finance_accounts" in main,
    "backup restore extracts ledger.db to a filesystem path":
        'File(dir,"ledger.db")' in main and 'FileOutputStream(out).use{zip.copyTo(it)}' in main,
    "backup package itself uses authenticated AES-GCM encryption":
        'Cipher.getInstance("AES/GCM/NoPadding")' in crypto and "cipher.updateAAD(header)" in crypto,
    "app module does not yet declare SQLCipher dependency":
        "sqlcipher" not in gradle.lower(),
    "source does not yet integrate Android Keystore for database key wrapping":
        "AndroidKeyStore" not in main and "AndroidKeyStore" not in "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in (ROOT / "app/src/main/java").rglob("*.kt")),
}

for label, passed in checks.items():
    print(("BLOCKER" if passed and ("plaintext" in label or "directly" in label or "direct selects" in label or "last digits" in label or "reads sensitive" in label or "extracts" in label or "does not yet" in label) else "PASS" if passed else "REVIEW") + " | " + label)

blockers = [name for name, passed in checks.items() if passed and any(token in name for token in ("plaintext", "directly", "direct selects", "last digits", "reads sensitive", "extracts", "does not yet"))]
if blockers:
    print(f"READINESS: BLOCKED ({len(blockers)} blockers). Do not claim database-at-rest encryption or release an encrypted-storage build.")
    sys.exit(0)
print("READINESS: REVIEW REQUIRED. Static checks alone cannot prove runtime encryption.")
