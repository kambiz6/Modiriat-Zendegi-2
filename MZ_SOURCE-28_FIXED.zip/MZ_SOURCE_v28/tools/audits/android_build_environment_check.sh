#!/usr/bin/env bash
set -u
printf '%s\n' 'Management Life 2.0 — Android build environment check'
printf 'Java: '; command -v java || true
java -version 2>&1 | head -n 1 || true
printf 'Gradle: '; command -v gradle || true
printf 'ADB: '; command -v adb || true
printf 'ANDROID_HOME=%s\n' "${ANDROID_HOME:-<unset>}"
printf 'ANDROID_SDK_ROOT=%s\n' "${ANDROID_SDK_ROOT:-<unset>}"
for sdk in "${ANDROID_HOME:-}" "${ANDROID_SDK_ROOT:-}" /opt/android-sdk /usr/lib/android-sdk "$HOME/Android/Sdk"; do
  if [ -n "$sdk" ] && [ -d "$sdk" ]; then
    printf 'SDK directory found: %s\n' "$sdk"
    find "$sdk/platforms" -maxdepth 2 -name android.jar -print 2>/dev/null | head -n 5
  fi
done
if [ -f ./gradlew ]; then echo 'Gradle wrapper: present'; else echo 'Gradle wrapper: MISSING'; fi
if [ -f ./app/build.gradle.kts ]; then echo 'App Gradle file: present'; else echo 'App Gradle file: MISSING'; fi
