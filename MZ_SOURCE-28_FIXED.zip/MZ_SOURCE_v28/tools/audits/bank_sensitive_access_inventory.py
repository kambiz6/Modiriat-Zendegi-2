#!/usr/bin/env python3
"""Inventory direct references to bank identifiers before secure-storage migration.

This is an audit aid, not proof of runtime security. It deliberately reports
source locations so reviewers can update every access path during migration.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "app/src/main/java/ir/kambiz/daftar"
FIELDS = ("account_number", "card_number", "iban")
REQUIRED_MARKERS = {
    "schema_and_migration": ("createFinanceExtras",),
    "insert": ("fun addAccount",),
    "details_read": ("fun accountDetails",),
    "search_index": ("mz_search_index",),
    "sms_share": ("shareBankCardSms",),
    "global_search": ("LIMIT 40",),
    "person_linked_display": ("owner_person_id",),
}

hits = []
for path in sorted(SOURCE.glob("*.kt")):
    lines = path.read_text(encoding="utf-8").splitlines()
    for number, line in enumerate(lines, 1):
        if any(re.search(rf"\b{re.escape(field)}\b", line) for field in FIELDS):
            hits.append((path.relative_to(ROOT).as_posix(), number, line.strip()))

main_text = (SOURCE / "MainActivity.kt").read_text(encoding="utf-8")
missing = [name for name, markers in REQUIRED_MARKERS.items()
           if not any(marker in main_text for marker in markers)]

print("BANK SENSITIVE FIELD ACCESS INVENTORY")
print(f"Root: {ROOT}")
print(f"Direct source-line hits: {len(hits)}")
for file, line, content in hits:
    print(f"{file}:{line}: {content}")
print("Required access-path markers:")
for name in REQUIRED_MARKERS:
    print(f"  {'FOUND' if name not in missing else 'MISSING'}: {name}")

if missing:
    print("AUDIT: FAIL — expected access-path marker(s) missing")
    sys.exit(1)
print("AUDIT: PASS — known direct access paths inventoried; encryption is NOT implied")
