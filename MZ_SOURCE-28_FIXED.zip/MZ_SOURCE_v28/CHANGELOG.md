## SOURCE-28 UI Appearance Stage — app 0.23.49 / versionCode 81
- Expanded appearance customization with custom palette colors, card radius, spacing, font family/weight, scale, line and letter spacing, contrast, reduced motion, one-hand spacing, navigation position, calendar mode and welcome text.
- Added page-specific dashboard/screen wallpapers with alpha, brightness and lightweight blur controls.
- Added drag-and-drop dashboard widget ordering while retaining arrow controls.
- Added a 14-icon Clay preview gallery and an optional Clay icon pack for mapped shortcuts.
- Included new preferences in appearance profiles and safe appearance reset.
- Added static UI/resource wiring test and implementation traceability report.
- Android build/device validation has not yet been performed.

# Changelog — Management Life 2.0

## SOURCE-28 — engineering/package preparation (app 0.23.48 / versionCode 80)
- Preserved the SOURCE-27 application code, app version, versionCode and database schema without runtime code changes.
- Added GitHub Actions workflow for Python regression tests, bank-access inventory, encryption-readiness reporting and Android debug APK build.
- Added Persian GitHub build instructions and refreshed build/test documentation.
- Live SQLite bank identifiers are still plaintext; SQLCipher/Android Keystore migration remains pending.
- No APK was built in the preparation environment; GitHub Actions must be run after upload.

## Source V27 — app 0.23.48 / versionCode 80
- Consolidated the dashboard's legacy SharedPreferences task list into the canonical `mz_tasks` owner table.
- Added an idempotent import map and database migration to preserve legacy tasks without duplicate imports.
- Preserved completed-task timestamps in `completed_at` and retained completed/archived task history.
- Dashboard task add/edit/status/archive actions now operate on the same task records as the task-management screen.
- Removed the second, independent dashboard task CRUD path; legacy preference data is retained as a migration source.

## Source V26 — app 0.23.47 / versionCode 79
- Added safe editing of existing financial obligations.
- Editing now rejects a total below recorded payments and rejects party/direction changes that conflict with linked real ledger transactions.
- Added non-destructive soft archive for obligations; linked payments and installments are preserved.

## Source V25 — app 0.23.46 / versionCode 78
- Masked bank identifiers by default in SMS preview.
- Added explicit confirmation before opening the system SMS composer.
- Enforced per-account SMS_SHARE permission and stable account IDs in the audit trail.
