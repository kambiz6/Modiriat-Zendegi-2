package ir.kambiz.daftar

/** قواعد خالص و قابل‌آزمون قابلیت‌های جدید؛ بدون وابستگی به Android. */
object MZFeatureRules {
    private val forbiddenCardFields = setOf("pin", "cvv", "cvv2", "otp", "password", "dynamic_password", "second_password")
    private val shareableCardFields = setOf("bank", "owner", "card", "account", "iban")

    fun maskCardNumber(raw: String): String {
        val digits = raw.filter(Char::isDigit)
        if (digits.isEmpty()) return ""
        // شماره‌های کوتاه/نامعتبر را نیز کامل پنهان کن؛ فقط شماره طولانی چهار رقم آخر را نشان می‌دهد.
        if (digits.length <= 4) return "•".repeat(digits.length)
        val visible = digits.takeLast(4)
        return "•".repeat(digits.length - visible.length) + visible
    }

    fun maskBankIdentifier(raw: String): String {
        val visible = raw.filter(Char::isLetterOrDigit)
        if (visible.isEmpty()) return ""
        if (visible.length <= 4) return "•".repeat(visible.length)
        return "•".repeat(visible.length - 4) + visible.takeLast(4)
    }

    /** پیش‌نمایش امن؛ شناسه‌های بانکی تا انتخاب صریح نمایش کامل، ماسک می‌مانند. */
    fun formatCardSharePreview(fields: Map<String, String>, selected: Set<String>, revealSensitive: Boolean = false): String {
        require(selected.isNotEmpty() && selected.all { it in shareableCardFields && it !in forbiddenCardFields }) { "فیلد انتخاب‌شده مجاز نیست" }
        return selected.sorted().mapNotNull { key ->
            val value = fields[key]?.trim().orEmpty()
            if (value.isBlank()) null else when (key) {
                "card" -> "شماره کارت: ${if (revealSensitive) value else maskCardNumber(value)}"
                "account" -> "شماره حساب: ${if (revealSensitive) value else maskBankIdentifier(value)}"
                "iban" -> "شبا: ${if (revealSensitive) value else maskBankIdentifier(value)}"
                "bank" -> "بانک: $value"
                "owner" -> "صاحب حساب: $value"
                else -> null
            }
        }.joinToString("\n")
    }

    /** متن نهایی پیامک فقط پس از تأیید صریح ساخته می‌شود. */
    fun buildCardShareMessage(fields: Map<String, String>, selected: Set<String>, explicitlyConfirmed: Boolean, revealSensitive: Boolean = false): String {
        require(explicitlyConfirmed) { "ارسال اطلاعات کارت نیازمند تأیید صریح است" }
        return formatCardSharePreview(fields, selected, revealSensitive)
    }

    /** اشتراک‌گذاری فقط زمانی مجاز است که گیرنده دقیقاً مالک ثبت‌شده حساب باشد. */
    fun isAccountOwnedByPerson(ownerPersonId: Long?, recipientPersonId: Long): Boolean =
        ownerPersonId != null && ownerPersonId > 0L && recipientPersonId > 0L && ownerPersonId == recipientPersonId

    /** تخصیص تجمعی یک تراکنش به تعهدها نباید از مبلغ واقعی همان تراکنش عبور کند. */
    fun canAllocateTransactionAmount(transactionAmount: Long, alreadyAllocated: Long, requestedAmount: Long): Boolean =
        transactionAmount > 0L && alreadyAllocated >= 0L && requestedAmount > 0L &&
            alreadyAllocated <= transactionAmount && requestedAmount <= transactionAmount - alreadyAllocated

    fun remainingObligation(total: Long, paid: Long): Long {
        require(total > 0 && paid >= 0 && paid <= total)
        return total - paid
    }

    fun obligationStatus(total: Long, paid: Long): String = when (remainingObligation(total, paid)) {
        total -> "OPEN"
        0L -> "SETTLED"
        else -> "PARTIAL"
    }

    fun isValidTaskPriority(priority: Int): Boolean = priority in 1..3
    fun isValidShoppingQuantity(quantity: Double): Boolean = quantity.isFinite() && quantity > 0.0
}
