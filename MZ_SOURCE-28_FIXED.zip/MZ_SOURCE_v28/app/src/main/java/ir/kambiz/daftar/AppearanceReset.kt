package ir.kambiz.daftar

/** Only presentation preferences are reset. Saved profiles, admin policy, and business data are deliberately excluded. */
object AppearanceReset {
    val preferenceKeys: Set<String> = setOf(
        "customization_mode", "theme", "home_layout", "icon_style",
        "ticker_enabled", "motion_enabled", "auto_night",
        "appearance_schedule_mode", "appearance_night_start", "appearance_night_end",
        "ticker_color", "ticker_size", "ticker_speed", "ticker_moving", "ticker_position", "ticker_messages",
        "appearance_background_uri", "appearance_background_alpha", "launcher_icon",
        "widget_order", "widget_hidden", "focus_mode", "senior_mode", "dashboard_page", "font_scale",
        "appearance_custom_accent", "appearance_custom_background", "appearance_custom_card", "appearance_custom_text", "appearance_custom_soft",
        "card_radius", "spacing_scale", "font_family", "font_weight", "letter_spacing", "line_spacing_extra", "high_contrast", "reduce_motion",
        "navigation_position", "one_hand_mode", "start_page", "welcome_message", "glass_cards", "appearance_backgrounds", "calendar_mode", "icon_pack"
    )

    fun shouldReset(key: String): Boolean = key in preferenceKeys
}
