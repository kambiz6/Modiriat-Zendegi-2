مدیریت زندگی ۲.۰ — راهنمای ساخت APK در GitHub Actions
شناسه سورس: SOURCE-28
نسخه برنامه: 0.23.48 | versionCode: 80 | پایگاه داده: 18

۱) بارگذاری سورس
- ZIP را استخراج کنید؛ ریشه مخزن باید مستقیماً شامل settings.gradle.kts، build.gradle.kts، app/، tools/ و .github/ باشد.
- یک مخزن GitHub بسازید. برای سورس شخصی، مخزن Private انتخاب امن‌تری است.
- محتوای پوشه استخراج‌شده را در ریشه مخزن قرار دهید و commit کنید.
- شاخه‌های ثابت پروژه را حفظ کنید: main برای مرجع پایدار و build-new-apk برای ساخت و آزمون.
- سورس را برای ساخت APK روی build-new-apk قرار دهید؛ workflow از قبل در .github/workflows/build-apk.yml قرار دارد.

۲) اجرای ساخت
- در GitHub وارد تب Actions شوید.
- workflow با نام Build Android APK را انتخاب کنید.
- گزینه Run workflow را بزنید و شاخه build-new-apk را انتخاب کنید.
- همچنین push تغییرات کد به build-new-apk به‌صورت خودکار workflow را اجرا می‌کند.
- workflow از JDK 17، Android SDK Platform 35، Build Tools 35.0.0 و Gradle 8.7 استفاده می‌کند.
- ابتدا آزمون‌های Python و ممیزی مسیرهای اطلاعات بانکی اجرا می‌شوند؛ سپس assembleDebug اجرا می‌شود.

۳) دریافت APK
- پس از موفقیت job، همان اجرای workflow را باز کنید.
- از بخش Artifacts فایل management-life-2-SOURCE-28-v0.23.48-debug-apk را دریافت کنید.
- فایل app-debug.apk درون artifact قرار دارد. فایل BUILD_OUTPUT_INFO.txt نیز شناسه commit و SHA-256 خروجی را ثبت می‌کند.

۴) محدودیت‌های مهم
- این workflow فقط APK آزمایشی Debug می‌سازد؛ امضای انتشار نهایی و Release APK تنظیم نشده است.
- موفقیت ساخت APK به معنی تأیید نصب، عملکرد کامل ۱۴ قابلیت، امنیت پایگاه داده یا آمادگی انتشار نیست.
- شماره کارت، حساب و شبا در SQLite فعلی هنوز رمزگذاری‌شده نیستند. ممیزی رمزگذاری عمداً وضعیت BLOCKED را گزارش می‌کند.
- SQLCipher و حفاظت کلید پایگاه داده با Android Keystore هنوز پیاده‌سازی نشده‌اند.
- قبل از نصب روی گوشی دارای اطلاعات واقعی، از داده‌ها پشتیبان بگیرید و ابتدا روی دستگاه/داده آزمایشی نصب و بررسی کنید.
- کلید امضای Release، رمزها، فایل‌های دیتابیس واقعی، پشتیبان‌های شخصی و local.properties را به مخزن GitHub اضافه نکنید.

۵) ساخت محلی
پروژه از Android Gradle Plugin 8.6.1، Kotlin Android plugin 2.0.20 و Gradle 8.7 استفاده می‌کند. در محیطی با JDK 17 و Android SDK Platform 35 از ریشه پروژه اجرا کنید:

    gradle --no-daemon clean assembleDebug

خروجی مورد انتظار:

    app/build/outputs/apk/debug/app-debug.apk

در این بسته Gradle Wrapper قرار ندارد؛ GitHub Actions نسخه Gradle 8.7 را در محیط runner نصب می‌کند.
