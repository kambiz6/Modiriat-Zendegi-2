# مدیریت زندگی ۲.۰ — SOURCE-28

**Application ID:** `ir.kambiz.daftar`  
**App version:** `0.23.48` · **versionCode:** `80` · **Database:** `18`  
**Source package:** `SOURCE-28` (based on the preserved SOURCE-27 application code)

این مخزن شامل سورس اندروید و مسیر ساخت آزمایشی APK از طریق GitHub Actions است.

## ساخت APK در GitHub

1. سورس را در شاخه `build-new-apk` قرار دهید.
2. به تب **Actions** بروید.
3. workflow با نام **Build Android APK** را اجرا کنید.
4. پس از موفقیت، artifact با نام `management-life-2-SOURCE-28-v0.23.48-debug-apk` را دریافت کنید.

راهنمای کامل فارسی: [README_GITHUB_BUILD_FA.txt](README_GITHUB_BUILD_FA.txt)

## وضعیت فنی و امنیتی

- workflow فقط APK آزمایشی **Debug** می‌سازد؛ امضای Release پیکربندی نشده است.
- APK در بسته سورس وجود ندارد و تا اجرای موفق GitHub Actions ساخته‌شده محسوب نمی‌شود.
- اطلاعات شماره کارت، حساب و شبا در SQLite فعلی هنوز متن آشکار هستند؛ SQLCipher و Android Keystore برای پایگاه داده ادغام نشده‌اند.
- همه ۱۴ نیازمندی محصول به‌صورت کامل و عملیاتی اثبات نشده‌اند؛ ممیزی ایستا به‌تنهایی اثبات عملکرد نیست.
- پیش از نصب روی اطلاعات واقعی، پشتیبان تهیه کنید و ابتدا روی داده/دستگاه آزمایشی بررسی کنید.

گزارش آزمون: [TEST_REPORT.md](TEST_REPORT.md) · راهنمای ساخت: [BUILD_GUIDE.md](BUILD_GUIDE.md) · شناسنامه سورس: [README_SOURCE_28_FA.txt](README_SOURCE_28_FA.txt)
