# Build Guide — Management Life 2.0 (SOURCE-28)

## Toolchain

- JDK 17
- Android SDK Platform 35
- Android Build Tools 35.0.0
- Android Gradle Plugin 8.6.1
- Kotlin Android plugin 2.0.20
- Gradle 8.7

## GitHub Actions (recommended for this source package)

The workflow is `.github/workflows/build-apk.yml`.

1. Extract the source ZIP so `settings.gradle.kts` is at the repository root.
2. Push the source to the `build-new-apk` branch (keep `main` as the stable reference branch).
3. Open GitHub Actions and run **Build Android APK**, selecting `build-new-apk`; code pushes to that branch also trigger the workflow.
4. Download the artifact `management-life-2-SOURCE-28-v0.23.48-debug-apk` from the successful run.
5. Verify `BUILD_OUTPUT_INFO.txt` and its APK SHA-256 value.

See `README_GITHUB_BUILD_FA.txt` for Persian step-by-step instructions and limitations.

## Local build

```bash
gradle --no-daemon clean assembleDebug
```

Expected output: `app/build/outputs/apk/debug/app-debug.apk`.

This source package does not include Gradle Wrapper files. GitHub Actions installs Gradle 8.7 explicitly.

## Tests and audits

```bash
for test in tools/tests/*.py; do python3 "$test" || exit 1; done
python3 tools/audits/bank_sensitive_access_inventory.py
python3 tools/audits/bank_encryption_readiness_audit.py
```

The readiness audit is expected to report `BLOCKED` until live database encryption and secure migration are implemented. It exits successfully because this is a documented security finding, not a CI compilation failure.

## Release and data safety

- The workflow creates a **debug APK only**. It does not create a signed release APK.
- A successful build does not prove complete functionality or real-device behavior.
- Bank account/card/IBAN fields remain plaintext in the SQLite database. SQLCipher and Android Keystore database-key protection are not implemented.
- Do not install on the primary database without a verified backup. Test migrations on copies first.
- Never commit real databases, backups, signing keys, passwords, `local.properties`, or personal data.
