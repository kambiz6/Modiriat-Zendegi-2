package ir.kambiz.daftar

/** Run: kotlinc app/src/main/java/ir/kambiz/daftar/AppearanceSchedule.kt tools/tests/AppearanceScheduleSmokeTest.kt -include-runtime -d /tmp/appearance-schedule-test.jar && java -jar /tmp/appearance-schedule-test.jar */
fun main() {
    val scheduled = AppearanceSchedule.MODE_SCHEDULED
    check(!AppearanceSchedule.isNight(AppearanceSchedule.MODE_OFF, 19 * 60, 7 * 60, 22 * 60))
    check(!AppearanceSchedule.isNight(scheduled, 19 * 60, 7 * 60, 18 * 60 + 59))
    check(AppearanceSchedule.isNight(scheduled, 19 * 60, 7 * 60, 19 * 60))
    check(AppearanceSchedule.isNight(scheduled, 19 * 60, 7 * 60, 23 * 60 + 59))
    check(AppearanceSchedule.isNight(scheduled, 19 * 60, 7 * 60, 0))
    check(!AppearanceSchedule.isNight(scheduled, 19 * 60, 7 * 60, 7 * 60))
    check(AppearanceSchedule.isNight(scheduled, 8 * 60, 17 * 60, 12 * 60))
    check(!AppearanceSchedule.isNight(scheduled, 8 * 60, 17 * 60, 17 * 60))
    check(!AppearanceSchedule.isNight(scheduled, 600, 600, 600))
    check(!AppearanceSchedule.isNight(scheduled, -1, 600, 500))
    check(AppearanceSchedule.formatTime(19 * 60 + 5) == "19:05")
    println("PASS: 11 appearance schedule checks")
}
