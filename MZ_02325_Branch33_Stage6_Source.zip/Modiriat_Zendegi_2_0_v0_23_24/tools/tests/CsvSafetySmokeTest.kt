package ir.kambiz.daftar

/** Run with kotlinc app/src/main/java/ir/kambiz/daftar/CsvSafety.kt tools/tests/CsvSafetySmokeTest.kt -include-runtime -d /tmp/csv-safety-test.jar && java -jar /tmp/csv-safety-test.jar */
fun main() {
    check(CsvSafety.protectSpreadsheetFormula("=1+1") == "'=1+1")
    check(CsvSafety.protectSpreadsheetFormula("  +SUM(A1:A2)") == "'  +SUM(A1:A2)")
    check(CsvSafety.protectSpreadsheetFormula("\t@cmd") == "'\t@cmd")
    check(CsvSafety.protectSpreadsheetFormula("-100") == "'-100")
    check(CsvSafety.protectSpreadsheetFormula("نام کالا") == "نام کالا")
    check(CsvSafety.cell("کالا, ویژه") == "\"کالا, ویژه\"")
    check(CsvSafety.cell("گفت \"سلام\"") == "\"گفت \"\"سلام\"\"\"")
    check(CsvSafety.cell("=HYPERLINK(\"https://example.com\")") == "\"'=HYPERLINK(\"\"https://example.com\"\")\"")
    println("PASS: 8 CSV safety checks")
}
