package ir.kambiz.daftar

import java.security.GeneralSecurityException

fun main() {
    val password = "StrongPass-1405".toCharArray()
    val plain = "Modiriat Zendegi backup: people, ledger, invoices".toByteArray()
    val encrypted = BackupCrypto.encrypt(plain, password)
    check(BackupCrypto.isEncrypted(encrypted))
    check(!encrypted.contentEquals(plain))
    check(BackupCrypto.decrypt(encrypted, password).contentEquals(plain))

    val wrongPasswordRejected = try {
        BackupCrypto.decrypt(encrypted, "WrongPass-1405".toCharArray())
        false
    } catch (_: GeneralSecurityException) { true }
    check(wrongPasswordRejected)

    val tampered = encrypted.copyOf().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() }
    val tamperRejected = try {
        BackupCrypto.decrypt(tampered, password)
        false
    } catch (_: GeneralSecurityException) { true }
    check(tamperRejected)

    val truncatedRejected = try {
        BackupCrypto.decrypt(encrypted.copyOf(12), password)
        false
    } catch (_: IllegalArgumentException) { true }
    check(truncatedRejected)

    val shortPasswordRejected = try {
        BackupCrypto.encrypt(plain, "short".toCharArray())
        false
    } catch (_: IllegalArgumentException) { true }
    check(shortPasswordRejected)

    val second = BackupCrypto.encrypt(plain, password)
    check(!encrypted.contentEquals(second)) // fresh salt/nonce for every export
    check(BackupCrypto.decrypt(second, password).contentEquals(plain))
    println("PASS: 8 backup encryption safety checks")
}
