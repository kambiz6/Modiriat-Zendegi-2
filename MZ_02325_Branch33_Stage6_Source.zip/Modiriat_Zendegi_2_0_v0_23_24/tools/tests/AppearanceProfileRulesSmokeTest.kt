package ir.kambiz.daftar

/** Run: kotlinc app/src/main/java/ir/kambiz/daftar/AppearanceProfileRules.kt tools/tests/AppearanceProfileRulesSmokeTest.kt -include-runtime -d /tmp/appearance-profile-rules-test.jar && java -jar /tmp/appearance-profile-rules-test.jar */
fun main() {
    check(AppearanceProfileRules.normalizeName(" كاميـز ") == AppearanceProfileRules.normalizeName("کامیــز"))
    check(AppearanceProfileRules.normalizeName("ي" ) == AppearanceProfileRules.normalizeName("ی"))
    check(AppearanceProfileRules.normalizeName("ك" ) == AppearanceProfileRules.normalizeName("ک"))
    check(AppearanceProfileRules.normalizeName("نام\u200cپروفایل") == AppearanceProfileRules.normalizeName("نامپروفایل"))
    check(AppearanceProfileRules.normalizeName("  NAME   ONE ") == "name one")
    check(AppearanceProfileRules.isValidName("پروفایل زمردی"))
    check(!AppearanceProfileRules.isValidName("   "))
    check(!AppearanceProfileRules.isValidName("x".repeat(41)))
    check(!AppearanceProfileRules.isValidName("نام\u0000نا معتبر"))
    println("PASS: 9 appearance profile rule checks")
}
