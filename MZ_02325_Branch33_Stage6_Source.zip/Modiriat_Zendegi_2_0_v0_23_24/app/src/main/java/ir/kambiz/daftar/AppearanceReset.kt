package ir.kambiz.daftar

/** Only presentation preferences are reset. Saved profiles, admin policy, and business data are deliberately excluded. */
object AppearanceReset {
    val preferenceKeys: Set<String> = setOf(
        "customization_mode", "theme", "home_layout", "icon_style",
        "ticker_enabled", "motion_enabled", "auto_night",
        "appearance_schedule_mode", "appearance_night_start", "appearance_night_end",
        "ticker_color", "ticker_size", "ticker_speed", "ticker_moving", "ticker_position", "ticker_messages",
        "appearance_background_uri", "appearance_background_alpha", "launcher_icon",
        "widget_order", "widget_hidden", "focus_mode", "senior_mode", "dashboard_page", "font_scale"
    )

    fun shouldReset(key: String): Boolean = key in preferenceKeys
}
