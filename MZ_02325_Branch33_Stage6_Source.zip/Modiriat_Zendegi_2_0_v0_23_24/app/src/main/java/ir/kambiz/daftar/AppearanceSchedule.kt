package ir.kambiz.daftar

/** Pure scheduling rules for the appearance night palette. Minutes are local-device minutes since midnight. */
object AppearanceSchedule {
    const val MODE_OFF = "off"
    const val MODE_SCHEDULED = "scheduled"

    fun isNight(mode: String, startMinute: Int, endMinute: Int, currentMinute: Int): Boolean {
        if (mode != MODE_SCHEDULED) return false
        if (startMinute !in 0..1439 || endMinute !in 0..1439 || currentMinute !in 0..1439) return false
        if (startMinute == endMinute) return false
        return if (startMinute < endMinute) {
            currentMinute >= startMinute && currentMinute < endMinute
        } else {
            currentMinute >= startMinute || currentMinute < endMinute
        }
    }

    fun formatTime(minutes: Int): String {
        val safe = minutes.coerceIn(0, 1439)
        return "%02d:%02d".format(safe / 60, safe % 60)
    }
}
