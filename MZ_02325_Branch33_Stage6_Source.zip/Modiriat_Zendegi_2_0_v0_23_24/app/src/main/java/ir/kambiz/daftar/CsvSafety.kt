package ir.kambiz.daftar

/** Utilities for producing CSV files that are safer to open in spreadsheet applications. */
internal object CsvSafety {
    /**
     * Prefixes spreadsheet formula-leading text with an apostrophe.
     * Leading whitespace is considered because spreadsheet programs may ignore it
     * when deciding whether a cell contains a formula.
     */
    fun protectSpreadsheetFormula(value: String): String {
        val firstMeaningful = value.firstOrNull { !it.isWhitespace() }
        return if (firstMeaningful in setOf('=', '+', '-', '@')) "'$value" else value
    }

    /** RFC-4180-style quoted CSV cell with formula protection. */
    fun cell(value: String): String =
        "\"${protectSpreadsheetFormula(value).replace("\"", "\"\"")}\""
}
