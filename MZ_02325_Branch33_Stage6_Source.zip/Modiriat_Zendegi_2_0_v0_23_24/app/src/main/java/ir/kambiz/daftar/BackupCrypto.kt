package ir.kambiz.daftar

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.security.GeneralSecurityException
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Authenticated encryption envelope for backup payloads. This helper is intentionally
 * independent of ZIP/SAF UI so legacy unencrypted backup handling remains unchanged
 * until the complete password workflow is integrated and reviewed. */
object BackupCrypto {
    private val MAGIC = byteArrayOf(0x4d, 0x5a, 0x42, 0x45, 0x4e, 0x43, 0x30, 0x31) // MZBENC01
    private const val SALT_BYTES = 16
    private const val NONCE_BYTES = 12
    private const val KEY_BITS = 256
    private const val GCM_TAG_BITS = 128
    private const val PBKDF2_ITERATIONS = 210_000
    private const val MIN_PASSWORD_CHARS = 8
    private const val MAX_PAYLOAD_BYTES = 512 * 1024 * 1024

    @JvmStatic
    fun encrypt(plainText: ByteArray, password: CharArray): ByteArray {
        require(plainText.size <= MAX_PAYLOAD_BYTES) { "Backup payload is too large" }
        validatePassword(password)
        val random = SecureRandom()
        val salt = ByteArray(SALT_BYTES).also(random::nextBytes)
        val nonce = ByteArray(NONCE_BYTES).also(random::nextBytes)
        val header = MAGIC + salt + nonce
        val key = deriveKey(password, salt)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonce))
            cipher.updateAAD(header)
            val encrypted = cipher.doFinal(plainText)
            ByteArrayOutputStream(header.size + encrypted.size).apply {
                write(header)
                write(encrypted)
            }.toByteArray()
        } finally {
            key.encoded?.fill(0)
        }
    }

    @JvmStatic
    fun decrypt(envelope: ByteArray, password: CharArray): ByteArray {
        validatePassword(password)
        val headerSize = MAGIC.size + SALT_BYTES + NONCE_BYTES
        require(envelope.size >= headerSize + 16) { "Encrypted backup is truncated" }
        require(envelope.size <= MAX_PAYLOAD_BYTES + headerSize + 16) { "Encrypted backup is too large" }
        require(envelope.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) { "Unknown encrypted backup format" }
        val saltStart = MAGIC.size
        val nonceStart = saltStart + SALT_BYTES
        val salt = envelope.copyOfRange(saltStart, nonceStart)
        val nonce = envelope.copyOfRange(nonceStart, headerSize)
        val header = envelope.copyOfRange(0, headerSize)
        val encrypted = envelope.copyOfRange(headerSize, envelope.size)
        val key = deriveKey(password, salt)
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonce))
            cipher.updateAAD(header)
            cipher.doFinal(encrypted)
        } catch (e: AEADBadTagException) {
            throw GeneralSecurityException("Password is incorrect or backup was modified", e)
        } finally {
            key.encoded?.fill(0)
        }
    }

    fun isEncrypted(envelope: ByteArray): Boolean =
        envelope.size >= MAGIC.size && envelope.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)

    private fun validatePassword(password: CharArray) {
        require(password.size >= MIN_PASSWORD_CHARS) { "Password must contain at least 8 characters" }
    }

    private fun deriveKey(password: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, PBKDF2_ITERATIONS, KEY_BITS)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            try { SecretKeySpec(bytes, "AES") } finally { bytes.fill(0) }
        } finally {
            spec.clearPassword()
        }
    }
}
