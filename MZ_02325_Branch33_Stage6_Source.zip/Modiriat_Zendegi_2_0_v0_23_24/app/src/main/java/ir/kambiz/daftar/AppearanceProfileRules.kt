package ir.kambiz.daftar

import java.text.Normalizer
import java.util.Locale

/** Pure validation and normalization rules shared by saved appearance profiles. */
object AppearanceProfileRules {
    fun normalizeName(value: String): String {
        val normalized = Normalizer.normalize(value.trim(), Normalizer.Form.NFKC)
            .lowercase(Locale.ROOT)
        val out = StringBuilder()
        normalized.forEach { ch ->
            when (ch) {
                '\u200c', '\u200d', '\u200e', '\u200f', '\u061c', '\ufeff',
                '\u0640', '\u064b', '\u064c', '\u064d', '\u064e', '\u064f',
                '\u0650', '\u0651', '\u0652', '\u0653', '\u0654', '\u0655' -> Unit
                'ي' -> out.append('ی')
                'ك' -> out.append('ک')
                'ة' -> out.append('ه')
                else -> if (ch.isWhitespace()) out.append(' ') else out.append(ch)
            }
        }
        return out.toString().replace("\\s+".toRegex(), " ").trim()
    }

    fun isValidName(name: String): Boolean {
        val value = name.trim()
        val count = value.codePointCount(0, value.length)
        return count in 1..40 && value.none { it.isISOControl() }
    }
}
