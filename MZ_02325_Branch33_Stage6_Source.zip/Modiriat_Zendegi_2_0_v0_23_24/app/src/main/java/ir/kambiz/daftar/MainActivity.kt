package ir.kambiz.daftar

import android.app.*
import android.animation.ValueAnimator
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.pdf.PdfDocument
import android.provider.ContactsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.text.DecimalFormat
import java.math.BigInteger
import java.util.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import java.io.ByteArrayInputStream
import android.util.Base64
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import android.database.DatabaseUtils
import org.json.JSONObject
import org.json.JSONArray
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class Person(val id: Long, val name: String, val phone: String, val address: String, val relation: String, val notes: String, val photoData: String, val balance: Long, val receivable: Long, val payable: Long, val secondPhone:String="", val nationalId:String="", val birthDate:String="", val job:String="", val workplace:String="", val source:String="", val rating:String="", val tags:String="", val location:String="", val fatherName:String="", val landline:String="", val email:String="", val groupName:String="سایر افراد و طرف‌حساب‌ها", val roles:String="")
data class Tx(val id: Long, val personId: Long?, val personName: String, val kind: String, val amount: Long, val note: String, val createdAt: Long, val account: String)
data class Summary(val income: Long, val expense: Long, val balance: Long, val receivable: Long, val payable: Long)
data class PersonOpening(val id: Long, val personId: Long, val amount: Long, val balanceType: String, val baseDate: Long, val description: String, val createdAt: Long)

class LedgerDb(ctx: Context) : SQLiteOpenHelper(ctx, "ledger.db", null, DATABASE_VERSION) {
    companion object {
        const val DATABASE_VERSION = 13
    }
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', address TEXT DEFAULT '', relation TEXT DEFAULT '', notes TEXT DEFAULT '', photo_data TEXT DEFAULT '', is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, display_mode INTEGER NOT NULL DEFAULT 4)")
        createTransactions(db)
        db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target TEXT NOT NULL, target_id INTEGER, details TEXT DEFAULT '', created_at INTEGER NOT NULL)")
        createAccounts(db)
        createTransfers(db)
        createPersonOpeningBalances(db)
        createPeopleExtras(db)
        createFinanceExtras(db)
        createPersonConnections(db)
        createInventoryAndInvoices(db)
        createInvoiceItems(db)
        db.execSQL("CREATE INDEX idx_tx_date ON transactions(created_at)")
        db.execSQL("CREATE INDEX idx_tx_person ON transactions(person_id)")
    }
    private fun createTransactions(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NULL, kind TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), note TEXT DEFAULT '', created_at INTEGER NOT NULL, account TEXT DEFAULT 'نقدی', is_deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(person_id) REFERENCES people(id))")
    }
    private fun createAccounts(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS finance_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, opening_balance INTEGER NOT NULL DEFAULT 0, opening_at INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("INSERT OR IGNORE INTO finance_accounts(name,created_at) VALUES('نقدی',?)", arrayOf(System.currentTimeMillis()))
    }
    private fun createTransfers(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS account_transfers(id INTEGER PRIMARY KEY AUTOINCREMENT, from_account TEXT NOT NULL, to_account TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), note TEXT DEFAULT '', created_at INTEGER NOT NULL, is_deleted INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transfer_date ON account_transfers(created_at)")
    }
    private fun createPersonOpeningBalances(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS person_opening_balances(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, amount INTEGER NOT NULL CHECK(amount>=0), balance_type TEXT NOT NULL CHECK(balance_type IN ('طلب','بدهی')), base_date INTEGER NOT NULL, description TEXT DEFAULT '', is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_person_opening_active ON person_opening_balances(person_id) WHERE is_active=1")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_opening_history ON person_opening_balances(person_id,created_at)")
    }
    private fun createPeopleExtras(db:SQLiteDatabase) {
        val columns=mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(people)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
        val additions=linkedMapOf("second_phone" to "TEXT DEFAULT ''", "national_id" to "TEXT DEFAULT ''", "birth_date" to "TEXT DEFAULT ''", "job" to "TEXT DEFAULT ''", "workplace" to "TEXT DEFAULT ''", "source" to "TEXT DEFAULT ''", "credit_rating" to "TEXT DEFAULT ''", "tags" to "TEXT DEFAULT ''", "location" to "TEXT DEFAULT ''", "father_name" to "TEXT DEFAULT ''", "landline" to "TEXT DEFAULT ''", "email" to "TEXT DEFAULT ''", "group_name" to "TEXT DEFAULT 'سایر افراد و طرف‌حساب‌ها'", "roles" to "TEXT DEFAULT ''")
        additions.forEach { (name,type) -> if(!columns.contains(name)) db.execSQL("ALTER TABLE people ADD COLUMN $name $type") }
        db.execSQL("CREATE TABLE IF NOT EXISTS person_documents(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, title TEXT NOT NULL, mime_type TEXT DEFAULT 'image/jpeg', data TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE TABLE IF NOT EXISTS person_reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, title TEXT NOT NULL, note TEXT DEFAULT '', remind_at INTEGER NOT NULL, is_done INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_docs ON person_documents(person_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_reminders ON person_reminders(remind_at,is_done)")
    }
    private fun createFinanceExtras(db: SQLiteDatabase) {
        val accountColumns=mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(finance_accounts)",null).use { c -> while(c.moveToNext()) accountColumns.add(c.getString(1)) }
        val accountAdditions=linkedMapOf("bank_name" to "TEXT DEFAULT ''", "account_type" to "TEXT DEFAULT 'صندوق'", "account_number" to "TEXT DEFAULT ''", "card_number" to "TEXT DEFAULT ''", "iban" to "TEXT DEFAULT ''", "owner_name" to "TEXT DEFAULT ''", "owner_person_id" to "INTEGER", "is_active" to "INTEGER NOT NULL DEFAULT 1", "notes" to "TEXT DEFAULT ''")
        accountAdditions.forEach { (name,type) -> if(!accountColumns.contains(name)) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN $name $type") }
        db.execSQL("CREATE TABLE IF NOT EXISTS tx_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT, tx_id INTEGER NOT NULL, method TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), reference TEXT DEFAULT '', details TEXT DEFAULT '', created_at INTEGER NOT NULL, FOREIGN KEY(tx_id) REFERENCES transactions(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_settlement_tx ON tx_settlements(tx_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS tx_documents(id INTEGER PRIMARY KEY AUTOINCREMENT, tx_id INTEGER NOT NULL, title TEXT NOT NULL, mime_type TEXT DEFAULT 'image/jpeg', data TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(tx_id) REFERENCES transactions(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_documents ON tx_documents(tx_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS financial_instruments(id INTEGER PRIMARY KEY AUTOINCREMENT, tx_id INTEGER, person_id INTEGER, instrument_type TEXT NOT NULL, number TEXT DEFAULT '', bank TEXT DEFAULT '', issuer TEXT DEFAULT '', amount INTEGER NOT NULL CHECK(amount>0), issued_at INTEGER NOT NULL, due_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'در انتظار', notes TEXT DEFAULT '', is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, FOREIGN KEY(tx_id) REFERENCES transactions(id), FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_instrument_due ON financial_instruments(due_at,status,is_deleted)")
        db.execSQL("CREATE TABLE IF NOT EXISTS installment_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, title TEXT NOT NULL, total_amount INTEGER NOT NULL CHECK(total_amount>0), installment_amount INTEGER NOT NULL CHECK(installment_amount>0), interval_days INTEGER NOT NULL DEFAULT 30, start_at INTEGER NOT NULL, next_due INTEGER NOT NULL, paid_amount INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'فعال', notes TEXT DEFAULT '', created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_installment_due ON installment_plans(next_due,status)")
        db.execSQL("CREATE TABLE IF NOT EXISTS account_reconciliations(id INTEGER PRIMARY KEY AUTOINCREMENT, account TEXT NOT NULL, from_at INTEGER NOT NULL, to_at INTEGER NOT NULL, book_balance INTEGER NOT NULL, statement_balance INTEGER NOT NULL, difference INTEGER NOT NULL, status TEXT NOT NULL, notes TEXT DEFAULT '', created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS account_opening_history(id INTEGER PRIMARY KEY AUTOINCREMENT, account TEXT NOT NULL, old_balance INTEGER NOT NULL, old_at INTEGER NOT NULL, new_balance INTEGER NOT NULL, new_at INTEGER NOT NULL, reason TEXT DEFAULT '', changed_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE people ADD COLUMN address TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN relation TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN notes TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE people ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0")
            createTransactions(db)
            db.execSQL("INSERT INTO transactions(person_id,kind,amount,note,created_at) SELECT e.person_id,e.kind,e.amount,e.note,e.created_at FROM entries e")
            db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target TEXT NOT NULL, target_id INTEGER, details TEXT DEFAULT '', created_at INTEGER NOT NULL)")
            db.execSQL("CREATE INDEX idx_tx_date ON transactions(created_at)")
            db.execSQL("CREATE INDEX idx_tx_person ON transactions(person_id)")
        }
        if (oldVersion < 3) {
            createAccounts(db)
            db.execSQL("INSERT OR IGNORE INTO finance_accounts(name,created_at) SELECT DISTINCT CASE WHEN TRIM(COALESCE(account,''))='' THEN 'نقدی' ELSE account END, ? FROM transactions", arrayOf(System.currentTimeMillis()))
        }
        if (oldVersion < 4) {
            val columns=mutableSetOf<String>()
            db.rawQuery("PRAGMA table_info(finance_accounts)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
            if(!columns.contains("opening_balance")) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN opening_balance INTEGER NOT NULL DEFAULT 0")
            if(!columns.contains("opening_at")) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN opening_at INTEGER NOT NULL DEFAULT 0")
            createTransfers(db)
        }
        if (oldVersion < 5) {
            createPersonOpeningBalances(db)
        }
        if (oldVersion < 6) {
            val columns=mutableSetOf<String>()
            db.rawQuery("PRAGMA table_info(people)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
            if(!columns.contains("display_mode")) db.execSQL("ALTER TABLE people ADD COLUMN display_mode INTEGER NOT NULL DEFAULT 4")
        }
        if (oldVersion < 7) {
            val columns=mutableSetOf<String>()
            db.rawQuery("PRAGMA table_info(people)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
            if(!columns.contains("photo_data")) db.execSQL("ALTER TABLE people ADD COLUMN photo_data TEXT DEFAULT ''")
        }
        if(oldVersion < 8) createPeopleExtras(db)
        if(oldVersion < 9) createPeopleExtras(db)
        if(oldVersion < 10) createFinanceExtras(db)
        if(oldVersion < 11) createPersonConnections(db)
        if(oldVersion < 12) createInventoryAndInvoices(db)
        if(oldVersion < 13) createInvoiceItems(db)
    }
    private fun createInventoryAndInvoices(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS inventory_products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sku TEXT DEFAULT '', unit TEXT NOT NULL DEFAULT 'عدد', purchase_price INTEGER NOT NULL DEFAULT 0, sale_price INTEGER NOT NULL DEFAULT 0, stock_qty REAL NOT NULL DEFAULT 0, min_stock REAL NOT NULL DEFAULT 0, is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_product_sku_active ON inventory_products(sku) WHERE sku<>'' AND is_deleted=0")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_product_name ON inventory_products(name)")
        db.execSQL("CREATE TABLE IF NOT EXISTS inventory_movements(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, qty_delta REAL NOT NULL, unit_price INTEGER NOT NULL DEFAULT 0, movement_type TEXT NOT NULL, reference TEXT DEFAULT '', note TEXT DEFAULT '', created_at INTEGER NOT NULL, FOREIGN KEY(product_id) REFERENCES inventory_products(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_inventory_movements_product ON inventory_movements(product_id,created_at)")
        db.execSQL("CREATE TABLE IF NOT EXISTS invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL UNIQUE, invoice_type TEXT NOT NULL CHECK(invoice_type IN ('خرید','فروش')), person_id INTEGER, created_at INTEGER NOT NULL, product_id INTEGER NOT NULL, product_name TEXT NOT NULL, unit TEXT NOT NULL, quantity REAL NOT NULL CHECK(quantity>0), unit_price INTEGER NOT NULL CHECK(unit_price>=0), subtotal INTEGER NOT NULL, discount INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL, paid INTEGER NOT NULL DEFAULT 0, note TEXT DEFAULT '', is_deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(person_id) REFERENCES people(id), FOREIGN KEY(product_id) REFERENCES inventory_products(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_invoices_date ON invoices(created_at,is_deleted)")
    }
    private fun createInvoiceItems(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS invoice_items(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER NOT NULL, product_id INTEGER NOT NULL, product_name TEXT NOT NULL, unit TEXT NOT NULL, quantity REAL NOT NULL CHECK(quantity>0), unit_price INTEGER NOT NULL CHECK(unit_price>=0), subtotal INTEGER NOT NULL, discount INTEGER NOT NULL DEFAULT 0, line_total INTEGER NOT NULL, FOREIGN KEY(invoice_id) REFERENCES invoices(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES inventory_products(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice ON invoice_items(invoice_id)")
        // Backfill legacy one-product invoices without changing their totals or stock movements.
        db.execSQL("INSERT INTO invoice_items(invoice_id,product_id,product_name,unit,quantity,unit_price,subtotal,discount,line_total) SELECT i.id,i.product_id,i.product_name,i.unit,i.quantity,i.unit_price,i.subtotal,i.discount,i.total FROM invoices i WHERE NOT EXISTS(SELECT 1 FROM invoice_items x WHERE x.invoice_id=i.id)")
    }
    data class InvoiceLine(val productId: Long, val quantity: Double, val unitPrice: Long, val discount: Long = 0)
    fun createMultiInvoice(type: String, personId: Long?, lines: List<InvoiceLine>, invoiceDiscount: Long, paid: Long, note: String, date: Long): Pair<Long, Long> {
        require(type == "خرید" || type == "فروش")
        require(lines.isNotEmpty()) { "حداقل یک قلم کالا لازم است" }
        require(invoiceDiscount >= 0 && paid >= 0) { "مبلغ تخفیف یا پرداخت معتبر نیست" }
        val d = writableDatabase
        d.beginTransaction()
        try {
            var subtotalAll = 0L
            var lineDiscountAll = 0L
            val resolved = lines.map { line ->
                require(line.quantity > 0 && line.unitPrice >= 0 && line.discount >= 0) { "مقدار یا قیمت یکی از اقلام معتبر نیست" }
                val product = d.rawQuery("SELECT name,unit,stock_qty FROM inventory_products WHERE id=? AND is_deleted=0", arrayOf(line.productId.toString())).use { c ->
                    if (!c.moveToFirst()) throw IllegalArgumentException("یکی از کالاها پیدا نشد")
                    Triple(c.getString(0), c.getString(1), c.getDouble(2))
                }
                val sub = (line.quantity * line.unitPrice).toLong()
                require(line.discount <= sub) { "تخفیف یک قلم از مبلغ همان قلم بیشتر است" }
                subtotalAll += sub; lineDiscountAll += line.discount
                Triple(line, product, sub)
            }
            val beforeInvoiceDiscount = subtotalAll - lineDiscountAll
            require(invoiceDiscount <= beforeInvoiceDiscount) { "تخفیف کل از مبلغ فاکتور بیشتر است" }
            val total = beforeInvoiceDiscount - invoiceDiscount
            require(paid <= total) { "مبلغ تسویه از مبلغ نهایی بیشتر است" }
            resolved.forEach { (line, product, _) ->
                val delta = if (type == "خرید") line.quantity else -line.quantity
                require(product.third + delta >= 0) { "موجودی ${product.first} برای فروش کافی نیست" }
            }
            val first = resolved.first()
            val no = "${if (type == "خرید") "KH" else "FR"}-${System.currentTimeMillis()}"
            val invoiceId = d.insertOrThrow("invoices", null, android.content.ContentValues().apply {
                put("invoice_no", no); put("invoice_type", type); if (personId == null) putNull("person_id") else put("person_id", personId)
                put("created_at", date); put("product_id", first.first.productId); put("product_name", "${resolved.size} قلم کالا"); put("unit", first.second.second)
                put("quantity", resolved.sumOf { it.first.quantity }); put("unit_price", 0); put("subtotal", subtotalAll)
                put("discount", lineDiscountAll + invoiceDiscount); put("total", total); put("paid", paid); put("note", note)
            })
            resolved.forEach { (line, product, sub) ->
                val lineTotal = sub - line.discount
                d.insertOrThrow("invoice_items", null, android.content.ContentValues().apply {
                    put("invoice_id", invoiceId); put("product_id", line.productId); put("product_name", product.first); put("unit", product.second)
                    put("quantity", line.quantity); put("unit_price", line.unitPrice); put("subtotal", sub); put("discount", line.discount); put("line_total", lineTotal)
                })
                val delta = if (type == "خرید") line.quantity else -line.quantity
                d.execSQL("UPDATE inventory_products SET stock_qty=stock_qty+?, purchase_price=CASE WHEN ?='خرید' THEN ? ELSE purchase_price END, sale_price=CASE WHEN ?='فروش' THEN ? ELSE sale_price END WHERE id=?", arrayOf(delta, type, line.unitPrice, type, line.unitPrice, line.productId))
                d.execSQL("INSERT INTO inventory_movements(product_id,qty_delta,unit_price,movement_type,reference,note,created_at) VALUES(?,?,?,?,?,?,?)", arrayOf(line.productId, delta, line.unitPrice, type, "فاکتور $no", note, date))
            }
            audit("ثبت فاکتور چندقلمی $type", "فاکتور", invoiceId, "$no • ${resolved.size} قلم • $total")
            d.setTransactionSuccessful()
            return Pair(invoiceId, total)
        } finally { d.endTransaction() }
    }
    fun invoiceItems(invoiceId: Long): List<Array<Any>> {
        val out = mutableListOf<Array<Any>>()
        readableDatabase.rawQuery("SELECT product_name,quantity,unit,unit_price,discount,line_total FROM invoice_items WHERE invoice_id=? ORDER BY id", arrayOf(invoiceId.toString())).use { c ->
            while (c.moveToNext()) out.add(arrayOf(c.getString(0), c.getDouble(1), c.getString(2), c.getLong(3), c.getLong(4), c.getLong(5)))
        }
        return out
    }
    fun products(): List<Array<Any>> {
        val out=mutableListOf<Array<Any>>()
        readableDatabase.rawQuery("SELECT id,name,sku,unit,purchase_price,sale_price,stock_qty,min_stock FROM inventory_products WHERE is_deleted=0 ORDER BY name COLLATE NOCASE",null).use { c -> while(c.moveToNext()) out.add(arrayOf(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getLong(5),c.getDouble(6),c.getDouble(7))) }
        return out
    }
    fun addProduct(name:String,sku:String,unit:String,buy:Long,sell:Long,opening:Double,min:Double):Long {
        require(name.isNotBlank() && buy>=0 && sell>=0 && opening>=0 && min>=0) { "اطلاعات کالا معتبر نیست" }
        val d=writableDatabase; val id=d.insertOrThrow("inventory_products",null,android.content.ContentValues().apply { put("name",name.trim());put("sku",sku.trim());put("unit",unit.trim().ifBlank{"عدد"});put("purchase_price",buy);put("sale_price",sell);put("stock_qty",opening);put("min_stock",min);put("created_at",System.currentTimeMillis()) })
        if(opening>0) d.execSQL("INSERT INTO inventory_movements(product_id,qty_delta,unit_price,movement_type,reference,note,created_at) VALUES(?,?,?,'موجودی اول دوره','افتتاحیه','ثبت موجودی اولیه',?)",arrayOf(id,opening,buy,System.currentTimeMillis()))
        audit("تعریف کالا","انبار",id,name); return id
    }
    fun adjustStock(productId:Long,delta:Double,price:Long,note:String) {
        require(delta!=0.0 && price>=0) { "مقدار یا قیمت معتبر نیست" }
        val d=writableDatabase;d.beginTransaction();try {
            val current=DatabaseUtils.longForQuery(d,"SELECT CAST(stock_qty*1000 AS INTEGER) FROM inventory_products WHERE id=? AND is_deleted=0",arrayOf(productId.toString()))/1000.0
            require(current+delta>=0) { "موجودی کالا کافی نیست" }
            d.execSQL("UPDATE inventory_products SET stock_qty=stock_qty+? WHERE id=?",arrayOf(delta,productId))
            d.execSQL("INSERT INTO inventory_movements(product_id,qty_delta,unit_price,movement_type,note,created_at) VALUES(?,?,?,'اصلاح دستی',?,?)",arrayOf(productId,delta,price,note,System.currentTimeMillis()))
            audit("اصلاح موجودی کالا","انبار",productId,"$delta؛ $note");d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun createInvoice(type:String,personId:Long?,productId:Long,quantity:Double,unitPrice:Long,discount:Long,paid:Long,note:String,date:Long):Pair<Long,Long> {
        require(type=="خرید" || type=="فروش")
        require(quantity>0 && unitPrice>=0 && discount>=0 && discount <= (quantity*unitPrice).toLong() && paid>=0 && paid <= (quantity*unitPrice).toLong()-discount) { "تخفیف نباید از مبلغ فاکتور بیشتر باشد" }
        val d=writableDatabase;d.beginTransaction();try {
            val p=d.rawQuery("SELECT name,unit,stock_qty FROM inventory_products WHERE id=? AND is_deleted=0",arrayOf(productId.toString())).use { c -> if(!c.moveToFirst()) throw IllegalArgumentException("کالا پیدا نشد"); Triple(c.getString(0),c.getString(1),c.getDouble(2)) }
            val delta=if(type=="خرید")quantity else -quantity
            require(p.third+delta>=0) { "موجودی برای فروش کافی نیست" }
            val subtotal=(quantity*unitPrice).toLong();val total=(subtotal-discount).coerceAtLeast(0L)
            val no="${if(type=="خرید")"KH" else "FR"}-${System.currentTimeMillis()}"
            val id=d.insertOrThrow("invoices",null,android.content.ContentValues().apply { put("invoice_no",no);put("invoice_type",type);if(personId==null)putNull("person_id")else put("person_id",personId);put("created_at",date);put("product_id",productId);put("product_name",p.first);put("unit",p.second);put("quantity",quantity);put("unit_price",unitPrice);put("subtotal",subtotal);put("discount",discount);put("total",total);put("paid",paid);put("note",note) })
            d.execSQL("UPDATE inventory_products SET stock_qty=stock_qty+?, purchase_price=CASE WHEN ?='خرید' THEN ? ELSE purchase_price END, sale_price=CASE WHEN ?='فروش' THEN ? ELSE sale_price END WHERE id=?",arrayOf(delta,type,unitPrice,type,unitPrice,productId))
            d.execSQL("INSERT INTO inventory_movements(product_id,qty_delta,unit_price,movement_type,reference,note,created_at) VALUES(?,?,?,?,?,?,?)",arrayOf(productId,delta,unitPrice,type,"فاکتور $no",note,date))
            audit("ثبت فاکتور $type","فاکتور",id,"$no • ${p.first} • $quantity ${p.second} • $total")
            d.setTransactionSuccessful();return Pair(id,total)
        } finally { d.endTransaction() }
    }
    fun invoices():List<Array<Any>> {
        val out=mutableListOf<Array<Any>>();readableDatabase.rawQuery("SELECT i.id,i.invoice_no,i.invoice_type,COALESCE(p.name,''),i.product_name,i.quantity,i.unit,i.total,i.created_at FROM invoices i LEFT JOIN people p ON p.id=i.person_id WHERE i.is_deleted=0 ORDER BY i.created_at DESC",null).use{c->while(c.moveToNext())out.add(arrayOf(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getDouble(5),c.getString(6),c.getLong(7),c.getLong(8)))};return out
    }
    fun invoicesCsv():String {
        val out=StringBuilder()
        out.append(listOf("شماره فاکتور","نوع","طرف حساب","تاریخ شمسی","نام کالا","مقدار","واحد کالا","قیمت واحد","تخفیف قلم","جمع قلم","مجموع تخفیف فاکتور","مبلغ نهایی","مبلغ پرداخت‌شده","واحد پول","توضیحات").joinToString(",", transform=CsvSafety::cell)).append("\r\n")
        readableDatabase.rawQuery("SELECT i.id,i.invoice_no,i.invoice_type,COALESCE(p.name,''),i.created_at,i.product_id,i.product_name,i.unit,i.quantity,i.unit_price,i.subtotal,i.discount,i.total,i.paid,COALESCE(i.note,'') FROM invoices i LEFT JOIN people p ON p.id=i.person_id WHERE i.is_deleted=0 ORDER BY i.created_at DESC,i.id DESC",null).use { invoices ->
            while(invoices.moveToNext()) {
                val id=invoices.getLong(0);val no=invoices.getString(1) ?: "";val type=invoices.getString(2) ?: "";val person=invoices.getString(3) ?: ""
                val date=jalali(invoices.getLong(4));val legacyProduct=invoices.getString(6) ?: "";val legacyUnit=invoices.getString(7) ?: ""
                val legacyQty=invoices.getDouble(8);val legacyPrice=invoices.getLong(9);val discount=invoices.getLong(11);val total=invoices.getLong(12);val paid=invoices.getLong(13);val note=invoices.getString(14) ?: ""
                var wroteLine=false
                var firstLine=true
                readableDatabase.rawQuery("SELECT product_name,quantity,unit,unit_price,discount,line_total FROM invoice_items WHERE invoice_id=? ORDER BY id",arrayOf(id.toString())).use { items ->
                    while(items.moveToNext()) {
                        wroteLine=true
                        val values=listOf(no,type,person,date,items.getString(0) ?: "",java.lang.String.format(java.util.Locale.ROOT,"%.3f",items.getDouble(1)).trimEnd('0').trimEnd('.'),items.getString(2) ?: "",items.getLong(3).toString(),items.getLong(4).toString(),items.getLong(5).toString(),if(firstLine)discount.toString() else "",if(firstLine)total.toString() else "",if(firstLine)paid.toString() else "",if(firstLine)moneyUnit() else "",if(firstLine)note else "")
                        out.append(values.joinToString(",",transform=CsvSafety::cell)).append("\r\n")
                        firstLine=false
                    }
                }
                if(!wroteLine) {
                    val values=listOf(no,type,person,date,legacyProduct,java.lang.String.format(java.util.Locale.ROOT,"%.3f",legacyQty).trimEnd('0').trimEnd('.'),legacyUnit,legacyPrice.toString(),discount.toString(),invoices.getLong(10).toString(),discount.toString(),total.toString(),paid.toString(),moneyUnit(),note)
                    out.append(values.joinToString(",",transform=CsvSafety::cell)).append("\r\n")
                }
            }
        }
        return out.toString()
    }
    private fun createPersonConnections(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS person_section_links(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, section_key TEXT NOT NULL, relation_label TEXT DEFAULT '', linked_record_id INTEGER, notes TEXT DEFAULT '', created_at INTEGER NOT NULL, is_deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_section_links_person ON person_section_links(person_id,is_deleted)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_section_links_section ON person_section_links(section_key,is_deleted)")
        db.execSQL("CREATE TABLE IF NOT EXISTS section_person_field_settings(id INTEGER PRIMARY KEY AUTOINCREMENT, section_key TEXT NOT NULL, field_key TEXT NOT NULL, field_label TEXT NOT NULL, is_visible INTEGER NOT NULL DEFAULT 1, display_order INTEGER NOT NULL DEFAULT 0, is_required INTEGER NOT NULL DEFAULT 0, allow_edit INTEGER NOT NULL DEFAULT 0, UNIQUE(section_key,field_key))")
        val sections = linkedMapOf(
            "finance" to "امور مالی و حسابداری", "ledger" to "دفتر حساب", "invoices" to "فاکتورها و صورتحساب‌ها",
            "sales" to "خرید و فروش", "contracts" to "قراردادها و تعهدات", "instruments" to "چک، سفته و اقساط",
            "bank_accounts" to "حساب‌های بانکی", "family" to "خانواده و بستگان", "friends" to "دوستان و آشنایان",
            "reminders" to "یادآوری‌ها و پیگیری‌ها", "documents" to "اسناد و مدارک", "other" to "سایر بخش‌ها"
        )
        val fields = listOf("name" to "نام و نام خانوادگی", "national_id" to "کد ملی / شناسه", "phone" to "شماره تماس اصلی", "second_phone" to "شماره تماس دوم", "landline" to "تلفن ثابت", "email" to "ایمیل", "address" to "نشانی", "job" to "شغل", "workplace" to "محل کار", "roles" to "نقش‌ها", "group_name" to "گروه اصلی")
        sections.forEach { (key, _) -> fields.forEachIndexed { index, f ->
            db.execSQL("INSERT OR IGNORE INTO section_person_field_settings(section_key,field_key,field_label,is_visible,display_order,is_required,allow_edit) VALUES(?,?,?,?,?,?,?)", arrayOf(key,f.first,f.second,1,index,if(f.first=="name")1 else 0,0))
        } }
    }
    fun addPersonSectionLink(personId:Long, sectionKey:String, relationLabel:String, notes:String=""):Long {
        val existing=DatabaseUtils.longForQuery(readableDatabase,"SELECT COALESCE(MAX(id),0) FROM person_section_links WHERE person_id=? AND section_key=? AND is_deleted=0",arrayOf(personId.toString(),sectionKey))
        if(existing>0L) return existing
        val id=writableDatabase.insertOrThrow("person_section_links",null,android.content.ContentValues().apply { put("person_id",personId);put("section_key",sectionKey);put("relation_label",relationLabel);put("notes",notes);put("created_at",System.currentTimeMillis()) })
        audit("اتصال پرونده شخص به بخش برنامه","شخص",personId,sectionKey+" • "+relationLabel)
        return id
    }
    fun personSectionLinks(personId:Long):List<Pair<String,String>> {
        val out=mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT section_key,relation_label FROM person_section_links WHERE person_id=? AND is_deleted=0 ORDER BY id DESC",arrayOf(personId.toString())).use { c -> while(c.moveToNext()) out.add(Pair(c.getString(0),c.getString(1) ?: "")) }
        return out
    }
    fun sectionPeople(sectionKey:String):List<Pair<Long,String>> {
        val out=mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT p.id,p.name,COALESCE(l.relation_label,'') FROM person_section_links l JOIN people p ON p.id=l.person_id WHERE l.section_key=? AND l.is_deleted=0 AND p.is_deleted=0 ORDER BY p.name COLLATE NOCASE",arrayOf(sectionKey)).use { c -> while(c.moveToNext()) out.add(Pair(c.getLong(0),c.getString(1)+if(c.getString(2).isNullOrBlank()) "" else " • "+c.getString(2))) }
        return out
    }
    fun hasPersonSectionLink(personId:Long,sectionKey:String):Boolean = DatabaseUtils.longForQuery(readableDatabase,"SELECT COUNT(*) FROM person_section_links WHERE person_id=? AND section_key=? AND is_deleted=0",arrayOf(personId.toString(),sectionKey))>0
    fun sectionFieldSettings(sectionKey:String):List<Triple<String,String,Boolean>> {
        val out=mutableListOf<Triple<String,String,Boolean>>()
        readableDatabase.rawQuery("SELECT field_key,field_label,is_visible FROM section_person_field_settings WHERE section_key=? ORDER BY display_order,id",arrayOf(sectionKey)).use { c -> while(c.moveToNext()) out.add(Triple(c.getString(0),c.getString(1),c.getInt(2)==1)) }
        return out
    }
    fun setSectionFieldVisible(sectionKey:String,fieldKey:String,visible:Boolean) {
        writableDatabase.execSQL("UPDATE section_person_field_settings SET is_visible=? WHERE section_key=? AND field_key=?",arrayOf(if(visible)1 else 0,sectionKey,fieldKey))
        audit("تنظیم نمایش فیلد اطلاعات شخص","تنظیم اتصال",-1L,sectionKey+" • "+fieldKey+" • "+visible)
    }
    override fun onOpen(db: SQLiteDatabase) { super.onOpen(db); db.setForeignKeyConstraintsEnabled(true) }
    fun accounts(includeInactive:Boolean=false): List<String> {
        val out= mutableListOf<String>()
        val sql=if(includeInactive)"SELECT name FROM finance_accounts WHERE is_deleted=0 ORDER BY id" else "SELECT name FROM finance_accounts WHERE is_deleted=0 AND is_active=1 ORDER BY id"
        readableDatabase.rawQuery(sql,null).use { c -> while(c.moveToNext()) out.add(c.getString(0)) }
        if(out.isEmpty()) out.add("نقدی")
        return out
    }
    fun addAccount(name:String,bank:String="",type:String="صندوق",number:String="",card:String="",iban:String="",owner:String="",ownerPersonId:Long?=null,notes:String=""): Boolean {
        val n=name.trim(); if(n.isEmpty()) return false
        return try { writableDatabase.insertOrThrow("finance_accounts",null,android.content.ContentValues().apply { put("name",n);put("bank_name",bank);put("account_type",type);put("account_number",number);put("card_number",card);put("iban",iban);put("owner_name",owner);if(ownerPersonId!=null)put("owner_person_id",ownerPersonId);put("notes",notes);put("created_at",System.currentTimeMillis()) }); audit("ایجاد","حساب مالی",-1,"$n • $bank • $type"); true } catch (_:Exception) { false }
    }
    fun accountDetails(name:String):String {
        readableDatabase.rawQuery("SELECT bank_name,account_type,account_number,card_number,iban,owner_name,notes FROM finance_accounts WHERE name=?",arrayOf(name)).use { c -> if(c.moveToFirst()) return listOf("بانک: ${c.getString(0) ?: ""}","نوع: ${c.getString(1) ?: ""}","شماره حساب: ${c.getString(2) ?: ""}","شماره کارت: ${c.getString(3) ?: ""}","شبا: ${c.getString(4) ?: ""}","صاحب حساب: ${c.getString(5) ?: ""}","توضیحات: ${c.getString(6) ?: ""}").filter{it.substringAfter(": ").isNotBlank()}.joinToString("\n") }
        return ""
    }
    fun setAccountActive(name:String,active:Boolean) { writableDatabase.execSQL("UPDATE finance_accounts SET is_active=? WHERE name=?",arrayOf(if(active)1 else 0,name));audit(if(active)"فعال‌سازی حساب" else "غیرفعال‌سازی حساب","حساب مالی",-1,name) }
    fun inactiveAccounts():List<String> { val out=mutableListOf<String>();readableDatabase.rawQuery("SELECT name FROM finance_accounts WHERE is_deleted=0 AND is_active=0 ORDER BY id",null).use{c->while(c.moveToNext())out.add(c.getString(0))};return out }
    fun accountIsActive(name:String):Boolean { readableDatabase.rawQuery("SELECT is_active FROM finance_accounts WHERE name=?",arrayOf(name)).use { c -> return c.moveToFirst() && c.getInt(0)==1 } }
    fun accountBalanceBefore(account:String, timestamp:Long):Long {
        var opening=0L; var openingAt=0L
        readableDatabase.rawQuery("SELECT opening_balance,opening_at FROM finance_accounts WHERE name=? AND is_deleted=0",arrayOf(account)).use { c -> if(c.moveToFirst()){opening=c.getLong(0);openingAt=c.getLong(1)} }
        if(openingAt>timestamp) return 0L
        var balance=opening
        val cashTotals=cashTotals(openingAt,timestamp,account)
        balance+=cashTotals.first-cashTotals.second
        readableDatabase.rawQuery("SELECT t.from_account,t.to_account,t.amount FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=CASE WHEN t.from_account=? THEN fa.opening_at ELSE ta.opening_at END AND t.created_at<? AND (t.from_account=? OR t.to_account=?)",arrayOf(account,timestamp.toString(),account,account)).use { c -> while(c.moveToNext()){val a=c.getLong(2);if(c.getString(0)==account)balance-=a else balance+=a} }
        return balance
    }
    fun cashTotals(start:Long,endExclusive:Long,account:String?=null):Pair<Long,Long> {
        var incoming=0L;var outgoing=0L
        val sql="SELECT t.id,t.kind,t.amount,(SELECT COUNT(*) FROM tx_settlements s WHERE s.tx_id=t.id),(SELECT COALESCE(SUM(CASE WHEN s.method IN ('نقدی','کارت‌به‌کارت','واریز بانکی') THEN s.amount WHEN s.method IN ('چک','سفته') AND EXISTS(SELECT 1 FROM financial_instruments i WHERE i.tx_id=t.id AND i.instrument_type=s.method AND i.amount=s.amount AND i.status IN ('وصول‌شده','پرداخت‌شده')) THEN s.amount ELSE 0 END),0) FROM tx_settlements s WHERE s.tx_id=t.id) FROM transactions t LEFT JOIN finance_accounts a ON a.name=t.account WHERE t.is_deleted=0 AND t.created_at>=? AND t.created_at<? AND t.created_at>=COALESCE(a.opening_at,0)"+(if(account==null)"" else " AND t.account=?")
        val args=if(account==null)arrayOf(start.toString(),endExclusive.toString()) else arrayOf(start.toString(),endExclusive.toString(),account)
        readableDatabase.rawQuery(sql,args).use { c -> while(c.moveToNext()) {
            val id=c.getLong(0);val kind=c.getString(1);val amount=c.getLong(2);val settlementCount=c.getInt(3);val settledCash=c.getLong(4)
            val cash=if(settlementCount==0) { if(kind in listOf("دریافت وجه","درآمد","پرداخت وجه","هزینه")) amount else 0L } else settledCash
            if(kind in listOf("دریافت وجه","درآمد","طلب","فروش نسیه","تحویل کالا")) incoming+=cash
            else if(kind in listOf("پرداخت وجه","هزینه","بدهی","خرید نسیه","دریافت کالا")) outgoing+=cash
        } }
        return Pair(incoming,outgoing)
    }
    fun accountBalances(includeInactive:Boolean=false): List<Pair<String,Long>> = accounts(includeInactive).map { Pair(it,accountBalanceBefore(it,Long.MAX_VALUE)) }
    fun setOpeningBalance(account:String,amount:Long,at:Long,reason:String="") {
        val d=writableDatabase
        val old=accountOpening(account)
        d.beginTransaction()
        try {
            d.execSQL("INSERT INTO account_opening_history(account,old_balance,old_at,new_balance,new_at,reason,changed_at) VALUES(?,?,?,?,?,?,?)",arrayOf(account,old.first,old.second,amount,at,reason,System.currentTimeMillis()))
            d.execSQL("UPDATE finance_accounts SET opening_balance=?,opening_at=? WHERE name=? AND is_deleted=0",arrayOf(amount,at,account))
            audit("ثبت/اصلاح مانده اول دوره","حساب مالی",-1,"$account: $old → $amount @ $at؛ $reason")
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun addTxDocument(txId:Long,title:String,data:String) { writableDatabase.execSQL("INSERT INTO tx_documents(tx_id,title,data,created_at) VALUES(?,?,?,?)",arrayOf(txId,title,data,System.currentTimeMillis()));audit("افزودن پیوست","تراکنش",txId,title) }
    fun txDocuments(txId:Long):List<Pair<Long,String>> { val out=mutableListOf<Pair<Long,String>>();readableDatabase.rawQuery("SELECT id,title FROM tx_documents WHERE tx_id=? ORDER BY id DESC",arrayOf(txId.toString())).use{c->while(c.moveToNext())out.add(Pair(c.getLong(0),c.getString(1)))};return out }
    fun txDocumentData(id:Long):String? { readableDatabase.rawQuery("SELECT data FROM tx_documents WHERE id=?",arrayOf(id.toString())).use{c->return if(c.moveToFirst())c.getString(0) else null} }
    fun deleteTxDocument(id:Long) { writableDatabase.delete("tx_documents","id=?",arrayOf(id.toString())) }
    fun addSettlement(txId:Long,method:String,amount:Long,reference:String,details:String) {
        require(amount>0) { "مبلغ تسویه باید بیشتر از صفر باشد" }
        writableDatabase.execSQL("INSERT INTO tx_settlements(tx_id,method,amount,reference,details,created_at) VALUES(?,?,?,?,?,?)",arrayOf(txId,method,amount,reference,details,System.currentTimeMillis()))
        audit("ثبت روش تسویه","تراکنش",txId,"$method: $amount؛ $reference؛ $details")
    }
    fun addInstrument(txId:Long?,personId:Long?,type:String,number:String,bank:String,issuer:String,amount:Long,issuedAt:Long,dueAt:Long,notes:String) {
        require(amount>0 && dueAt>=issuedAt) { "مبلغ یا سررسید ابزار مالی معتبر نیست" }
        writableDatabase.execSQL("INSERT INTO financial_instruments(tx_id,person_id,instrument_type,number,bank,issuer,amount,issued_at,due_at,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,'در انتظار',?,?)",arrayOf(txId,personId,type,number,bank,issuer,amount,issuedAt,dueAt,notes,System.currentTimeMillis()))
        audit("ثبت $type","ابزار مالی",-1,"$number • $amount • سررسید ${jalali(dueAt)}")
    }
    fun settlementSummary(txId:Long):String {
        val parts=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT method,amount,reference,details FROM tx_settlements WHERE tx_id=? ORDER BY id",arrayOf(txId.toString())).use { c -> while(c.moveToNext()) parts.add("${c.getString(0)}: ${fmt(c.getLong(1))} ${moneyUnit()}${if(c.getString(2).isNullOrBlank())"" else " • ${c.getString(2)}"}${if(c.getString(3).isNullOrBlank())"" else " • ${c.getString(3)}"}") }
        return parts.joinToString("\n")
    }
    fun instrumentRows():List<Pair<Long,String>> {
        val out=mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT id,instrument_type,number,bank,amount,due_at,status,notes FROM financial_instruments WHERE is_deleted=0 ORDER BY due_at",null).use { c -> while(c.moveToNext()) out.add(Pair(c.getLong(0),"${c.getString(1)} ${c.getString(2)} • ${c.getString(3)} • ${fmt(c.getLong(4))} ${moneyUnit()} • سررسید ${jalali(c.getLong(5))} • ${c.getString(6)}${if(c.getString(7).isNullOrBlank())"" else " • ${c.getString(7)}"}")) }
        return out
    }
    fun updateInstrumentStatus(id:Long,status:String) { writableDatabase.execSQL("UPDATE financial_instruments SET status=? WHERE id=?",arrayOf(status,id));audit("تغییر وضعیت ابزار مالی","ابزار مالی",id,status) }
    fun installmentRows():List<Pair<Long,String>> {
        val out=mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT i.id,p.name,i.title,i.total_amount,i.installment_amount,i.paid_amount,i.next_due,i.status FROM installment_plans i JOIN people p ON p.id=i.person_id WHERE i.status='فعال' ORDER BY i.next_due",null).use { c -> while(c.moveToNext()) out.add(Pair(c.getLong(0),"${c.getString(1)} • ${c.getString(2)}\nکل: ${fmt(c.getLong(3))}؛ هر قسط: ${fmt(c.getLong(4))}؛ پرداخت‌شده: ${fmt(c.getLong(5))}\nسررسید بعدی: ${jalali(c.getLong(6))} • ${c.getString(7)}")) }
        return out
    }
    fun payInstallment(id:Long,amount:Long) {
        require(amount>0) { "مبلغ پرداخت معتبر نیست" }
        val d=writableDatabase;d.beginTransaction()
        try {
            var total=0L;var paid=0L;var each=0L;var interval=30;var due=System.currentTimeMillis()
            d.rawQuery("SELECT total_amount,paid_amount,installment_amount,interval_days,next_due FROM installment_plans WHERE id=? AND status='فعال'",arrayOf(id.toString())).use { c -> if(!c.moveToFirst()) throw IllegalArgumentException("برنامه فعال پیدا نشد");total=c.getLong(0);paid=c.getLong(1);each=c.getLong(2);interval=c.getInt(3);due=c.getLong(4) }
            require(paid+amount<=total) { "مبلغ پرداخت از مانده اقساط بیشتر است" }
            val newPaid=paid+amount;val completedSteps=(newPaid/each)-(paid/each)
            val next=Calendar.getInstance().apply{timeInMillis=due;add(Calendar.DAY_OF_MONTH,(interval*completedSteps).toInt())}.timeInMillis
            d.execSQL("UPDATE installment_plans SET paid_amount=?,next_due=?,status=? WHERE id=?",arrayOf(newPaid,next,if(newPaid==total)"تسویه‌شده" else "فعال",id))
            audit("ثبت پرداخت قسط","برنامه اقساط",id,"$amount؛ مجموع پرداخت ${paid+amount}")
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun instruments():List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT instrument_type,number,bank,amount,due_at,status,notes FROM financial_instruments WHERE is_deleted=0 ORDER BY due_at",null).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} ${c.getString(1)} • ${c.getString(2)} • ${fmt(c.getLong(3))} ${moneyUnit()} • سررسید ${jalali(c.getLong(4))} • ${c.getString(5)}${if(c.getString(6).isNullOrBlank())"" else " • ${c.getString(6)}"}") }
        return out
    }
    fun addInstallment(personId:Long,title:String,total:Long,each:Long,interval:Int,start:Long,notes:String) {
        require(total>0 && each>0 && each<=total && interval>0) { "مقادیر قسط معتبر نیستند" }
        writableDatabase.execSQL("INSERT INTO installment_plans(person_id,title,total_amount,installment_amount,interval_days,start_at,next_due,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(personId,title,total,each,interval,start,start,notes,System.currentTimeMillis()))
        audit("ثبت برنامه اقساط","شخص",personId,"$title • $total • قسط $each")
    }
    fun installments():List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT p.name,i.title,i.total_amount,i.installment_amount,i.paid_amount,i.next_due,i.status FROM installment_plans i JOIN people p ON p.id=i.person_id WHERE i.status='فعال' ORDER BY i.next_due",null).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} • ${c.getString(1)}\nکل: ${fmt(c.getLong(2))}؛ هر قسط: ${fmt(c.getLong(3))}؛ پرداخت‌شده: ${fmt(c.getLong(4))}\nسررسید بعدی: ${jalali(c.getLong(5))} • ${c.getString(6)}") }
        return out
    }
    fun reconcile(account:String,start:Long,end:Long,statement:Long,notes:String):Pair<Long,Long> {
        val book=accountBalanceBefore(account,end)
        val diff=statement-book
        writableDatabase.execSQL("INSERT INTO account_reconciliations(account,from_at,to_at,book_balance,statement_balance,difference,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(account,start,end,book,statement,diff,if(diff==0L)"مطابق" else "دارای مغایرت",notes,System.currentTimeMillis()))
        audit("مغایرت‌گیری حساب","حساب مالی",-1,"$account • دفتر $book • صورت‌حساب $statement • اختلاف $diff")
        return Pair(book,diff)
    }
    fun reconciliationHistory():List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT account,from_at,to_at,book_balance,statement_balance,difference,status,notes FROM account_reconciliations ORDER BY id DESC LIMIT 100",null).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} • ${jalali(c.getLong(1))} تا ${jalali(c.getLong(2))}\nدفتر: ${fmt(c.getLong(3))}؛ صورت‌حساب: ${fmt(c.getLong(4))}؛ اختلاف: ${fmt(c.getLong(5))} • ${c.getString(6)}${if(c.getString(7).isNullOrBlank())"" else " • ${c.getString(7)}"}") }
        return out
    }

    fun transfer(from:String,to:String,amount:Long,note:String,at:Long) {
        require(from!=to) { "حساب مبدأ و مقصد باید متفاوت باشند" }; require(amount>0) { "مبلغ باید بیشتر از صفر باشد" }
        val d=writableDatabase; d.beginTransaction()
        try { d.execSQL("INSERT INTO account_transfers(from_account,to_account,amount,note,created_at) VALUES(?,?,?,?,?)",arrayOf(from,to,amount,note,at)); audit("انتقال وجه بین حساب‌ها","انتقال",-1,"$from ← $to: $amount"); d.setTransactionSuccessful() } finally { d.endTransaction() }
    }
    fun accountTransfers(account:String,start:Long,endExclusive:Long):List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT t.from_account,t.to_account,t.amount,t.note,t.created_at FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=CASE WHEN t.from_account=? THEN fa.opening_at ELSE ta.opening_at END AND t.created_at>=? AND t.created_at<? AND (t.from_account=? OR t.to_account=?) ORDER BY t.created_at DESC,t.id DESC",arrayOf(account,start.toString(),endExclusive.toString(),account,account)).use { c -> while(c.moveToNext()){val incoming=c.getString(1)==account;out.add("${if(incoming)"واریز از ${c.getString(0)}" else "انتقال به ${c.getString(1)}"} • ${fmt(c.getLong(2))} ${moneyUnit()} • ${jalali(c.getLong(4))}${if(c.getString(3).isNullOrBlank())"" else " • ${c.getString(3)}"}")} }
        return out
    }
    fun accountTransferTotals(account:String,start:Long,endExclusive:Long):Pair<Long,Long> {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN t.to_account=? THEN t.amount ELSE 0 END),0),COALESCE(SUM(CASE WHEN t.from_account=? THEN t.amount ELSE 0 END),0) FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=CASE WHEN t.from_account=? THEN fa.opening_at ELSE ta.opening_at END AND t.created_at>=? AND t.created_at<? AND (t.from_account=? OR t.to_account=?)",arrayOf(account,account,account,start.toString(),endExclusive.toString(),account,account)).use { c -> return if(c.moveToFirst()) Pair(c.getLong(0),c.getLong(1)) else Pair(0L,0L) }
    }
    fun accountOpeningAt(account:String):Long { readableDatabase.rawQuery("SELECT opening_at FROM finance_accounts WHERE name=?",arrayOf(account)).use { c -> return if(c.moveToFirst())c.getLong(0) else 0L } }
    fun accountOpening(account:String):Pair<Long,Long> { readableDatabase.rawQuery("SELECT opening_balance,opening_at FROM finance_accounts WHERE name=?",arrayOf(account)).use { c -> return if(c.moveToFirst())Pair(c.getLong(0),c.getLong(1)) else Pair(0L,0L) } }
    fun updateTx(id:Long, kind:String, amount:Long, note:String, account:String, createdAt:Long) {
        val settled=DatabaseUtils.longForQuery(readableDatabase,"SELECT COALESCE(SUM(amount),0) FROM tx_settlements WHERE tx_id=?",arrayOf(id.toString()))
        require(amount>=settled) { "مبلغ عملیات از مجموع تسویه‌های ثبت‌شده کمتر است؛ ابتدا جزئیات تسویه را اصلاح کنید" }
        writableDatabase.execSQL("UPDATE transactions SET kind=?,amount=?,note=?,account=?,created_at=? WHERE id=? AND is_deleted=0",arrayOf(kind,amount,note,account,createdAt,id)); audit("ویرایش","تراکنش",id,"$kind - $amount")
    }
    fun personOpeningBalance(personId:Long):PersonOpening? {
        readableDatabase.rawQuery("SELECT id,person_id,amount,balance_type,base_date,description,created_at FROM person_opening_balances WHERE person_id=? AND is_active=1 LIMIT 1",arrayOf(personId.toString())).use { c ->
            return if(c.moveToFirst()) PersonOpening(c.getLong(0),c.getLong(1),c.getLong(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6)) else null
        }
    }
    fun setPersonOpeningBalance(personId:Long,amount:Long,balanceType:String,baseDate:Long,description:String) {
        require(amount>=0) { "مبلغ مانده اولیه نمی‌تواند منفی باشد" }
        require(balanceType=="طلب" || balanceType=="بدهی") { "نوع مانده اولیه نامعتبر است" }
        val d=writableDatabase
        d.beginTransaction()
        try {
            d.execSQL("UPDATE person_opening_balances SET is_active=0 WHERE person_id=? AND is_active=1",arrayOf(personId))
            d.execSQL("INSERT INTO person_opening_balances(person_id,amount,balance_type,base_date,description,is_active,created_at) VALUES(?,?,?,?,?,1,?)",arrayOf(personId,amount,balanceType,baseDate,description,System.currentTimeMillis()))
            audit("ثبت/اصلاح مانده اول دوره","شخص",personId,"$balanceType: $amount @ $baseDate؛ $description")
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    private fun balances(personId: Long): Pair<Long,Long> {
        val opening=personOpeningBalance(personId)
        var receivable=if(opening?.balanceType=="طلب") opening.amount else 0L
        var payable=if(opening?.balanceType=="بدهی") opening.amount else 0L
        val baseDate=opening?.baseDate ?: 0L
        readableDatabase.rawQuery("SELECT t.id,t.kind,t.amount,(SELECT COUNT(*) FROM tx_settlements s WHERE s.tx_id=t.id),(SELECT COALESCE(SUM(CASE WHEN s.method IN ('نقدی','کارت‌به‌کارت','واریز بانکی','دریافت کالا/جنس','تهاتر') THEN s.amount WHEN s.method IN ('چک','سفته') AND EXISTS(SELECT 1 FROM financial_instruments i WHERE i.tx_id=t.id AND i.instrument_type=s.method AND i.amount=s.amount AND i.status IN ('وصول‌شده','پرداخت‌شده') AND i.is_deleted=0) THEN s.amount ELSE 0 END),0) FROM tx_settlements s WHERE s.tx_id=t.id) FROM transactions t WHERE t.person_id=? AND t.is_deleted=0 AND t.created_at>=? ORDER BY t.created_at,t.id", arrayOf(personId.toString(),baseDate.toString())).use { c ->
            while(c.moveToNext()) {
                val kind=c.getString(1); val grossAmount=c.getLong(2);val settlementCount=c.getInt(3);val settled=c.getLong(4);val amount=if(kind in listOf("دریافت وجه","پرداخت وجه") && settlementCount>0)settled else grossAmount
                val increasesReceivable = kind in listOf("طلب","پرداخت وجه","تحویل کالا","فروش نسیه")
                if(increasesReceivable) {
                    val offset=minOf(payable,amount); payable-=offset; receivable+=amount-offset
                } else if(kind in listOf("بدهی","دریافت وجه","دریافت کالا","خرید نسیه")) {
                    val offset=minOf(receivable,amount); receivable-=offset; payable+=amount-offset
                }
                if(settled>0 && kind in listOf("طلب","فروش نسیه","تحویل کالا")) { val offset=minOf(receivable,settled);receivable-=offset }
                if(settled>0 && kind in listOf("بدهی","خرید نسیه","دریافت کالا")) { val offset=minOf(payable,settled);payable-=offset }
            }
        }
        return Pair(receivable,payable)
    }
    fun people(q: String = ""): List<Person> {
        val out= mutableListOf<Person>()
        readableDatabase.rawQuery("SELECT id,name,phone,address,relation,notes,COALESCE(photo_data,''),second_phone,national_id,birth_date,job,workplace,source,credit_rating,tags,location,father_name,landline,email,group_name,roles FROM people WHERE is_deleted=0 AND (name LIKE ? OR phone LIKE ? OR second_phone LIKE ? OR national_id LIKE ? OR tags LIKE ? OR job LIKE ? OR workplace LIKE ? OR email LIKE ? OR group_name LIKE ? OR roles LIKE ?) ORDER BY name", arrayOf("%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%")).use { c ->
            while(c.moveToNext()) { val id=c.getLong(0); val b=balances(id); out.add(Person(id,c.getString(1),c.getString(2) ?: "",c.getString(3) ?: "",c.getString(4) ?: "",c.getString(5) ?: "",c.getString(6) ?: "",b.first-b.second,b.first,b.second,c.getString(7) ?: "",c.getString(8) ?: "",c.getString(9) ?: "",c.getString(10) ?: "",c.getString(11) ?: "",c.getString(12) ?: "",c.getString(13) ?: "",c.getString(14) ?: "",c.getString(15) ?: "",c.getString(16) ?: "",c.getString(17) ?: "",c.getString(18) ?: "",c.getString(19) ?: "سایر افراد و طرف‌حساب‌ها",c.getString(20) ?: "")) }
        }
        return out
    }
    fun personDisplayMode(id:Long):Int {
        readableDatabase.rawQuery("SELECT display_mode FROM people WHERE id=?",arrayOf(id.toString())).use { c ->
            return if(c.moveToFirst()) c.getInt(0).coerceIn(1,5) else 4
        }
    }
    fun setPersonDisplayMode(id:Long,mode:Int) {
        require(mode in 1..5)
        writableDatabase.execSQL("UPDATE people SET display_mode=? WHERE id=?",arrayOf(mode,id))
        audit("تغییر تنظیم نمایش شخص","شخص",id,"حالت نمایش: $mode")
    }
    fun addPerson(name: String, phone: String, address: String, relation: String, notes: String, photoData:String=""): Long {
        val id = writableDatabase.insertOrThrow("people", null, android.content.ContentValues().apply { put("name",name); put("phone",phone); put("address",address); put("relation",relation); put("notes",notes); put("photo_data",photoData); put("created_at",System.currentTimeMillis()) })
        audit("ایجاد", "شخص", id, name)
        return id
    }
    fun setPersonPhoto(id:Long,data:String) {
        writableDatabase.execSQL("UPDATE people SET photo_data=? WHERE id=?",arrayOf(data,id))
        audit("تغییر عکس شخص","شخص",id,if(data.isBlank())"حذف عکس" else "ثبت عکس")
    }
    fun updatePersonExtra(id:Long, secondPhone:String, nationalId:String, birthDate:String, job:String, workplace:String, source:String, rating:String, tags:String, location:String, fatherName:String="", landline:String="", email:String="", groupName:String="سایر افراد و طرف‌حساب‌ها", roles:String="") {
        writableDatabase.execSQL("UPDATE people SET second_phone=?,national_id=?,birth_date=?,job=?,workplace=?,source=?,credit_rating=?,tags=?,location=?,father_name=?,landline=?,email=?,group_name=?,roles=? WHERE id=?",arrayOf(secondPhone,nationalId,birthDate,job,workplace,source,rating,tags,location,fatherName,landline,email,groupName,roles,id))
        audit("ویرایش مشخصات تکمیلی","شخص",id,"تکمیل پرونده")
    }
    fun duplicatePeople(name:String,phone:String,nationalId:String,excludeId:Long=0):List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name,phone,national_id FROM people WHERE is_deleted=0 AND id<>? AND ((?<>'' AND national_id=?) OR (?<>'' AND (phone=? OR second_phone=?)) OR (?<>'' AND name=?))",arrayOf(excludeId.toString(),nationalId,nationalId,phone,phone,phone,name,name)).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} • ${c.getString(1)} • ${c.getString(2)}") }
        return out.distinct()
    }
    fun addDocument(personId:Long,title:String,data:String) { writableDatabase.execSQL("INSERT INTO person_documents(person_id,title,data,created_at) VALUES(?,?,?,?)",arrayOf(personId,title,data,System.currentTimeMillis())); audit("افزودن مدرک","شخص",personId,title) }
    fun documents(personId:Long):List<Pair<Long,String>> { val out=mutableListOf<Pair<Long,String>>(); readableDatabase.rawQuery("SELECT id,title FROM person_documents WHERE person_id=? ORDER BY id DESC",arrayOf(personId.toString())).use { c->while(c.moveToNext())out.add(Pair(c.getLong(0),c.getString(1)))};return out }
    fun documentData(id:Long):String? { readableDatabase.rawQuery("SELECT data FROM person_documents WHERE id=?",arrayOf(id.toString())).use { c->return if(c.moveToFirst())c.getString(0) else null } }
    fun deleteDocument(id:Long) { writableDatabase.delete("person_documents","id=?",arrayOf(id.toString())) }
    fun addReminder(personId:Long,title:String,note:String,at:Long):Long { writableDatabase.execSQL("INSERT INTO person_reminders(person_id,title,note,remind_at,created_at) VALUES(?,?,?,?,?)",arrayOf(personId,title,note,at,System.currentTimeMillis()));val id=DatabaseUtils.longForQuery(readableDatabase,"SELECT last_insert_rowid()",null);audit("ثبت یادآوری","شخص",personId,title);return id }
    fun allPendingReminders():List<Array<Any>> {
        val out=mutableListOf<Array<Any>>()
        readableDatabase.rawQuery("SELECT r.id,r.title,r.remind_at,p.name FROM person_reminders r JOIN people p ON p.id=r.person_id WHERE r.is_done=0 AND p.is_deleted=0 ORDER BY r.remind_at",null).use { c -> while(c.moveToNext()) out.add(arrayOf(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3))) }
        return out
    }
    fun reminders(personId:Long):List<Triple<Long,String,Long>> { val out=mutableListOf<Triple<Long,String,Long>>(); readableDatabase.rawQuery("SELECT id,title,remind_at FROM person_reminders WHERE person_id=? AND is_done=0 ORDER BY remind_at",arrayOf(personId.toString())).use { c->while(c.moveToNext())out.add(Triple(c.getLong(0),c.getString(1),c.getLong(2)))};return out }
    fun completeReminder(id:Long) { writableDatabase.execSQL("UPDATE person_reminders SET is_done=1 WHERE id=?",arrayOf(id)) }
    fun archivePerson(id:Long) {
        writableDatabase.execSQL("UPDATE people SET is_deleted=1 WHERE id=? AND is_deleted=0",arrayOf(id))
        audit("بایگانی", "شخص", id, "پرونده از فهرست فعال خارج شد؛ سوابق مالی حفظ شدند")
    }
    fun restorePerson(id:Long) {
        writableDatabase.execSQL("UPDATE people SET is_deleted=0 WHERE id=? AND is_deleted=1",arrayOf(id))
        audit("بازیابی", "شخص", id, "بازگشت پرونده به فهرست فعال")
    }
    fun deletedPeople():List<Person> {
        val out=mutableListOf<Person>()
        readableDatabase.rawQuery("SELECT id,name,phone,address,relation,notes,COALESCE(photo_data,''),second_phone,national_id,birth_date,job,workplace,source,credit_rating,tags,location,father_name,landline,email,group_name,roles FROM people WHERE is_deleted=1 ORDER BY name",null).use { c ->
            while(c.moveToNext()) { val id=c.getLong(0); val b=balances(id); out.add(Person(id,c.getString(1),c.getString(2) ?: "",c.getString(3) ?: "",c.getString(4) ?: "",c.getString(5) ?: "",c.getString(6) ?: "",b.first-b.second,b.first,b.second,c.getString(7) ?: "",c.getString(8) ?: "",c.getString(9) ?: "",c.getString(10) ?: "",c.getString(11) ?: "",c.getString(12) ?: "",c.getString(13) ?: "",c.getString(14) ?: "",c.getString(15) ?: "",c.getString(16) ?: "",c.getString(17) ?: "",c.getString(18) ?: "",c.getString(19) ?: "سایر افراد و طرف‌حساب‌ها",c.getString(20) ?: "")) }
        }
        return out
    }
    fun personName(id:Long):String { readableDatabase.rawQuery("SELECT name FROM people WHERE id=?",arrayOf(id.toString())).use { c -> return if(c.moveToFirst()) c.getString(0) else "" } }
    fun personTransactionCount(id:Long):Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM transactions WHERE person_id=?",arrayOf(id.toString())).use { c -> return if(c.moveToFirst()) c.getInt(0) else 0 }
    }
    fun addTx(personId: Long?, kind: String, amount: Long, note: String, account: String, createdAt:Long):Long {
        val id = writableDatabase.insertOrThrow("transactions", null, android.content.ContentValues().apply { if(personId==null) putNull("person_id") else put("person_id",personId); put("kind",kind); put("amount",amount); put("note",note); put("account",account.ifBlank { "نقدی" }); put("created_at",createdAt) })
        if(personId!=null) {
            addPersonSectionLink(personId,"ledger","طرف‌حساب دفتر حساب")
            if(kind in listOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")) addPersonSectionLink(personId,"finance","طرف‌حساب امور مالی")
        }
        audit("ثبت", "تراکنش", id, "$kind - $amount")
        return id
    }
    private fun audit(action:String,target:String,id:Long,details:String) { writableDatabase.execSQL("INSERT INTO audit_log(action,target,target_id,details,created_at) VALUES(?,?,?,?,?)", arrayOf(action,target,id,details,System.currentTimeMillis())) }
    fun summary(): Summary {
        val totals=cashTotals(0L,Long.MAX_VALUE);val inc=totals.first;val exp=totals.second
        val ps=people(); val cash=accountBalances(true).sumOf{it.second}
        return Summary(inc,exp,cash,ps.sumOf{if(it.balance>0) it.balance else 0L},ps.sumOf{if(it.balance<0) -it.balance else 0L})
    }
    fun transactions(personId: Long? = null, limit: Int = 300): List<Tx> {
        val out= mutableListOf<Tx>()
        val where=if(personId==null) "t.is_deleted=0" else "t.is_deleted=0 AND t.person_id=?"
        val args=if(personId==null) null else arrayOf(personId.toString())
        readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id WHERE $where ORDER BY t.created_at DESC,t.id DESC LIMIT $limit",args).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }
        return out
    }
    // دفتر شخص بر مبنای مانده امضاشده محاسبه می‌شود: مثبت = طلب ما از شخص، منفی = بدهی ما به شخص.
    fun personLedgerRows(personId:Long,start:Long=0L,endExclusive:Long=Long.MAX_VALUE):List<Tx> {
        val out=mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,''),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id WHERE t.person_id=? AND t.is_deleted=0 AND t.created_at>=? AND t.created_at<? ORDER BY t.created_at ASC,t.id ASC",arrayOf(personId.toString(),start.toString(),endExclusive.toString())).use { c ->
            while(c.moveToNext()) out.add(Tx(c.getLong(0),personId,c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی"))
        }
        return out
    }
    fun personLedgerImpact(t:Tx):Long {
        val count=DatabaseUtils.longForQuery(readableDatabase,"SELECT COUNT(*) FROM tx_settlements WHERE tx_id=?",arrayOf(t.id.toString()))
        val settled=DatabaseUtils.longForQuery(readableDatabase,"SELECT COALESCE(SUM(CASE WHEN s.method IN ('نقدی','کارت‌به‌کارت','واریز بانکی','دریافت کالا/جنس','تهاتر') THEN s.amount WHEN s.method IN ('چک','سفته') AND EXISTS(SELECT 1 FROM financial_instruments i WHERE i.tx_id=s.tx_id AND i.instrument_type=s.method AND i.amount=s.amount AND i.status IN ('وصول‌شده','پرداخت‌شده') AND i.is_deleted=0) THEN s.amount ELSE 0 END),0) FROM tx_settlements s WHERE s.tx_id=?",arrayOf(t.id.toString()))
        return when(t.kind) {
            "طلب","تحویل کالا","فروش نسیه" -> t.amount-settled
            "بدهی","دریافت کالا","خرید نسیه" -> -(t.amount-settled)
            "دریافت وجه" -> -(if(count>0L) settled else t.amount)
            "پرداخت وجه" -> if(count>0L) settled else t.amount
            else -> 0L
        }
    }
    fun personBalanceBefore(personId:Long,timestamp:Long):Long {
        val opening=personOpeningBalance(personId)
        var balance=when(opening?.balanceType){"طلب"->opening.amount;"بدهی"->-opening.amount;else->0L}
        val from=opening?.baseDate ?: 0L
        if(timestamp<=from) return balance
        personLedgerRows(personId,from,timestamp).forEach { balance+=personLedgerImpact(it) }
        return balance
    }
    fun cashBalanceBefore(timestamp:Long):Long = accounts().sumOf { accountBalanceBefore(it,timestamp) }
    fun transactionsBetween(start:Long,endExclusive:Long):List<Tx> {
        val out= mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id LEFT JOIN finance_accounts a ON a.name=t.account WHERE t.is_deleted=0 AND t.created_at>=? AND t.created_at<? AND t.created_at>=COALESCE(a.opening_at,0) ORDER BY t.created_at DESC,t.id DESC",arrayOf(start.toString(),endExclusive.toString())).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }
        return out
    }
    fun deleteTx(id:Long) { writableDatabase.execSQL("UPDATE transactions SET is_deleted=1 WHERE id=?",arrayOf(id)); audit("حذف نرم", "تراکنش", id, "انتقال به سطل بازیابی") }
    fun restoreTx(id:Long) { writableDatabase.execSQL("UPDATE transactions SET is_deleted=0 WHERE id=?",arrayOf(id)); audit("بازیابی", "تراکنش", id, "بازیابی از سطل") }
    fun deletedTx(): List<Tx> {
        val out= mutableListOf<Tx>(); readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id WHERE t.is_deleted=1 ORDER BY t.created_at DESC",null).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }; return out
    }
}

private object MoneyDisplay {
    var unit: String = "تومان"
    var separator: Boolean = true
    var persianDigits: Boolean = true
}
private fun fmt(n: Long): String {
    // Use BigInteger so converting large toman balances to rial cannot overflow Long.
    val value = BigInteger.valueOf(n).let { if (MoneyDisplay.unit == "ریال") it.multiply(BigInteger.TEN) else it }
    val raw = if (MoneyDisplay.separator) DecimalFormat("#,###").format(value) else value.toString()
    return if (MoneyDisplay.persianDigits) raw.map { ch -> if (ch in '0'..'9') ('۰'.code + (ch.code-'0'.code)).toChar() else ch }.joinToString("") else raw
}
private fun moneyUnit(): String = MoneyDisplay.unit
// Accept Persian, Arabic-Indic and English digits in every numeric field.
private fun parseLongDigits(input: String): Long? {
    val normalized = input.trim().filterNot { it == ',' || it == '٬' || it == '،' || it == '，' || it.isWhitespace() }.map { ch ->
        when (ch) {
            in '۰'..'۹' -> ('0'.code + ch.code - '۰'.code).toChar()
            in '٠'..'٩' -> ('0'.code + ch.code - '٠'.code).toChar()
            else -> ch
        }
    }.joinToString("")
    return normalized.toLongOrNull()
}
private fun parseDecimalDigits(input:String):Double? {
    val normalized=input.trim().filterNot{it==','||it=='٬'||it=='،'||it=='，'||it.isWhitespace()}.map{ch->when(ch){in '۰'..'۹'->('0'.code+ch.code-'۰'.code).toChar();in '٠'..'٩'->('0'.code+ch.code-'٠'.code).toChar();'٫'->'.';else->ch}}.joinToString("")
    return normalized.toDoubleOrNull()
}
private fun jalali(millis:Long):String {
    val cal=Calendar.getInstance().apply { timeInMillis=millis }; val gy=cal.get(Calendar.YEAR); val gm=cal.get(Calendar.MONTH)+1; val gd=cal.get(Calendar.DAY_OF_MONTH)
    val gdm=arrayOf(0,31,if(isLeap(gy))29 else 28,31,30,31,30,31,31,30,31,30,31)
    var gy2=gy-1600; var gm2=gm-1; var gd2=gd-1
    var gdn=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400
    for(i in 0 until gm2) gdn+=gdm[i+1]
    gdn+=gd2
    var jdn=gdn-79; val jnp=jdn/12053; jdn%=12053
    var jy=979+33*jnp+4*(jdn/1461); jdn%=1461
    if(jdn>=366){jy+=(jdn-1)/365; jdn=(jdn-1)%365}
    val jm=if(jdn<186) 1+(jdn/31).toInt() else 7+((jdn-186)/30).toInt()
    val jd=if(jdn<186) 1+(jdn%31).toInt() else 1+((jdn-186)%30).toInt()
    return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
}
private fun isLeap(y:Int)= (y%4==0 && y%100!=0)||y%400==0
private fun jalaliToMillis(jy:Int,jm:Int,jd:Int):Long? {
    if(jy<1200 || jy>1600 || jm !in 1..12 || jd !in 1..31) return null
    val base=Calendar.getInstance().apply { clear(); set(jy+621,Calendar.MARCH,18,0,0,0) }
    var start:Calendar?=null
    for(offset in 0..5) {
        val candidate=(base.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH,offset) }
        val label=jalali(candidate.timeInMillis)
        if(label=="%04d/01/01".format(Locale.US,jy)){start=candidate;break}
    }
    val first=start ?: return null
    val maxDay=if(jm<=6)31 else if(jm<=11)30 else if(isJalaliLeap(jy))30 else 29
    if(jd>maxDay) return null
    val dayOffset=if(jm<=6)(jm-1)*31+(jd-1) else 186+(jm-7)*30+(jd-1)
    first.add(Calendar.DAY_OF_MONTH,dayOffset)
    return first.timeInMillis
}
private fun isJalaliLeap(year:Int):Boolean {
    val a=jalaliToMillisRawStart(year) ?: return false
    val b=jalaliToMillisRawStart(year+1) ?: return false
    return (b-a)/86400000L>365
}
private fun jalaliToMillisRawStart(jy:Int):Long? {
    val base=Calendar.getInstance().apply { clear(); set(jy+621,Calendar.MARCH,18,0,0,0) }
    for(offset in 0..5) { val c=(base.clone() as Calendar).apply{add(Calendar.DAY_OF_MONTH,offset)}; if(jalali(c.timeInMillis)=="%04d/01/01".format(Locale.US,jy)) return c.timeInMillis }
    return null
}
private fun jalaliInput(millis:Long):String = jalali(millis)


class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private var peopleFilter = 0 // 0 همه، 1 طلبکار، 2 بدهکار، 3 تسویه‌شده
    private var peopleSort = 0 // 0 نام، 1 بیشترین طلب، 2 بیشترین بدهی، 3 بیشترین مانده خالص
    private val requestCreateBackup = 4101
    private var pendingBackupType:String = "both"
    private val requestRestoreBackup = 4102
    private val requestPickContact = 4103
    private val requestTakePersonPhoto = 4104
    private val requestChoosePersonPhoto = 4105
    private val requestChooseTxDocument = 4121
    private val requestChooseAppearanceBackground = 4122
    private val requestExportInvoicesCsv = 4123
    private var pendingTxDocumentId:Long?=null
    private var activePersonName:EditText?=null
    private var activePersonPhone:EditText?=null
    private var activePersonPhotoData:String=""
    private var activePersonPhotoPreview:ImageView?=null
    private lateinit var root: LinearLayout
    private val green=0xff21634a.toInt(); private val red=0xffa74636.toInt(); private val bg=0xfff4f7f4.toInt(); private val pale=0xffe8f1eb.toInt()
    private data class HomePalette(val name:String,val background:Int,val accent:Int,val deep:Int,val soft:Int,val card:Int,val text:Int)
    private val homePalettes = listOf(
        HomePalette("سبز زمردی",0xfff1f6f2.toInt(),0xff16845b.toInt(),0xff07583d.toInt(),0xffc8ead8.toInt(),0xffffffff.toInt(),0xff20352a.toInt()),
        HomePalette("آبی سلطنتی",0xffedf4fa.toInt(),0xff2876b8.toInt(),0xff12436f.toInt(),0xffc9e2f6.toInt(),0xffffffff.toInt(),0xff203247.toInt()),
        HomePalette("مشکی و طلایی",0xff17191d.toInt(),0xffd6ad55.toInt(),0xff805b1b.toInt(),0xff514126.toInt(),0xff252930.toInt(),0xfff4ead4.toInt()),
        HomePalette("سفید مینیمال",0xfff8f8f6.toInt(),0xffa88c60.toInt(),0xff695538.toInt(),0xffeee4d2.toInt(),0xffffffff.toInt(),0xff34312b.toInt()),
        HomePalette("طبیعت و آرامش",0xffedf4ed.toInt(),0xff56835a.toInt(),0xff31583a.toInt(),0xffd4e6d0.toInt(),0xffffffff.toInt(),0xff263b2b.toInt()),
        HomePalette("بنفش مدرن",0xfff2eff8.toInt(),0xff7955b5.toInt(),0xff493078.toInt(),0xffded2f2.toInt(),0xffffffff.toInt(),0xff302642.toInt())
    )
    // پالت مشترک برای همه صفحات؛ حالت شب در صورت فعال‌بودن از پالت مشکی و طلایی استفاده می‌کند.
    private fun currentPalette():HomePalette {
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val autoNight=prefs.getBoolean("auto_night",false)
        val clock=Calendar.getInstance()
        val currentMinute=clock.get(Calendar.HOUR_OF_DAY)*60+clock.get(Calendar.MINUTE)
        val scheduleMode=prefs.getString("appearance_schedule_mode",null)
        val night=if(scheduleMode!=null){
            AppearanceSchedule.isNight(
                scheduleMode,
                prefs.getInt("appearance_night_start",19*60),
                prefs.getInt("appearance_night_end",7*60),
                currentMinute
            )
        }else autoNight && (clock.get(Calendar.HOUR_OF_DAY)>=19 || clock.get(Calendar.HOUR_OF_DAY)<7)
        val index=if(night) 2 else prefs.getInt("theme",0).coerceIn(0,homePalettes.lastIndex)
        return homePalettes[index]
    }
    private fun addHomeIconTile(parent:LinearLayout, label:String, icon:String, palette:HomePalette, iconStyle:Int, layoutStyle:Int, action:()->Unit) {
        val tile=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            setPadding(if(layoutStyle==5)14 else 6,if(layoutStyle==5)8 else 10,if(layoutStyle==5)14 else 6,10)
            background=GradientDrawable().apply { cornerRadius=when(layoutStyle){0->24f;3->4f;4->30f;6->14f;else->18f};setColor(palette.card);if(layoutStyle==3)setStroke(2,palette.accent) }
            elevation=when(iconStyle){2->10f;3->8f;4->6f;else->3f}
            isClickable=true;isFocusable=true;setOnClickListener{action()}
        }
        val colors=when(iconStyle){
            0->intArrayOf(palette.soft,palette.accent,palette.deep)
            1->intArrayOf(0xffffffff.toInt(),palette.soft,palette.accent)
            2->intArrayOf(palette.accent,palette.deep)
            3->intArrayOf(palette.deep,palette.accent,palette.deep)
            4->intArrayOf(palette.card,palette.soft)
            else->intArrayOf(palette.accent,0xff8b6bd1.toInt(),palette.deep)
        }
        val badge=TextView(this).apply {
            text=icon;textSize=if(layoutStyle==5)23f else 27f;gravity=Gravity.CENTER;setTextColor(0xffffffff.toInt())
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,colors).apply {
                shape=if(iconStyle==4)GradientDrawable.RECTANGLE else GradientDrawable.OVAL
                cornerRadius=if(iconStyle==4)18f else 0f
                setStroke(if(iconStyle==3)3 else 1,if(iconStyle==3)0xfff6d77a.toInt() else 0x66ffffff)
            }
            elevation=when(iconStyle){2,3->10f;4->3f;else->6f}
            setPadding(13,13,13,13)
        }
        val iconSize=if(layoutStyle==5)54 else 64
        tile.addView(badge,LinearLayout.LayoutParams(iconSize,iconSize))
        tile.addView(text(label,if(layoutStyle==5)14f else 12f,palette.text,true).apply{gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,-2))
        parent.addView(tile,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(4,5,4,5)})
    }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); loadMoneySettings(); val peoplePrefs=getSharedPreferences("people_list",Context.MODE_PRIVATE); peopleFilter=peoplePrefs.getInt("filter",0).coerceIn(0,3); peopleSort=peoplePrefs.getInt("sort",0).coerceIn(0,3); db=LedgerDb(this); migrateCatalogSection103To22(); showHome()}
    private fun loadMoneySettings(){
        val p=getSharedPreferences("money_display",Context.MODE_PRIVATE)
        MoneyDisplay.unit=p.getString("unit","تومان") ?: "تومان"
        MoneyDisplay.separator=p.getBoolean("separator",true)
        MoneyDisplay.persianDigits=p.getBoolean("persian_digits",true)
    }
    private fun saveMoneySettings(unit:String,separator:Boolean,persian:Boolean){
        getSharedPreferences("money_display",Context.MODE_PRIVATE).edit().putString("unit",unit).putBoolean("separator",separator).putBoolean("persian_digits",persian).apply()
        MoneyDisplay.unit=unit; MoneyDisplay.separator=separator; MoneyDisplay.persianDigits=persian
    }
    private fun showMoneySettings(){
        base("تنظیمات نمایش مبالغ"){showHome()}
        val box=card()
        box.addView(text("واحد نمایش مبلغ",16f,green,true))
        val unit=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("تومان","ریال"));setSelection(if(MoneyDisplay.unit=="ریال")1 else 0)}
        val separator=styledCheckBox().apply{text="نمایش جداکننده هزارگان";isChecked=MoneyDisplay.separator}
        val digits=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("ارقام فارسی","ارقام انگلیسی"));setSelection(if(MoneyDisplay.persianDigits)0 else 1)}
        box.addView(unit);box.addView(separator);box.addView(text("شیوه نمایش ارقام",16f,green,true));box.addView(digits)
        box.addView(text("مبالغ در پایگاه داده تغییر نمی‌کنند؛ فقط شیوه نمایش آن‌ها عوض می‌شود. ورود مبالغ همچنان بر اساس تومان است.",13f))
        root.addView(box)
        root.addView(btn("ذخیره تنظیمات"){saveMoneySettings(unit.selectedItem.toString(),separator.isChecked,digits.selectedItemPosition==0);toast("تنظیمات ذخیره شد");showHome()})
        root.addView(btn("بازگشت بدون ذخیره"){showHome()})
    }
    private fun base(title:String, back:(()->Unit)?=null){
        val palette=currentPalette()
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,12,16,10);layoutDirection=View.LAYOUT_DIRECTION_RTL;setBackgroundColor(palette.background)}
        applyAppearanceBackground(root)
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        if(back!=null) head.addView(btn("‹") { back() },LinearLayout.LayoutParams(52,-2))
        head.addView(text(title,22f,palette.accent,true),LinearLayout.LayoutParams(0,-2,1f)); root.addView(head); setContentView(root)
    }
    private fun appearanceFontScale():Float = getSharedPreferences("home_dashboard",Context.MODE_PRIVATE).getFloat("font_scale",1.0f).coerceIn(0.85f,1.30f)
    private fun text(s:String,size:Float=15f,color:Int=currentPalette().text,bold:Boolean=false)=TextView(this).apply{
        text=s;textSize=size*appearanceFontScale()
        val palette=currentPalette();setTextColor(if(color==green) palette.accent else color)
        if(bold)typeface=Typeface.DEFAULT_BOLD
        gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL;setPadding(4,7,4,7)
    }
    private fun btn(s:String,action:()->Unit)=Button(this).apply{
        val palette=currentPalette();text=s;textSize=14f*appearanceFontScale();isAllCaps=false;setTextColor(palette.text)
        background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(palette.soft,palette.card)).apply{cornerRadius=14f;setStroke(1,palette.accent)}
        minHeight=48;setPadding(14,8,14,8);stateListAnimator=null
        setOnClickListener{action()}
    }
    private fun field(hint:String,number:Boolean=false)=EditText(this).apply{
        val palette=currentPalette();this.hint=hint;textSize=15f*appearanceFontScale();setSingleLine(true)
        layoutDirection=View.LAYOUT_DIRECTION_RTL;setTextColor(palette.text);setHintTextColor((palette.text and 0x00ffffff) or 0x88000000.toInt())
        background=GradientDrawable().apply{setColor(palette.card);cornerRadius=12f;setStroke(1,palette.soft)}
        setPadding(14,10,14,10);minHeight=48
        if(number)inputType=InputType.TYPE_CLASS_NUMBER
    }
    private fun styledSpinner()=Spinner(this).apply{
        val p=currentPalette();backgroundTintList=android.content.res.ColorStateList.valueOf(p.accent)
        setPadding(8,6,8,6);minimumHeight=46
    }
    private fun styledCheckBox()=CheckBox(this).apply{
        val p=currentPalette();setTextColor(p.text)
        buttonTintList=android.content.res.ColorStateList.valueOf(p.accent)
        setPadding(4,6,4,6)
    }
    private fun styleDialogView(view:View):View{
        val p=currentPalette()
        if(view is LinearLayout){
            view.setPadding(maxOf(view.paddingLeft,12),maxOf(view.paddingTop,8),maxOf(view.paddingRight,12),maxOf(view.paddingBottom,8))
            view.setBackgroundColor(p.background)
            for(i in 0 until view.childCount) styleDialogView(view.getChildAt(i))
        } else if(view is ScrollView){
            view.setBackgroundColor(p.background)
            if(view.childCount>0) styleDialogView(view.getChildAt(0))
        } else if(view is TextView){view.setTextColor(p.text)}
        return view
    }
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,8,12,8);background=GradientDrawable().apply{setColor(currentPalette().card);cornerRadius=18f;setStroke(1,currentPalette().soft)}}
    private fun line(parent:LinearLayout){parent.addView(View(this).apply{setBackgroundColor(currentPalette().soft)},LinearLayout.LayoutParams(-1,1))}
    private fun showInventory(query:String="", stockFilter:Int=0){
        base("مدیریت کالا و انبار"){showHome()}
        root.addView(btn("＋ تعریف کالای جدید"){ addInventoryProduct() })
        root.addView(btn("＋ اصلاح موجودی یک کالا"){ adjustInventoryStock() })
        val rows=db.products()
        if(rows.isEmpty()) { root.addView(text("هنوز کالایی ثبت نشده است.")); return }
        val lowCount=rows.count{(it[6] as Double) <= (it[7] as Double)}
        val zeroCount=rows.count{(it[6] as Double) <= 0.0}
        val stockValue=rows.sumOf{(it[6] as Double)*(it[4] as Long).toDouble()}
        val summary=card()
        summary.addView(text("خلاصه وضعیت انبار",16f,currentPalette().accent,true))
        val metrics=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        fun inventoryMetric(label:String,value:String,color:Int)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(3,6,3,6);addView(text(label,11f,0xff68736d.toInt(),true));addView(text(value,13f,color,true))}
        metrics.addView(inventoryMetric("تعداد کالا",rows.size.toString(),currentPalette().accent),LinearLayout.LayoutParams(0,-2,1f))
        metrics.addView(inventoryMetric("کم‌موجود",lowCount.toString(),if(lowCount>0)red else green),LinearLayout.LayoutParams(0,-2,1f))
        metrics.addView(inventoryMetric("ناموجود",zeroCount.toString(),if(zeroCount>0)red else green),LinearLayout.LayoutParams(0,-2,1f))
        summary.addView(metrics)
        summary.addView(text("ارزش تقریبی موجودی بر مبنای قیمت خرید: ${fmt(stockValue.toLong())} ${moneyUnit()}",13f,green,true))
        root.addView(summary)
        val search=field("جست‌وجوی نام، کد یا بارکد کالا").apply{setText(query)}
        root.addView(search)
        val filters=arrayOf("همه کالاها","نیازمند سفارش (در حد هشدار یا کمتر)","ناموجودها","موجودی بالاتر از حد هشدار")
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        controls.addView(btn("جست‌وجو"){showInventory(search.text.toString().trim(),stockFilter)},LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(btn("فیلتر: ${filters[stockFilter.coerceIn(0,3)]}"){
            AlertDialog.Builder(this@MainActivity).setTitle("فیلتر موجودی کالا").setSingleChoiceItems(filters,stockFilter){dialog,which->dialog.dismiss();showInventory(search.text.toString().trim(),which)}.setNegativeButton("انصراف",null).show()
        },LinearLayout.LayoutParams(0,-2,1f))
        root.addView(controls)
        val normalized=query.trim().lowercase(Locale.ROOT)
        val filtered=rows.filter{r->
            val matches=normalized.isBlank() || listOf(r[1].toString(),r[2].toString(),r[3].toString()).any{it.lowercase(Locale.ROOT).contains(normalized)}
            val qty=r[6] as Double;val min=r[7] as Double
            matches && when(stockFilter){1->qty<=min;2->qty<=0.0;3->qty>min;else->true}
        }
        root.addView(text("${filtered.size} کالا از ${rows.size} کالا",12f))
        if(filtered.isEmpty()) root.addView(text("کالایی با این جست‌وجو یا فیلتر پیدا نشد."))
        filtered.forEach { r ->
            val id=r[0] as Long; val qty=r[6] as Double;val min=r[7] as Double
            val low=qty<=min;val c=card()
            c.addView(text(r[1].toString(),17f,currentPalette().accent,true))
            c.addView(text("کد: ${r[2].toString().ifBlank{"—"}}  •  واحد: ${r[3]}"))
            c.addView(text("موجودی: $qty ${r[3]}  •  حد هشدار: $min",14f,if(low)red else green,true))
            c.addView(text("خرید: ${fmt(r[4] as Long)}  •  فروش: ${fmt(r[5] as Long)} ${moneyUnit()}"))
            c.addView(text(if(qty<=0.0)"وضعیت: ناموجود" else if(low)"وضعیت: نیازمند بررسی و سفارش" else "وضعیت: موجودی مناسب",12f,if(low)red else green,true))
            c.addView(btn("＋ اصلاح موجودی این کالا"){adjustInventoryStockFor(id)})
            root.addView(c);line(root)
        }
    }
    private fun adjustInventoryStockFor(productId:Long){
        val rows=db.products();val index=rows.indexOfFirst{it[0] as Long==productId}
        if(index<0){toast("کالا پیدا نشد");showInventory();return}
        val labels=rows.map{"${it[1]} • موجودی ${it[6]} ${it[3]}"}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val product=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,labels);setSelection(index)}
        val direction=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("ورود به انبار","خروج از انبار"))}
        val qty=field("مقدار",false).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL}
        val price=field("قیمت واحد",true);val note=field("علت اصلاح")
        listOf(product,direction,qty,price,note).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("اصلاح موجودی کالا").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ثبت تغییر"){_,_->
            val value=parseDecimalDigits(qty.text.toString());if(value==null||value<=0){toast("مقدار معتبر وارد کنید");return@setPositiveButton}
            val delta=if(direction.selectedItemPosition==0)value else -value
            try{db.adjustStock(rows[product.selectedItemPosition][0] as Long,delta,parseLongDigits(price.text.toString())?:0,note.text.toString());showInventory()}catch(e:Exception){toast(e.message?:"اصلاح موجودی ناموفق")}
        }.show()
    }
    private fun addInventoryProduct(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val name=field("نام کالا");val sku=field("کد کالا / بارکد (اختیاری)");val unit=field("واحد؛ عدد، کیلو، متر...").apply{setText("عدد")};val buy=field("قیمت خرید هر واحد",true);val sell=field("قیمت فروش هر واحد",true);val opening=field("موجودی اولیه",true);val min=field("حد هشدار موجودی",true)
        listOf(name,sku,unit,buy,sell,opening,min).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("تعریف کالای جدید").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره کالا"){_,_->try{db.addProduct(name.text.toString(),sku.text.toString(),unit.text.toString(),parseLongDigits(buy.text.toString())?:0,parseLongDigits(sell.text.toString())?:0,parseDecimalDigits(opening.text.toString())?:0.0,parseDecimalDigits(min.text.toString())?:0.0);showInventory()}catch(e:Exception){toast(e.message?:"ثبت کالا ناموفق بود")}}.show()
    }
    private fun adjustInventoryStock(){
        val rows=db.products();if(rows.isEmpty()){toast("ابتدا کالا تعریف کنید");return}
        val labels=rows.map{"${it[1]} • موجودی ${it[6]} ${it[3]}"};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val product=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,labels)};val direction=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("ورود به انبار","خروج از انبار"))};val qty=field("مقدار",false).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL};val price=field("قیمت واحد",true);val note=field("علت اصلاح")
        listOf(product,direction,qty,price,note).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("اصلاح موجودی انبار").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ثبت تغییر"){_,_->val value=parseDecimalDigits(qty.text.toString());if(value==null||value<=0){toast("مقدار معتبر وارد کنید");return@setPositiveButton};val q=if(direction.selectedItemPosition==0)value else -value;try{db.adjustStock(rows[product.selectedItemPosition][0] as Long,q,parseLongDigits(price.text.toString())?:0,note.text.toString());showInventory()}catch(e:Exception){toast(e.message?:"اصلاح موجودی ناموفق")}}.show()
    }
    private fun showInvoices(){
        base("فاکتورهای خرید و فروش"){showHome()}
        root.addView(btn("＋ ثبت فاکتور خرید یا فروش"){ addInvoice() })
        root.addView(btn("＋ ثبت فاکتور چندقلمی"){ addMultiInvoice() })
        root.addView(btn("خروجی اکسل فاکتورها (CSV)"){ exportInvoicesCsv() })
        val rows=db.invoices()
        val sales=rows.filter{it[2].toString()=="فروش"}.sumOf{it[7] as Long}
        val purchases=rows.filter{it[2].toString()=="خرید"}.sumOf{it[7] as Long}
        val summary=card()
        summary.addView(text("خلاصه فاکتورها",16f,currentPalette().accent,true))
        summary.addView(text("تعداد کل: ${rows.size}"))
        summary.addView(text("مجموع فروش: ${fmt(sales)} ${moneyUnit()}"))
        summary.addView(text("مجموع خرید: ${fmt(purchases)} ${moneyUnit()}"))
        summary.addView(text("اختلاف فروش و خرید: ${fmt(sales-purchases)} ${moneyUnit()}",14f,currentPalette().accent,true))
        root.addView(summary)
        val search=field("جست‌وجو: شماره فاکتور، شخص یا کالا")
        val filter=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("همه فاکتورها","فقط فروش","فقط خرید"))}
        root.addView(search);root.addView(filter)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(list)
        fun render(){
            list.removeAllViews()
            val q=search.text.toString().trim()
            val type=filter.selectedItemPosition
            val visible=rows.filter{r->
                val typeOk=type==0 || (type==1 && r[2].toString()=="فروش") || (type==2 && r[2].toString()=="خرید")
                val textOk=q.isBlank() || listOf(r[1],r[3],r[4]).any{it.toString().contains(q,true)}
                typeOk && textOk
            }
            if(visible.isEmpty()){list.addView(text(if(rows.isEmpty())"هنوز فاکتوری ثبت نشده است." else "فاکتوری با این جست‌وجو پیدا نشد."));return}
            visible.forEach{r->
                val c=card()
                c.addView(text("${r[2]} • ${r[1]}",16f,currentPalette().accent,true))
                c.addView(text("طرف‌حساب: ${r[3].toString().ifBlank{"ثبت نشده"}}"))
                c.addView(text("${r[4]} • ${r[5]} ${r[6]} • مبلغ ${fmt(r[7] as Long)} ${moneyUnit()}"))
                c.addView(text("${jalali(r[8] as Long)}"))
                c.addView(btn("نمایش اقلام فاکتور") {
                    val items = db.invoiceItems(r[0] as Long)
                    val detail = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 8) }
                    if (items.isEmpty()) detail.addView(text("جزئیات اقلام موجود نیست."))
                    items.forEachIndexed { index, item -> detail.addView(text("${index + 1}. ${item[0]} • ${item[1]} ${item[2]} • واحد ${fmt(item[3] as Long)} • مبلغ ${fmt(item[5] as Long)}")) }
                    AlertDialog.Builder(this@MainActivity).setTitle("اقلام ${r[1]}").setView(styleDialogView(detail)).setPositiveButton("بستن", null).show()
                })
                list.addView(c);line(list)
            }
            list.addView(text("نمایش ${visible.size} فاکتور از ${rows.size} فاکتور",12f,currentPalette().soft))
        }
        search.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()}
            override fun afterTextChanged(s:android.text.Editable?){}
        })
        filter.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){}
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){render()}
        }
        render()
    }
    private fun exportInvoicesCsv() {
        try {
            val csv=db.invoicesCsv()
            if(db.invoices().isEmpty()) { toast("فاکتوری برای خروجی گرفتن وجود ندارد"); return }
            val file=File(cacheDir,"invoices_export.csv")
            FileOutputStream(file).use { stream -> stream.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte()));stream.write(csv.toByteArray(Charsets.UTF_8)) }
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE);type="text/csv"
                putExtra(Intent.EXTRA_TITLE,"فاکتورها_${System.currentTimeMillis()}.csv")
            }
            startActivityForResult(intent,requestExportInvoicesCsv)
        } catch(e:Exception) { toast("آماده‌سازی خروجی فاکتورها ناموفق بود: ${e.message ?: "خطا"}") }
    }

    private fun addMultiInvoice() {
        val products = db.products()
        if (products.isEmpty()) { toast("ابتدا در بخش انبار کالا تعریف کنید"); return }
        val people = db.people("")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 0, 20, 0) }
        val type = styledSpinner().apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("فروش", "خرید")) }
        val person = styledSpinner().apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("بدون طرف‌حساب") + people.map { it.name }) }
        val linesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lineViews = mutableListOf<Triple<Spinner, EditText, EditText>>()
        fun addLine() {
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 8, 0, 8) }
            val product = styledSpinner().apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, products.map { "${it[1]} • موجودی ${it[6]} ${it[3]}" }) }
            val qty = field("مقدار", false).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
            val price = field("قیمت واحد", true)
            product.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val ix = if (type.selectedItemPosition == 0) 5 else 4
                    price.setText(products.getOrNull(position)?.get(ix)?.toString() ?: "")
                }
            }
            row.addView(text("قلم ${lineViews.size + 1}", 13f, currentPalette().accent, true)); row.addView(product); row.addView(qty); row.addView(price)
            linesBox.addView(row); lineViews.add(Triple(product, qty, price))
        }
        val invoiceDiscount = field("تخفیف کل فاکتور", true)
        val paid = field("مبلغ تسویه‌شده", true)
        val note = field("توضیحات")
        box.addView(text("نوع فاکتور")); box.addView(type); box.addView(text("طرف‌حساب")); box.addView(person)
        box.addView(linesBox); box.addView(btn("＋ افزودن قلم کالا") { addLine() })
        box.addView(invoiceDiscount); box.addView(paid); box.addView(note)
        addLine()
        AlertDialog.Builder(this).setTitle("ثبت فاکتور چندقلمی").setView(styleDialogView(box)).setNegativeButton("انصراف", null).setPositiveButton("ثبت فاکتور") { _, _ ->
            try {
                val parsed = lineViews.map { (product, qty, price) ->
                    val q = parseDecimalDigits(qty.text.toString()) ?: throw IllegalArgumentException("مقدار هر قلم را وارد کنید")
                    val pr = parseLongDigits(price.text.toString()) ?: throw IllegalArgumentException("قیمت هر قلم معتبر نیست")
                    if (q <= 0 || pr < 0) throw IllegalArgumentException("مقدار یا قیمت هر قلم معتبر نیست")
                    LedgerDb.InvoiceLine(products[product.selectedItemPosition][0] as Long, q, pr)
                }
                val dis = parseLongDigits(invoiceDiscount.text.toString()) ?: 0L
                val pay = parseLongDigits(paid.text.toString()) ?: 0L
                val personId = people.getOrNull(person.selectedItemPosition - 1)?.id
                val invoiceType = type.selectedItem.toString()
                val result = db.createMultiInvoice(invoiceType, personId, parsed, dis, pay, note.text.toString(), System.currentTimeMillis())
                val isSale = invoiceType == "فروش"; val account = db.accounts().firstOrNull() ?: "نقدی"; val remaining = result.second - pay
                if (remaining > 0) db.addTx(personId, if (isSale) "فروش نسیه" else "خرید نسیه", remaining, "فاکتور ${result.first} • ${note.text}", account, System.currentTimeMillis())
                if (pay > 0) { val tx = db.addTx(personId, if (isSale) "دریافت وجه" else "پرداخت وجه", pay, "تسویه فاکتور ${result.first}", account, System.currentTimeMillis()); db.addSettlement(tx, "نقدی", pay, "", "تسویه فاکتور") }
                toast("فاکتور چندقلمی ثبت شد")
                showInvoices()
            } catch (e: Exception) { toast(e.message ?: "ثبت فاکتور ناموفق بود") }
        }.show()
    }
    private fun addInvoice(){
        val products=db.products();if(products.isEmpty()){toast("ابتدا در بخش انبار کالا تعریف کنید");return}
        val people=db.people("");val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val type=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("فروش","خرید"))}
        val product=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,products.map{"${it[1]} • موجودی ${it[6]} ${it[3]}"})}
        val person=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("بدون طرف‌حساب")+people.map{it.name})}
        val qty=field("تعداد / مقدار",false).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL};val price=field("قیمت هر واحد",true);val discount=field("تخفیف",true);val paid=field("مبلغ تسویه‌شده (فعلاً نقدی)",true);val note=field("توضیحات")
        listOf(text("نوع فاکتور"),type,text("کالا"),product,text("طرف‌حساب"),person,qty,price,discount,paid,note).forEach{box.addView(it)}
        product.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){val ix=if(type.selectedItemPosition==0)5 else 4;price.setText(products[pos][ix].toString())}}
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){val ix=if(pos==0)5 else 4;price.setText(products.getOrNull(product.selectedItemPosition)?.get(ix)?.toString()?:"")}}
        AlertDialog.Builder(this).setTitle("ثبت فاکتور یک‌قلمی").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ثبت فاکتور"){_,_->val q=parseDecimalDigits(qty.text.toString());val pr=parseLongDigits(price.text.toString());val dis=parseLongDigits(discount.text.toString())?:0L;val pay=parseLongDigits(paid.text.toString())?:0L;if(q==null||q<=0||pr==null||dis<0||dis>(q*pr).toLong()||pay<0){toast("مقدار یا قیمت معتبر نیست");return@setPositiveButton};val total=(q*pr-dis).toLong().coerceAtLeast(0);if(pay>total){toast("مبلغ تسویه از مبلغ فاکتور بیشتر است");return@setPositiveButton};val personId=people.getOrNull(person.selectedItemPosition-1)?.id;try{val result=db.createInvoice(type.selectedItem.toString(),personId,products[product.selectedItemPosition][0] as Long,q,pr,dis,pay,note.text.toString(),System.currentTimeMillis());val isSale=type.selectedItemPosition==0;val account=db.accounts().firstOrNull()?:"نقدی";val remaining=total-pay;if(remaining>0){val tx=db.addTx(personId,if(isSale)"فروش نسیه" else "خرید نسیه",remaining,"فاکتور ${result.first} • ${note.text}",account,System.currentTimeMillis())};if(pay>0){val tx=db.addTx(personId,if(isSale)"دریافت وجه" else "پرداخت وجه",pay,"تسویه فاکتور ${result.first}",account,System.currentTimeMillis());db.addSettlement(tx,"نقدی",pay,"","تسویه فاکتور")};showInvoices()}catch(e:Exception){toast(e.message?:"ثبت فاکتور ناموفق بود")}}.show()
    }
    private fun showHome(requestedPage:Int?=null){
        base("مدیریت زندگی ۲.۰")
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val senior=prefs.getBoolean("senior_mode",false)
        val focus=prefs.getBoolean("focus_mode",false)
        val pageTitles=listOf("نمای کلی","امور مالی","برنامه‌ریزی","ابزارها")
        val selectedPage=(requestedPage ?: prefs.getInt("dashboard_page",0)).coerceIn(0,3)
        if(requestedPage!=null) prefs.edit().putInt("dashboard_page",selectedPage).apply()
        val tickerEnabled=prefs.getBoolean("ticker_enabled",true) && !focus
        val theme=prefs.getInt("theme",0).coerceIn(0,homePalettes.lastIndex)
        val palette=currentPalette()
        val accent=palette.accent
        val large=if(senior)1.22f else 1f
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(6,4,6,8)}
        pageTitles.forEachIndexed{index,title->
            val tab=btn(title){showHome(index)}
            tab.textSize=if(index==selectedPage)14f else 12f
            tab.setTextColor(if(index==selectedPage)0xffffffff.toInt() else palette.text)
            tab.background=GradientDrawable().apply{cornerRadius=18f;setColor(if(index==selectedPage)accent else palette.soft);setStroke(if(index==selectedPage)0 else 1,accent)}
            val lp=LinearLayout.LayoutParams(0,-2,1f);lp.setMargins(3,0,3,0);tabs.addView(tab,lp)
        }
        root.addView(tabs,LinearLayout.LayoutParams(-1,-2))
        val sc=ScrollView(this)
        val hasCustomBackground=!getSharedPreferences("home_dashboard",Context.MODE_PRIVATE).getString("appearance_background_uri","").isNullOrBlank()
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,8,14,18);layoutDirection=View.LAYOUT_DIRECTION_RTL;setBackgroundColor(if(hasCustomBackground) 0x00000000 else palette.background)}
        sc.addView(content)
        root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))

        // هر ابزارک فقط از داده‌های موجود برنامه می‌خواند؛ هیچ رکورد مالی یا شخصی جدیدی نمی‌سازد.
        val widgets=linkedMapOf<String,View>()
        val welcome=card().apply{setBackground(GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(palette.accent,palette.deep)).apply{cornerRadius=22f});setPadding(16,14,16,14)}
        welcome.addView(text("خوش آمدید 👋",(21f*large),-1,true))
        welcome.addView(text("مدیریت امور روزمره، مالی و خانوادگی در یک جا",(14f*large),-1))
        welcome.addView(text("تاریخ شمسی: ${jalali(System.currentTimeMillis())}    •    ساعت: ${java.text.SimpleDateFormat("HH:mm",Locale.US).format(Date())}",(13f*large),-1))
        widgets["welcome"]=welcome

        if(tickerEnabled){
            widgets["ticker"]=buildAppearanceTicker(large,accent)
        }

        val summary=db.summary(); val finance=card().apply{setBackgroundColor(palette.card)}
        finance.addView(text("خلاصه امور مالی",(18f*large),accent,true))
        finance.addView(text("دریافت: ${fmt(summary.income)} ${moneyUnit()}     •     پرداخت: ${fmt(summary.expense)} ${moneyUnit()}",(15f*large)))
        finance.addView(text("مانده نقدی: ${fmt(summary.balance)} ${moneyUnit()}",(18f*large),if(summary.balance>=0)accent else red,true))
        finance.addView(text("طلب از اشخاص: ${fmt(summary.receivable)} ${moneyUnit()}   |   بدهی به اشخاص: ${fmt(summary.payable)} ${moneyUnit()}",(14f*large)))
        finance.setOnClickListener{showFinance()}
        widgets["finance"]=finance

        val alertSummary=collectHomeAlerts()
        val alerts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,8,10,8);setBackgroundColor(palette.card)}
        alerts.addView(text("مرکز هشدارها و یادآوری‌ها",(18f*large),accent,true))
        alerts.addView(text("موارد نیازمند پیگیری: ${alertSummary.size}",(15f*large),if(alertSummary.isEmpty())palette.text else red,true))
        if(alertSummary.isEmpty()) alerts.addView(text("در حال حاضر هشدار ثبت‌شده‌ای وجود ندارد.",(13f*large)))
        else alertSummary.take(3).forEach { alerts.addView(text("• ${it.second}",(13f*large),palette.text)) }
        alerts.addView(btn("مشاهده همه هشدارها") { showAlertCenter() })
        widgets["alerts"]=alerts

        val tasks=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,8,10,8);setBackgroundColor(palette.card)}
        tasks.addView(text("کارهای امروز",(18f*large),accent,true))
        tasks.addView(btn("＋ افزودن کار امروز") { addHomeTaskDialog() })
        tasks.addView(btn("تاریخچه انجام کارها") { showHomeTaskHistory() })
        val todayKey=java.text.SimpleDateFormat("yyyyMMdd",Locale.US).format(Date())
        val todaysTasks=readHomeTasks().filter{it.optString("day_key")==todayKey}
        if(todaysTasks.isEmpty()) tasks.addView(text("برای امروز کاری ثبت نشده است.",(14f*large)))
        else todaysTasks.forEach{task->
            val taskId=task.optLong("id")
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
            val priority=task.optString("priority","معمولی")
            val dueAt=task.optLong("due_at",0L)
            val suffix=buildString { append("  •  $priority"); if(dueAt>0) append("  •  ${jalali(dueAt)}") }
            val check=styledCheckBox().apply{text=task.optString("title")+suffix;isChecked=task.optBoolean("done",false);textSize=14f*large;setOnCheckedChangeListener{_,checked->updateHomeTask(taskId,checked);showHome()}}
            row.addView(check,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(btn("ویرایش"){editHomeTaskDialog(taskId)})
            row.setOnLongClickListener{AlertDialog.Builder(this@MainActivity).setMessage("این کار از فهرست حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_->deleteHomeTask(taskId);showHome()}.show();true}
            tasks.addView(row)
        }
        widgets["tasks"]=tasks

        val goals=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,8,10,8);setBackgroundColor(palette.card)}
        goals.addView(text("اهداف و برنامه‌ریزی شخصی",(18f*large),accent,true))
        goals.addView(btn("＋ افزودن هدف جدید") { addHomeGoalDialog() })
        goals.addView(btn("مشاهده تاریخچه پیشرفت اهداف") { showHomeGoalHistory() })
        val allGoals=readHomeGoals()
        if(allGoals.length()==0) goals.addView(text("هنوز هدفی ثبت نشده است.",(14f*large)))
        else for(i in 0 until allGoals.length()){
            val goal=allGoals.optJSONObject(i)?:continue
            val goalId=goal.optLong("id")
            val title=goal.optString("title")
            val target=goal.optLong("target",1).coerceAtLeast(1)
            val progress=goal.optLong("progress",0).coerceAtLeast(0)
            val percent=((progress.toDouble()/target.toDouble())*100.0).toInt().coerceAtLeast(0)
            val unit=goal.optString("unit")
            val detail=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8)}
            detail.addView(text(title,(15f*large),palette.text,true))
            detail.addView(text("پیشرفت: ${fmt(progress)} از ${fmt(target)} $unit  •  ${percent}%",(13f*large),accent))
            val due=goal.optString("due_date")
            if(due.isNotBlank()) detail.addView(text("مهلت: $due",(12f*large),palette.text))
            val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=percent.coerceAtMost(100)}
            detail.addView(bar,LinearLayout.LayoutParams(-1,12))
            detail.addView(btn("ثبت پیشرفت هدف") { updateHomeGoalDialog(goalId) })
            detail.setOnLongClickListener{AlertDialog.Builder(this@MainActivity).setMessage("هدف «$title» حذف شود؟").setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_->deleteHomeGoal(goalId);showHome()}.show();true}
            goals.addView(detail);line(goals)
        }
        widgets["goals"]=goals

        val shortcuts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val layoutStyle=prefs.getInt("home_layout",0).coerceIn(0,7)
        val iconStyle=prefs.getInt("icon_style",0).coerceIn(0,5)
        val layoutTitles=arrayOf("کلاسیک لوکس","رنگارنگ فانتزی","مینیمال","مشکی لوکس","شیشه‌ای","طبیعت","آینده‌نگر","آبی سلطنتی")
        shortcuts.addView(text("دسترسی سریع • ${layoutTitles[layoutStyle]}",(18f*large),accent,true))
        val shortcutsData=listOf(
            Triple("امور مالی","💳",{showFinance()}),Triple("اشخاص","👥",{showPeople()}),Triple("انبار کالا","📦",{showInventory()}),
            Triple("فاکتورها","🧾",{showInvoices()}),Triple("فهرست امکانات","🗂️",{showProgramCatalog()}),Triple("پشتیبان‌گیری","🛡️",{showBackup()})
        )
        val columns=when(layoutStyle){0,3,6->3;1,2,4,7->2;else->1}
        shortcutsData.chunked(columns).forEach{items->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;gravity=if(columns==1)Gravity.CENTER else Gravity.CENTER_VERTICAL}
            items.forEach{item->addHomeIconTile(row,item.first,item.second,palette,iconStyle,layoutStyle,item.third)}
            repeat(columns-items.size){row.addView(View(this),LinearLayout.LayoutParams(0,1,1f))}
            shortcuts.addView(row)
        }
        widgets["shortcuts"]=shortcuts

        val actions=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        actions.addView(btn("＋ ثبت دریافت / پرداخت / درآمد / هزینه") { financeEntryDialog() })
        actions.addView(btn("＋ افزودن شخص") { addPersonDialog() })
        actions.addView(btn("📚 فهرست کامل ۱۰۲ شاخه و زیرشاخه‌ها") { showProgramCatalog() })
        actions.addView(btn("مدیریت صندوق‌ها و حساب‌ها") { showAccounts() })
        actions.addView(btn("📦 مدیریت کالا و انبار") { showInventory() })
        actions.addView(btn("🧾 فاکتورهای خرید و فروش") { showInvoices() })
        actions.addView(btn("مدیریت اتصال اطلاعات اشخاص به بخش‌ها") { showPersonConnectionSettings() })
        actions.addView(btn("سطل بازیابی تراکنش‌ها") { showTrash() })
        actions.addView(btn("تنظیمات نمایش مبالغ") { showMoneySettings() })
        actions.addView(btn("تنظیمات صفحه اصلی") { showHomeSettings() })
        actions.addView(btn("🎨 ظاهر و شخصی‌سازی پیشرفته") { showAppearanceSettings() })
        actions.addView(btn("پشتیبان‌گیری و بازیابی اطلاعات") { showBackup() })
        widgets["actions"]=actions

        if(!focus){
            val recent=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            recent.addView(text("آخرین تراکنش‌ها",(18f*large),accent,true))
            val rows=db.transactions(null,10)
            if(rows.isEmpty())recent.addView(text("هنوز تراکنشی ثبت نشده است.")) else rows.forEach{recent.addView(txCard(it,false));line(recent)}
            widgets["recent"]=recent
        }

        val defaultOrder=listOf("welcome","ticker","finance","alerts","tasks","goals","shortcuts","actions","recent")
        val saved=prefs.getString("widget_order","")?.split(',')?.filter{it in defaultOrder}.orEmpty()
        val order=(saved+defaultOrder).distinct().toMutableList()
        if(prefs.getString("ticker_position","top")=="bottom" && order.remove("ticker")) order.add(order.size,"ticker")
        else if(prefs.getString("ticker_position","top")=="top" && order.remove("ticker")) order.add(1.coerceAtMost(order.size),"ticker")
        val hidden=prefs.getStringSet("widget_hidden",emptySet())?:emptySet()
        val pageWidgets=when(selectedPage){
            0 -> setOf("welcome","ticker","alerts","shortcuts")
            1 -> setOf("finance","recent")
            2 -> setOf("tasks","goals")
            else -> setOf("actions")
        }
        order.forEach{id->val view=widgets[id];if(view!=null&&!hidden.contains(id)&&id in pageWidgets){content.addView(view);content.addView(View(this).apply{setBackgroundColor(0x00000000)},LinearLayout.LayoutParams(1,8))}}
        content.addView(btn("تنظیم و جابه‌جایی ابزارک‌های صفحه اصلی") { showHomeWidgetSettings() })
        content.addView(text("صفحه ${selectedPage+1} از ۴ • ${pageTitles[selectedPage]}",12f,palette.text))
    }
    private data class HomeAlert(val type:String,val second:String,val at:Long,val actionId:Long=0L)
    private fun collectHomeAlerts():List<HomeAlert>{
        val out=mutableListOf<HomeAlert>()
        val now=System.currentTimeMillis()
        val todayStart=java.util.Calendar.getInstance().apply{set(java.util.Calendar.HOUR_OF_DAY,0);set(java.util.Calendar.MINUTE,0);set(java.util.Calendar.SECOND,0);set(java.util.Calendar.MILLISECOND,0)}.timeInMillis
        val tomorrow=todayStart+24L*60L*60L*1000L
        val tasks=readHomeTasks()
        for(i in 0 until tasks.length()){
            val t=tasks.optJSONObject(i)?:continue
            if(t.optBoolean("done",false)) continue
            val due=t.optLong("due_at",0L)
            if(due>0 && due<tomorrow){
                val state=if(due<todayStart)"عقب‌افتاده" else "سررسید امروز"
                out.add(HomeAlert("کار", "کار $state: ${t.optString("title")} • اولویت ${t.optString("priority","معمولی")}",due,t.optLong("id")))
            }
        }
        db.allPendingReminders().forEach { r ->
            val at=r[2] as Long
            if(at<tomorrow) out.add(HomeAlert("یادآوری شخص", "${r[3]}: ${r[1]}",at,r[0] as Long))
        }
        db.products().forEach { r ->
            val stock=r[6] as Double; val min=r[7] as Double
            if(min>0 && stock<=min) out.add(HomeAlert("موجودی", "کمبود موجودی: ${r[1]} • موجودی ${stock} ${r[3]} (حد هشدار ${min})",now,r[0] as Long))
        }
        return out.sortedWith(compareBy<HomeAlert>({if(it.type=="کار" && it.at<todayStart)0 else 1},{it.at}))
    }
    private fun showAlertCenter(){
        base("مرکز هشدارها و یادآوری‌ها"){showHome()}
        root.addView(text("این صفحه فقط داده‌های موجود در کارها، یادآوری اشخاص و انبار را می‌خواند؛ مورد جدیدی در حسابداری یا اشخاص ایجاد نمی‌کند.",13f))
        val alerts=collectHomeAlerts()
        if(alerts.isEmpty()) root.addView(text("هشدار فعالی وجود ندارد.",16f,green,true))
        alerts.forEach { a ->
            val c=card()
            c.addView(text(a.type,12f,green,true))
            c.addView(text(a.second,15f))
            if(a.type!="موجودی") c.addView(text("موعد: ${jalali(a.at)}",12f))
            when(a.type){
                "کار" -> c.addView(btn("رفتن به کارهای امروز"){showHome()})
                "یادآوری شخص" -> c.addView(btn("علامت‌گذاری به‌عنوان انجام‌شده"){db.completeReminder(a.actionId);showAlertCenter()})
                "موجودی" -> c.addView(btn("رفتن به انبار"){showInventory()})
            }
            root.addView(c);line(root)
        }
        root.addView(btn("بازگشت به صفحه اصلی"){showHome()})
    }

    private fun showHomeTaskHistory(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val history=try{JSONArray(prefs.getString("home_task_history","[]")?:"[]")}catch(_:Exception){JSONArray()}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8)}
        if(history.length()==0) box.addView(text("هنوز کاری به‌عنوان انجام‌شده ثبت نشده است."))
        else for(i in history.length()-1 downTo 0){val item=history.optJSONObject(i)?:continue;box.addView(text("${item.optString("title")} • انجام‌شده در ${jalali(item.optLong("at"))}",14f));line(box)}
        AlertDialog.Builder(this).setTitle("تاریخچه کارهای انجام‌شده").setView(styleDialogView(ScrollView(this).apply{addView(box)})).setPositiveButton("بستن",null).show()
    }
    private fun readHomeTasks():JSONArray = try{JSONArray(getSharedPreferences("home_dashboard",Context.MODE_PRIVATE).getString("home_tasks","[]")?:"[]")}catch(_:Exception){JSONArray()}
    private fun saveHomeTasks(tasks:JSONArray){getSharedPreferences("home_dashboard",Context.MODE_PRIVATE).edit().putString("home_tasks",tasks.toString()).apply()}
    private fun addHomeTaskDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val input=field("عنوان کار امروز")
        val priority=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("کم","معمولی","زیاد","فوری"))}
        val date=dateFields(box,System.currentTimeMillis(),"مهلت انجام کار")
        box.addView(input);box.addView(text("اولویت کار"));box.addView(priority)
        AlertDialog.Builder(this).setTitle("افزودن کار امروز").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->
            val title=input.text.toString().trim();val due=readDate(date)
            if(title.isEmpty()||due==null){toast("عنوان و تاریخ معتبر وارد کنید");return@setPositiveButton}
            val tasks=readHomeTasks();tasks.put(JSONObject().put("id",System.currentTimeMillis()).put("title",title).put("day_key",java.text.SimpleDateFormat("yyyyMMdd",Locale.US).format(Date())).put("priority",priority.selectedItem.toString()).put("due_at",due).put("done",false).put("created_at",System.currentTimeMillis()))
            saveHomeTasks(tasks);showHome()
        }.show()
    }
    private fun editHomeTaskDialog(id:Long){
        val tasks=readHomeTasks();val task=(0 until tasks.length()).mapNotNull{tasks.optJSONObject(it)}.firstOrNull{it.optLong("id")==id}?:return
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val input=field("عنوان کار").apply{setText(task.optString("title"))}
        val priority=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("کم","معمولی","زیاد","فوری"));setSelection(listOf("کم","معمولی","زیاد","فوری").indexOf(task.optString("priority","معمولی")).coerceAtLeast(0))}
        val date=dateFields(box,task.optLong("due_at",System.currentTimeMillis()),"مهلت انجام کار")
        box.addView(input);box.addView(text("اولویت کار"));box.addView(priority)
        AlertDialog.Builder(this).setTitle("ویرایش کار").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره تغییرات"){_,_->
            val title=input.text.toString().trim();val due=readDate(date)
            if(title.isEmpty()||due==null){toast("عنوان و تاریخ معتبر وارد کنید");return@setPositiveButton}
            for(i in 0 until tasks.length()){val item=tasks.optJSONObject(i)?:continue;if(item.optLong("id")==id){item.put("title",title).put("priority",priority.selectedItem.toString()).put("due_at",due).put("updated_at",System.currentTimeMillis());break}}
            saveHomeTasks(tasks);showHome()
        }.show()
    }
    private fun updateHomeTask(id:Long,done:Boolean){
        val old=readHomeTasks();val updated=JSONArray();var taskTitle=""
        for(i in 0 until old.length()){val item=old.optJSONObject(i)?:continue;if(item.optLong("id")==id){taskTitle=item.optString("title");item.put("done",done).put("completed_at",if(done)System.currentTimeMillis() else JSONObject.NULL)};updated.put(item)}
        saveHomeTasks(updated)
        if(done){val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE);val history=try{JSONArray(prefs.getString("home_task_history","[]")?:"[]")}catch(_:Exception){JSONArray()};history.put(JSONObject().put("task_id",id).put("title",taskTitle).put("action","completed").put("at",System.currentTimeMillis()));prefs.edit().putString("home_task_history",history.toString()).apply()}
    }
    private fun deleteHomeTask(id:Long){
        val old=readHomeTasks();val updated=JSONArray()
        for(i in 0 until old.length()){val item=old.optJSONObject(i)?:continue;if(item.optLong("id")!=id)updated.put(item)}
        saveHomeTasks(updated)
    }
    private fun readHomeGoals():JSONArray = try{JSONArray(getSharedPreferences("home_dashboard",Context.MODE_PRIVATE).getString("home_goals","[]")?:"[]")}catch(_:Exception){JSONArray()}
    private fun saveHomeGoals(goals:JSONArray){getSharedPreferences("home_dashboard",Context.MODE_PRIVATE).edit().putString("home_goals",goals.toString()).apply()}
    private fun addHomeGoalDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,8)}
        val title=EditText(this).apply{hint="عنوان هدف";setSingleLine(true)}
        val target=EditText(this).apply{hint="مقدار نهایی هدف (عدد)";inputType=InputType.TYPE_CLASS_NUMBER}
        val unit=EditText(this).apply{hint="واحد (مثلاً کتاب، کیلومتر، تومان)";setSingleLine(true)}
        val due=EditText(this).apply{hint="مهلت هدف به شمسی (اختیاری)";setSingleLine(true)}
        listOf(title,target,unit,due).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("تعریف هدف جدید").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره هدف"){_,_->
            val name=title.text.toString().trim();val targetValue=parseLongDigits(target.text.toString());val dueText=due.text.toString().trim()
            if(name.isEmpty()||targetValue==null||targetValue<=0){toast("عنوان و مقدار نهایی معتبر وارد کنید");return@setPositiveButton}
            if(dueText.isNotEmpty()){
                val parts=dueText.split("/")
                val valid=parts.size==3 && jalaliToMillis(parts[0].toIntOrNull()?:-1,parts[1].toIntOrNull()?:-1,parts[2].toIntOrNull()?:-1)!=null
                if(!valid){toast("مهلت شمسی معتبر وارد کنید؛ قالب صحیح سال/ماه/روز است");return@setPositiveButton}
            }
            val goals=readHomeGoals();goals.put(JSONObject().put("id",System.currentTimeMillis()).put("title",name).put("target",targetValue).put("progress",0).put("unit",unit.text.toString().trim()).put("due_date",dueText).put("created_at",System.currentTimeMillis()))
            saveHomeGoals(goals);showHome()
        }.show()
    }
    private fun updateHomeGoalDialog(id:Long){
        val goal=readHomeGoals().let{arr->(0 until arr.length()).mapNotNull{arr.optJSONObject(it)}.firstOrNull{it.optLong("id")==id}}?:return
        val input=EditText(this).apply{hint="میزان پیشرفت فعلی";inputType=InputType.TYPE_CLASS_NUMBER;setText(goal.optLong("progress").toString())}
        AlertDialog.Builder(this).setTitle("ثبت پیشرفت: ${goal.optString("title")}").setView(input).setNegativeButton("انصراف",null).setPositiveButton("ذخیره پیشرفت"){_,_->
            val value=parseLongDigits(input.text.toString())
            if(value==null||value<0){toast("مقدار پیشرفت معتبر نیست");return@setPositiveButton}
            val goals=readHomeGoals();var goalTitle=""
            for(i in 0 until goals.length()){val item=goals.optJSONObject(i)?:continue;if(item.optLong("id")==id){goalTitle=item.optString("title");item.put("progress",value).put("updated_at",System.currentTimeMillis());break}}
            saveHomeGoals(goals)
            val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE);val history=try{JSONArray(prefs.getString("home_goal_history","[]")?:"[]")}catch(_:Exception){JSONArray()}
            history.put(JSONObject().put("goal_id",id).put("title",goalTitle).put("progress",value).put("at",System.currentTimeMillis()))
            prefs.edit().putString("home_goal_history",history.toString()).apply();showHome()
        }.show()
    }
    private fun showHomeGoalHistory(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val history=try{JSONArray(prefs.getString("home_goal_history","[]")?:"[]")}catch(_:Exception){JSONArray()}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8)}
        if(history.length()==0) box.addView(text("هنوز سابقه‌ای برای پیشرفت اهداف ثبت نشده است."))
        else for(i in history.length()-1 downTo 0){val item=history.optJSONObject(i)?:continue;box.addView(text("${item.optString("title")} • پیشرفت ثبت‌شده: ${fmt(item.optLong("progress"))} • ${jalali(item.optLong("at"))}",14f));line(box)}
        AlertDialog.Builder(this).setTitle("تاریخچه پیشرفت اهداف").setView(styleDialogView(ScrollView(this).apply{addView(box)})).setPositiveButton("بستن",null).show()
    }
    private fun deleteHomeGoal(id:Long){
        val old=readHomeGoals();val updated=JSONArray()
        for(i in 0 until old.length()){val item=old.optJSONObject(i)?:continue;if(item.optLong("id")!=id)updated.put(item)}
        saveHomeGoals(updated)
    }
    private fun showHomeWidgetSettings(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val labels=linkedMapOf("welcome" to "خوشامدگویی و تاریخ","ticker" to "نوار پیام متحرک","finance" to "خلاصه امور مالی","alerts" to "مرکز هشدارها و یادآوری‌ها","tasks" to "کارهای امروز","goals" to "اهداف و برنامه‌ریزی شخصی","shortcuts" to "دسترسی سریع","actions" to "دکمه‌های عملیات و مدیریت","recent" to "آخرین تراکنش‌ها")
        val defaults=labels.keys.toList()
        val stored=prefs.getString("widget_order","")?.split(',')?.filter{it in labels.keys}.orEmpty()
        val order=(stored+defaults).distinct().toMutableList()
        val hidden=(prefs.getStringSet("widget_hidden",emptySet())?:emptySet()).toMutableSet()
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,8,12,8)}
        val scroll=ScrollView(this).apply{addView(rows)}
        fun render(){
            rows.removeAllViews()
            order.forEachIndexed{index,id->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
                val check=styledCheckBox().apply{text=labels[id]?:id;isChecked=!hidden.contains(id);layoutParams=LinearLayout.LayoutParams(0,-2,1f);setOnCheckedChangeListener{_,checked->if(checked)hidden.remove(id) else hidden.add(id)}}
                row.addView(check)
                val up=Button(this).apply{text="↑";isEnabled=index>0;setOnClickListener{val item=order.removeAt(index);order.add(index-1,item);render()}}
                val down=Button(this).apply{text="↓";isEnabled=index<order.lastIndex;setOnClickListener{val item=order.removeAt(index);order.add(index+1,item);render()}}
                row.addView(up,LinearLayout.LayoutParams(48,-2));row.addView(down,LinearLayout.LayoutParams(48,-2));rows.addView(row)
            }
            rows.addView(text("با فلش‌ها ترتیب ابزارک‌ها را تغییر دهید. تیک هر ابزارک را برای نمایش یا پنهان‌کردن آن تنظیم کنید.",13f,green))
        }
        render()
        AlertDialog.Builder(this).setTitle("مدیریت ابزارک‌های صفحه اصلی").setView(scroll).setNegativeButton("انصراف",null).setNeutralButton("بازگشت به پیش‌فرض"){_,_->prefs.edit().remove("widget_order").remove("widget_hidden").apply();showHome()}.setPositiveButton("ذخیره ترتیب و نمایش"){_,_->prefs.edit().putString("widget_order",order.joinToString(",")).putStringSet("widget_hidden",hidden.toSet()).apply();showHome()}.show()
    }
    private fun showHomeSettings(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,8)}
        val ticker=styledCheckBox().apply{text="نمایش نوار پیام متحرک";isChecked=prefs.getBoolean("ticker_enabled",true)}
        val focus=styledCheckBox().apply{text="حالت تمرکز (پنهان‌کردن پیام و تراکنش‌های اخیر)";isChecked=prefs.getBoolean("focus_mode",false)}
        val senior=styledCheckBox().apply{text="حالت سالمندان (متن و دکمه‌های درشت‌تر)";isChecked=prefs.getBoolean("senior_mode",false)}
        val theme=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,homePalettes.map{it.name});setSelection(prefs.getInt("theme",0).coerceIn(0,homePalettes.lastIndex))}
        box.addView(ticker);box.addView(focus);box.addView(senior);box.addView(text("رنگ‌بندی صفحه",15f,green,true));box.addView(theme)
        AlertDialog.Builder(this).setTitle("شخصی‌سازی صفحه اصلی").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->prefs.edit().putBoolean("ticker_enabled",ticker.isChecked).putBoolean("focus_mode",focus.isChecked).putBoolean("senior_mode",senior.isChecked).putInt("theme",theme.selectedItemPosition).apply();showHome()}.show()
    }
    private fun showAppearanceSettings(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8)}
        val mode=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("آزادی کامل","شخصی‌سازی کنترل‌شده"));setSelection(prefs.getInt("customization_mode",1).coerceIn(0,1))}
        val theme=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,homePalettes.map{it.name});setSelection(prefs.getInt("theme",0).coerceIn(0,homePalettes.lastIndex))}
        val layoutNames=arrayOf("کلاسیک لوکس","رنگارنگ فانتزی","مینیمال","مشکی لوکس","شیشه‌ای","طبیعت","آینده‌نگر","آبی سلطنتی")
        val layout=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,layoutNames);setSelection(prefs.getInt("home_layout",0).coerceIn(0,layoutNames.lastIndex))}
        val iconStyles=arrayOf("فانتزی","براق","سه‌بعدی","نورانی","سایه‌دار","گرادیانی")
        val icons=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,iconStyles);setSelection(prefs.getInt("icon_style",0).coerceIn(0,iconStyles.lastIndex))}
        val ticker=styledCheckBox().apply{text="نمایش نوار پیام";isChecked=prefs.getBoolean("ticker_enabled",true)}
        val motion=styledCheckBox().apply{text="فعال بودن جلوه‌های حرکتی";isChecked=prefs.getBoolean("motion_enabled",true)}
        val savedScheduleMode=prefs.getString("appearance_schedule_mode",null)
        val nightMode=styledSpinner().apply{
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("بدون زمان‌بندی (تم انتخابی همیشه فعال)","زمان‌بندی شب و روز"))
            val enabled= savedScheduleMode?.let{it==AppearanceSchedule.MODE_SCHEDULED} ?: prefs.getBoolean("auto_night",false)
            setSelection(if(enabled)1 else 0)
        }
        var nightStart=prefs.getInt("appearance_night_start",19*60).coerceIn(0,1439)
        var nightEnd=prefs.getInt("appearance_night_end",7*60).coerceIn(0,1439)
        lateinit var nightStartButton:Button
        lateinit var nightEndButton:Button
        nightStartButton=btn("شروع تم شب: ${AppearanceSchedule.formatTime(nightStart)}") {
            TimePickerDialog(this,{_,hour,minute->nightStart=hour*60+minute;nightStartButton.text="شروع تم شب: ${AppearanceSchedule.formatTime(nightStart)}"},nightStart/60,nightStart%60,true).show()
        }
        nightEndButton=btn("پایان تم شب: ${AppearanceSchedule.formatTime(nightEnd)}") {
            TimePickerDialog(this,{_,hour,minute->nightEnd=hour*60+minute;nightEndButton.text="پایان تم شب: ${AppearanceSchedule.formatTime(nightEnd)}"},nightEnd/60,nightEnd%60,true).show()
        }
        val fontScale=SeekBar(this).apply{max=45;progress=((prefs.getFloat("font_scale",1.0f)-0.85f)*100).toInt().coerceIn(0,45)}
        val fontScaleLabel=text("اندازه نوشته‌ها: ${"%.0f".format(java.util.Locale.US,prefs.getFloat("font_scale",1.0f)*100)}٪",14f,green,true)
        // پیش‌نمایش زنده فقط در همین صفحه است و تا زدن «ذخیره» هیچ ترجیحی را تغییر نمی‌دهد.
        val preview=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,14,16,14)}
        val previewTitle=text("پیش‌نمایش زنده ظاهر",16f,green,true)
        val previewBody=text("نمونه نوشته و رنگ‌ها\nآیکون: ✦   صفحه اصلی",14f)
        val previewMeta=text("",12f)
        preview.addView(previewTitle);preview.addView(previewBody);preview.addView(previewMeta)
        fun refreshAppearancePreview(){
            val p=homePalettes[theme.selectedItemPosition.coerceIn(0,homePalettes.lastIndex)]
            preview.background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(p.background,p.soft)).apply{cornerRadius=18f;setStroke(2,p.accent)}
            previewTitle.setTextColor(p.accent);previewBody.setTextColor(p.text);previewMeta.setTextColor(p.deep)
            previewBody.textSize=14f*(0.85f+fontScale.progress/100f)
            previewMeta.text="${p.name}  |  ${layoutNames[layout.selectedItemPosition]}  |  ${iconStyles[icons.selectedItemPosition]}"
        }
        val previewListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:android.view.View?,position:Int,id:Long){refreshAppearancePreview()}
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?){ }
        }
        theme.onItemSelectedListener=previewListener;layout.onItemSelectedListener=previewListener;icons.onItemSelectedListener=previewListener
        fontScale.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar:SeekBar?,progress:Int,fromUser:Boolean){fontScaleLabel.text="اندازه نوشته‌ها: ${85+progress}٪";refreshAppearancePreview()}
            override fun onStartTrackingTouch(seekBar:SeekBar?){}
            override fun onStopTrackingTouch(seekBar:SeekBar?){}
        })
        val allowFull=prefs.getBoolean("policy_allow_full",true)
        if(!allowFull)mode.setSelection(1)
        mode.isEnabled=allowFull
        theme.isEnabled=prefs.getBoolean("policy_allow_theme",true)
        layout.isEnabled=prefs.getBoolean("policy_allow_layout",true)
        icons.isEnabled=prefs.getBoolean("policy_allow_icons",true)
        motion.isEnabled=prefs.getBoolean("policy_allow_motion",true)
        refreshAppearancePreview()
        box.addView(text("حالت شخصی‌سازی",14f,green,true));box.addView(mode)
        box.addView(text("تم رنگی",14f,green,true));box.addView(theme)
        box.addView(text("طرح صفحه اصلی",14f,green,true));box.addView(layout)
        box.addView(text("سبک آیکون‌های داخلی",14f,green,true));box.addView(icons)
        box.addView(ticker);box.addView(motion)
        box.addView(text("زمان‌بندی تم شب",14f,green,true));box.addView(nightMode)
        box.addView(nightStartButton);box.addView(nightEndButton)
        box.addView(fontScaleLabel);box.addView(fontScale)
        box.addView(text("نمونه تغییرات (بدون ذخیره روی برنامه)",14f,green,true));box.addView(preview)
        box.addView(btn("بازگشت سریع به تنظیمات ذخیره‌شده") {
            mode.setSelection(prefs.getInt("customization_mode",1).coerceIn(0,1))
            theme.setSelection(prefs.getInt("theme",0).coerceIn(0,homePalettes.lastIndex))
            layout.setSelection(prefs.getInt("home_layout",0).coerceIn(0,layoutNames.lastIndex))
            icons.setSelection(prefs.getInt("icon_style",0).coerceIn(0,iconStyles.lastIndex))
            ticker.isChecked=prefs.getBoolean("ticker_enabled",true);motion.isChecked=prefs.getBoolean("motion_enabled",true)
            nightMode.setSelection(if((prefs.getString("appearance_schedule_mode",null)?.let{it==AppearanceSchedule.MODE_SCHEDULED} ?: prefs.getBoolean("auto_night",false)))1 else 0)
            nightStart=prefs.getInt("appearance_night_start",19*60).coerceIn(0,1439);nightEnd=prefs.getInt("appearance_night_end",7*60).coerceIn(0,1439)
            nightStartButton.text="شروع تم شب: ${AppearanceSchedule.formatTime(nightStart)}";nightEndButton.text="پایان تم شب: ${AppearanceSchedule.formatTime(nightEnd)}"
            fontScale.progress=((prefs.getFloat("font_scale",1.0f)-0.85f)*100).toInt().coerceIn(0,45)
            refreshAppearancePreview();toast("مقادیر ذخیره‌شده دوباره بارگذاری شدند")
        })
        box.addView(btn("ویرایش نوار پیام متحرک و پیام‌های آن") { showTickerSettings() })
        box.addView(btn("تغییر آیکون برنامه در صفحه گوشی") { showLauncherIconSettings() })
        box.addView(btn("پس‌زمینه و تصویر دلخواه") { showAppearanceBackgroundSettings() })
        box.addView(btn("پروفایل‌های ظاهری ذخیره‌شده") { showAppearanceProfiles() })
        box.addView(btn("سیاست‌های شخصی‌سازی مدیر دستگاه") { showAppearancePolicySettings() })
        box.addView(btn("بازنشانی امن تنظیمات ظاهری به پیش‌فرض") { confirmAppearanceReset() })
        box.addView(text("بازنشانی فقط ترجیحات ظاهری را به پیش‌فرض برمی‌گرداند؛ پروفایل‌های ذخیره‌شده، سیاست‌های مدیر، اطلاعات مالی، اشخاص، فاکتورها و اسناد حذف نمی‌شوند.",12f,green))
        box.addView(text("سیاست‌های مدیر در این نسخه محلی و مخصوص همین دستگاه‌اند؛ احراز هویت و نقش‌های چندکاربره تا زمان پیاده‌سازی سامانه حساب‌ها فعال محسوب نمی‌شوند.",12f,red))
        AlertDialog.Builder(this).setTitle("ظاهر و شخصی‌سازی برنامه").setView(styleDialogView(ScrollView(this).apply{addView(box)})).setNegativeButton("انصراف",null).setNeutralButton("ذخیره پروفایل") { _, _ ->
            val input=EditText(this).apply{hint="نام پروفایل؛ مثلاً زمردی لوکس"}
            AlertDialog.Builder(this).setTitle("ذخیره پروفایل ظاهری").setView(input).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->
                val name=input.text.toString().trim()
                if(name.isNotEmpty()){
                    prefs.edit().putInt("customization_mode",mode.selectedItemPosition).putInt("theme",theme.selectedItemPosition)
                        .putInt("home_layout",layout.selectedItemPosition).putInt("icon_style",icons.selectedItemPosition)
                        .putBoolean("ticker_enabled",ticker.isChecked).putBoolean("motion_enabled",motion.isChecked)
                        .putBoolean("auto_night",nightMode.selectedItemPosition==1)
                        .putString("appearance_schedule_mode",if(nightMode.selectedItemPosition==1)AppearanceSchedule.MODE_SCHEDULED else AppearanceSchedule.MODE_OFF)
                        .putInt("appearance_night_start",nightStart).putInt("appearance_night_end",nightEnd)
                        .putFloat("font_scale",0.85f+fontScale.progress/100f).apply()
                    saveAppearanceProfile(name)
                }else toast("نام پروفایل را وارد کن")
            }.show()
        }.setPositiveButton("ذخیره تنظیمات"){_,_->
            prefs.edit().putInt("customization_mode",mode.selectedItemPosition).putInt("theme",theme.selectedItemPosition).putInt("home_layout",layout.selectedItemPosition).putInt("icon_style",icons.selectedItemPosition).putBoolean("ticker_enabled",ticker.isChecked).putBoolean("motion_enabled",motion.isChecked).putBoolean("auto_night",nightMode.selectedItemPosition==1)
                .putString("appearance_schedule_mode",if(nightMode.selectedItemPosition==1)AppearanceSchedule.MODE_SCHEDULED else AppearanceSchedule.MODE_OFF)
                .putInt("appearance_night_start",nightStart).putInt("appearance_night_end",nightEnd)
                .putFloat("font_scale",0.85f+fontScale.progress/100f).apply()
            toast("تنظیمات ظاهری ذخیره شد");showHome()
        }.show()
    }
    private fun confirmAppearanceReset(){
        AlertDialog.Builder(this)
            .setTitle("بازنشانی تنظیمات ظاهری")
            .setMessage("فقط ظاهر و ترجیحات نمایشی برنامه به حالت پیش‌فرض برمی‌گردند. پروفایل‌های ذخیره‌شده، سیاست‌های مدیر و تمام اطلاعات مالی، اشخاص، فاکتورها و اسناد دست‌نخورده می‌مانند. این کار قابل بازگشت خودکار نیست.")
            .setNegativeButton("انصراف",null)
            .setPositiveButton("بازنشانی فقط ظاهر"){_,_->resetAppearancePreferences()}
            .show()
    }

    private fun resetAppearancePreferences(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val backgroundUri=prefs.getString("appearance_background_uri",null)
        if(!backgroundUri.isNullOrBlank()){
            try{contentResolver.releasePersistableUriPermission(Uri.parse(backgroundUri),Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
        }
        val editor=prefs.edit()
        AppearanceReset.preferenceKeys.forEach{editor.remove(it)}
        if(!editor.commit()){
            toast("بازنشانی انجام نشد؛ تنظیمات قبلی حفظ شدند")
            return
        }
        try{
            val aliases=arrayOf("LauncherEmerald","LauncherGold","LauncherBlue","LauncherModern")
            aliases.forEachIndexed{i,alias->
                val component=android.content.ComponentName(this,"ir.kambiz.daftar.$alias")
                packageManager.setComponentEnabledSetting(component,if(i==0)android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED else android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,android.content.pm.PackageManager.DONT_KILL_APP)
            }
        }catch(e:Exception){toast("تنظیمات ظاهر بازنشانی شد؛ بازنشانی آیکون لانچر نیازمند بررسی است: ${e.message?:"خطا"}");showHome();return}
        toast("تنظیمات ظاهری به پیش‌فرض برگشت؛ داده‌ها و پروفایل‌ها حفظ شدند")
        showHome()
    }

    private fun showLauncherIconSettings(){
        val names=arrayOf("زمردی","مشکی و طلایی","آبی سلطنتی","چندرنگ مدرن")
        val aliases=arrayOf("LauncherEmerald","LauncherGold","LauncherBlue","LauncherModern")
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val selected=prefs.getInt("launcher_icon",0).coerceIn(0,3)
        AlertDialog.Builder(this).setTitle("آیکون برنامه").setSingleChoiceItems(names,selected,null)
            .setNegativeButton("انصراف",null).setPositiveButton("اعمال آیکون"){dialog,_ ->
                val index=(dialog as AlertDialog).listView.checkedItemPosition.coerceIn(0,3)
                try{
                    val pm=packageManager
                    aliases.forEachIndexed{i,name->
                        val component=android.content.ComponentName(this,"ir.kambiz.daftar."+name)
                        pm.setComponentEnabledSetting(component,if(i==index)android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED else android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,android.content.pm.PackageManager.DONT_KILL_APP)
                    }
                    prefs.edit().putInt("launcher_icon",index).apply();toast("آیکون برنامه تغییر کرد؛ ممکن است لانچر گوشی کمی زمان برای به‌روزرسانی نیاز داشته باشد.")
                }catch(e:Exception){toast("تغییر آیکون انجام نشد: ${e.message?:"خطا"}")}
            }.show()
    }
    private fun buildAppearanceTicker(scale:Float, fallbackColor:Int):View {
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val messages=try{JSONArray(prefs.getString("ticker_messages","[]")?:"[]")}catch(_:Exception){JSONArray()}
        val messageText=(0 until messages.length()).map{messages.optString(it).trim()}.filter{it.isNotBlank()}.joinToString("     •     ")
            .ifBlank { "امروز، یک قدم کوچک برای نظم بیشتر زندگی بردارید" }
        val colors=intArrayOf(0xff16845b.toInt(),0xff2876b8.toInt(),0xffd6ad55.toInt(),0xff7955b5.toInt(),0xffc04b55.toInt(),currentPalette().text)
        val color=colors[prefs.getInt("ticker_color",0).coerceIn(0,colors.lastIndex)]
        val size=prefs.getInt("ticker_size",13).coerceIn(10,24)*scale
        val moving=prefs.getBoolean("ticker_moving",true) && prefs.getBoolean("motion_enabled",true)
        val frame=FrameLayout(this).apply{setPadding(6,8,6,8);setBackgroundColor(0x12000000)}
        val label=TextView(this).apply{
            text=messageText;textSize=size;setTextColor(if(color==0)fallbackColor else color);setSingleLine(true)
            gravity=Gravity.CENTER_VERTICAL;includeFontPadding=true
        }
        frame.addView(label,FrameLayout.LayoutParams(-2,-2,Gravity.CENTER_VERTICAL))
        var runningAnimator:ValueAnimator?=null
        if(moving){
            frame.addOnLayoutChangeListener(object:View.OnLayoutChangeListener{
                override fun onLayoutChange(v:View,l:Int,t:Int,r:Int,b:Int,ol:Int,ot:Int,or:Int,ob:Int){
                    if(r-l<=0||label.width<=0||runningAnimator!=null)return
                    val speed=prefs.getInt("ticker_speed",3).coerceIn(1,5)
                    runningAnimator=ValueAnimator.ofFloat((r-l).toFloat(),-label.width.toFloat()).apply{
                        duration=(36000L-((speed-1)*7000L)).coerceAtLeast(8000L);repeatCount=ValueAnimator.INFINITE
                        addUpdateListener{label.translationX=it.animatedValue as Float};start()
                    }
                    frame.setOnTouchListener{_,event->
                        when(event.action){android.view.MotionEvent.ACTION_DOWN->runningAnimator?.pause();android.view.MotionEvent.ACTION_UP,android.view.MotionEvent.ACTION_CANCEL->runningAnimator?.resume()}
                        true
                    }
                    frame.removeOnLayoutChangeListener(this)
                }
            })
        } else {
            label.gravity=Gravity.CENTER
            label.layoutParams=FrameLayout.LayoutParams(-1,-2,Gravity.CENTER)
        }
        frame.addOnAttachStateChangeListener(object:View.OnAttachStateChangeListener{
            override fun onViewAttachedToWindow(v:View){}
            override fun onViewDetachedFromWindow(v:View){runningAnimator?.cancel();runningAnimator=null;frame.clearAnimation()}
        })
        return frame
    }
    private fun showTickerSettings(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,8,16,8)}
        val messages=EditText(this).apply{
            hint="هر پیام را در یک خط بنویسید";minLines=3;maxLines=7;gravity=Gravity.TOP or Gravity.RIGHT
            setText((try{JSONArray(prefs.getString("ticker_messages","[]")?:"[]")}catch(_:Exception){JSONArray()}).let{a->(0 until a.length()).joinToString("\n"){a.optString(it)}})
        }
        val mode=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("حرکت پیوسته","نمایش ثابت"));setSelection(if(prefs.getBoolean("ticker_moving",true))0 else 1)}
        val position=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("بالای صفحه اصلی","پایین صفحه اصلی"));setSelection(if(prefs.getString("ticker_position","top")=="bottom")1 else 0)}
        val colorNames=arrayOf("سبز زمردی","آبی","طلایی","بنفش","قرمز","هماهنگ با متن تم")
        val color=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,colorNames);setSelection(prefs.getInt("ticker_color",0).coerceIn(0,5))}
        val size=SeekBar(this).apply{max=14;progress=(prefs.getInt("ticker_size",13)-10).coerceIn(0,14)}
        val speed=SeekBar(this).apply{max=4;progress=(prefs.getInt("ticker_speed",3)-1).coerceIn(0,4)}
        box.addView(text("پیام‌ها (هر پیام در یک خط؛ چند پیام پشت سر هم نمایش داده می‌شوند)",14f,green,true));box.addView(messages)
        box.addView(text("شیوه نمایش",14f,green,true));box.addView(mode)
        box.addView(text("محل نمایش",14f,green,true));box.addView(position)
        box.addView(text("رنگ نوشته",14f,green,true));box.addView(color)
        box.addView(text("اندازه نوشته: ${size.progress+10}",13f));box.addView(size)
        box.addView(text("سرعت حرکت: ${speed.progress+1} از ۵",13f));box.addView(speed)
        box.addView(text("برای توقف موقت نوار متحرک، آن را لمس کنید. پیام‌های تزئینی جایگزین هشدارهای مهم برنامه نیستند.",12f,red))
        AlertDialog.Builder(this).setTitle("تنظیم نوار پیام").setView(styleDialogView(ScrollView(this).apply{addView(box)})).setNegativeButton("انصراف",null).setPositiveButton("ذخیره پیام‌ها و تنظیمات"){_,_->
            val arr=JSONArray();messages.text.toString().lines().map{it.trim()}.filter{it.isNotBlank()}.take(20).forEach{arr.put(it)}
            prefs.edit().putString("ticker_messages",arr.toString()).putBoolean("ticker_moving",mode.selectedItemPosition==0)
                .putString("ticker_position",if(position.selectedItemPosition==1)"bottom" else "top")
                .putInt("ticker_color",color.selectedItemPosition).putInt("ticker_size",size.progress+10).putInt("ticker_speed",speed.progress+1).apply()
            toast("تنظیمات نوار پیام ذخیره شد");showHome()
        }.show()
    }
    private fun applyAppearanceBackground(target:View){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val raw=prefs.getString("appearance_background_uri","") ?: ""
        if(raw.isBlank()) return
        try {
            val uri=Uri.parse(raw)
            val bitmap=contentResolver.openInputStream(uri).use { input -> if(input==null) null else BitmapFactory.decodeStream(input) }
            if(bitmap!=null){
                val drawable=BitmapDrawable(resources,bitmap)
                drawable.alpha=prefs.getInt("appearance_background_alpha",110).coerceIn(35,220)
                target.background=drawable
            }
        } catch (_:Exception) { prefs.edit().remove("appearance_background_uri").apply() }
    }
    private fun showAppearanceBackgroundSettings(){
        base("پس‌زمینه دلخواه") { showAppearanceSettings() }
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val preview=ImageView(this).apply { layoutParams=LinearLayout.LayoutParams(-1,220);scaleType=ImageView.ScaleType.CENTER_CROP;setBackgroundColor(pale) }
        fun refreshPreview(){
            val raw=prefs.getString("appearance_background_uri","") ?: ""
            if(raw.isBlank()){preview.setImageDrawable(null);preview.setBackgroundColor(pale);return}
            try{contentResolver.openInputStream(Uri.parse(raw)).use{stream->preview.setImageBitmap(if(stream==null)null else BitmapFactory.decodeStream(stream))}}catch(_:Exception){preview.setImageDrawable(null)}
        }
        val dim=SeekBar(this).apply{max=185;progress=(prefs.getInt("appearance_background_alpha",110)-35).coerceIn(0,185)}
        root.addView(text("تصویر انتخابی فقط به‌عنوان پس‌زمینه نمایش داده می‌شود؛ اطلاعات برنامه و سوابق مالی تغییری نمی‌کنند.",13f,green))
        root.addView(preview);root.addView(text("شدت نمایش تصویر (کمتر = محوتر/تیره‌تر)",13f,green,true));root.addView(dim)
        refreshPreview()
        root.addView(btn("انتخاب تصویر از گالری"){try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},requestChooseAppearanceBackground)}catch(e:Exception){toast("باز کردن گالری ممکن نیست")}})
        root.addView(btn("ذخیره شدت نمایش"){prefs.edit().putInt("appearance_background_alpha",dim.progress+35).apply();showAppearanceBackgroundSettings()})
        root.addView(btn("حذف پس‌زمینه دلخواه"){prefs.edit().remove("appearance_background_uri").apply();toast("پس‌زمینه حذف شد");showAppearanceBackgroundSettings()})
        root.addView(btn("بازگشت به تنظیمات ظاهر"){showAppearanceSettings()})
    }
    private val appearanceProfileLock = Any()
    private val appearanceProfileKeys = setOf(
        "customization_mode", "theme", "home_layout", "icon_style", "ticker_enabled", "motion_enabled", "auto_night",
        "appearance_schedule_mode", "appearance_night_start", "appearance_night_end",
        "ticker_color", "ticker_size", "ticker_speed", "ticker_moving", "ticker_position", "ticker_messages",
        "appearance_background_uri", "appearance_background_alpha", "launcher_icon", "widget_order", "widget_hidden",
        "focus_mode", "senior_mode", "dashboard_page", "font_scale"
    )

    private fun normalizeAppearanceProfileName(value:String):String = AppearanceProfileRules.normalizeName(value)

    private fun validAppearanceProfileName(name:String):Boolean = AppearanceProfileRules.isValidName(name)

    private fun appearanceProfileKey(name:String) = "appearance_profile_v2_" + name

    /** v2 entries take precedence over a legacy entry with the same normalized name. */
    private fun appearanceProfileEntries(prefs:SharedPreferences):List<Triple<String,String,Boolean>> {
        return prefs.all.keys
            .filter { it.startsWith("appearance_profile_v2_") || it.startsWith("appearance_profile_") }
            .map { key ->
                val isV2=key.startsWith("appearance_profile_v2_")
                Triple(if(isV2) key.removePrefix("appearance_profile_v2_") else key.removePrefix("appearance_profile_"),key,isV2)
            }
            .filter { it.first.isNotBlank() }
            .sortedWith(compareByDescending<Triple<String,String,Boolean>> { it.third }.thenBy { it.first })
            .distinctBy { normalizeAppearanceProfileName(it.first) }
    }

    private fun saveAppearanceProfile(name:String){
        val clean=name.trim()
        if(!validAppearanceProfileName(clean)){toast("نام پروفایل باید بین ۱ تا ۴۰ نویسه باشد");return}
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        synchronized(appearanceProfileLock){
            val key=appearanceProfileKey(clean)
            val legacyKey="appearance_profile_"+clean
            val entries=appearanceProfileEntries(prefs)
            val duplicate=entries.firstOrNull {
                normalizeAppearanceProfileName(it.first)==normalizeAppearanceProfileName(clean) && it.second!=key && it.second!=legacyKey
            }
            if(duplicate!=null){toast("پروفایلی با این نام یا شکل نوشتاری مشابه وجود دارد");return}
            if(!prefs.contains(key) && entries.size>=30){toast("حداکثر ۳۰ پروفایل قابل ذخیره است");return}

            val snapshot=JSONObject()
            appearanceProfileKeys.forEach { keyName ->
                if(!prefs.contains(keyName)) return@forEach
                val value=prefs.all[keyName] ?: return@forEach
                val item=JSONObject()
                when(value){
                    is String -> item.put("type","string").put("value",value)
                    is Boolean -> item.put("type","boolean").put("value",value)
                    is Int -> item.put("type","int").put("value",value)
                    is Long -> item.put("type","long").put("value",value)
                    is Float -> {
                        if(!value.isFinite()){toast("یکی از تنظیمات ظاهری مقدار نامعتبر دارد");return}
                        item.put("type","float").put("value",value.toDouble())
                    }
                    is Set<*> -> {
                        val strings=value.filterIsInstance<String>()
                        if(strings.size!=value.size){toast("مجموعه تنظیمات ظاهری معتبر نیست");return}
                        val arr=JSONArray();strings.forEach{arr.put(it)}
                        item.put("type","string_set").put("value",arr)
                    }
                    else -> { toast("نوع یکی از تنظیمات ظاهری پشتیبانی نمی‌شود");return }
                }
                snapshot.put(keyName,item)
            }
            val payload=JSONObject().put("format",2).put("saved_at",System.currentTimeMillis()).put("settings",snapshot).toString()
            val editor=prefs.edit().putString(key,payload)
            if(prefs.contains(legacyKey)) editor.remove(legacyKey)
            if(editor.commit()) toast("پروفایل «$clean» ذخیره شد") else toast("ذخیره پروفایل ناموفق بود")
        }
    }

    private fun applyAppearanceProfile(name:String,raw:String){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        try{
            if(raw.isBlank()) throw IllegalArgumentException("محتوای پروفایل خالی است")
            val editor=prefs.edit()
            if(raw.trimStart().startsWith("{")){
                val root=JSONObject(raw)
                if(root.optInt("format",-1)!=2) throw IllegalArgumentException("نسخه قالب پروفایل پشتیبانی نمی‌شود")
                val settings=root.optJSONObject("settings") ?: throw IllegalArgumentException("ساختار پروفایل معتبر نیست")
                val decoded=linkedMapOf<String,Any>()
                val keys=settings.keys()
                while(keys.hasNext()){
                    val key=keys.next()
                    if(key !in appearanceProfileKeys) continue
                    val item=settings.optJSONObject(key) ?: throw IllegalArgumentException("مقدار تنظیم «$key» خراب است")
                    val value=item.opt("value")
                    val decodedValue:Any=when(item.optString("type")){
                        "string" -> value as? String ?: throw IllegalArgumentException("مقدار متنی «$key» نامعتبر است")
                        "boolean" -> value as? Boolean ?: throw IllegalArgumentException("مقدار منطقی «$key» نامعتبر است")
                        "int" -> (value as? Number)?.toDouble()?.let { if(it.isFinite() && it%1.0==0.0 && it in Int.MIN_VALUE.toDouble()..Int.MAX_VALUE.toDouble()) it.toInt() else null } ?: throw IllegalArgumentException("عدد «$key» نامعتبر است")
                        "long" -> (value as? Number)?.toDouble()?.let { if(it.isFinite() && it%1.0==0.0 && it>=Long.MIN_VALUE.toDouble() && it<=Long.MAX_VALUE.toDouble()) it.toLong() else null } ?: throw IllegalArgumentException("عدد «$key» نامعتبر است")
                        "float" -> (value as? Number)?.toFloat()?.takeIf { it.isFinite() } ?: throw IllegalArgumentException("عدد اعشاری «$key» نامعتبر است")
                        "string_set" -> {
                            val arr=value as? JSONArray ?: throw IllegalArgumentException("فهرست «$key» نامعتبر است")
                            val set=(0 until arr.length()).map { arr.opt(it) as? String ?: throw IllegalArgumentException("عضو فهرست «$key» نامعتبر است") }.toSet()
                            set
                        }
                        else -> throw IllegalArgumentException("نوع داده «$key» پشتیبانی نمی‌شود")
                    }
                    decoded[key]=decodedValue
                }
                validateAppearanceProfileSettings(decoded)
                if(!settings.has("appearance_schedule_mode")) editor.remove("appearance_schedule_mode").remove("appearance_night_start").remove("appearance_night_end")
                decoded.forEach { (key,value) ->
                    when(value){
                        is String -> editor.putString(key,value)
                        is Boolean -> editor.putBoolean(key,value)
                        is Int -> editor.putInt(key,value)
                        is Long -> editor.putLong(key,value)
                        is Float -> editor.putFloat(key,value)
                        is Set<*> -> editor.putStringSet(key,value.filterIsInstance<String>().toSet())
                    }
                }
            }else{
                // سازگاری با پروفایل‌های قدیمی نسخه‌های پیشین
                val v=raw.split('|')
                if(v.size<7) throw IllegalArgumentException("پروفایل قدیمی ناقص است")
                val mode=v[0].toIntOrNull() ?: throw IllegalArgumentException("حالت شخصی‌سازی نامعتبر است")
                val themeIndex=v[1].toIntOrNull() ?: throw IllegalArgumentException("تم رنگی نامعتبر است")
                val layoutIndex=v[2].toIntOrNull() ?: throw IllegalArgumentException("چیدمان نامعتبر است")
                val iconIndex=v[3].toIntOrNull() ?: throw IllegalArgumentException("سبک آیکون نامعتبر است")
                if(mode !in 0..1 || themeIndex !in homePalettes.indices || layoutIndex !in 0..7 || iconIndex !in 0..5) throw IllegalArgumentException("مقادیر پروفایل قدیمی خارج از محدوده‌اند")
                editor.remove("appearance_schedule_mode").remove("appearance_night_start").remove("appearance_night_end")
                editor.putInt("customization_mode",mode)
                    .putInt("theme",themeIndex)
                    .putInt("home_layout",layoutIndex)
                    .putInt("icon_style",iconIndex)
                    .putBoolean("ticker_enabled",v[4].toBooleanStrictOrNull() ?: throw IllegalArgumentException("وضعیت نوار پیام نامعتبر است"))
                    .putBoolean("motion_enabled",v[5].toBooleanStrictOrNull() ?: throw IllegalArgumentException("وضعیت حرکت نامعتبر است"))
                    .putBoolean("auto_night",v[6].toBooleanStrictOrNull() ?: throw IllegalArgumentException("وضعیت تم شب نامعتبر است"))
                if(v.size>=12){
                    val color=v[7].toIntOrNull() ?: throw IllegalArgumentException("رنگ نوار پیام نامعتبر است")
                    val size=v[8].toIntOrNull() ?: throw IllegalArgumentException("اندازه نوار پیام نامعتبر است")
                    val speed=v[9].toIntOrNull() ?: throw IllegalArgumentException("سرعت نوار پیام نامعتبر است")
                    if(color !in 0..5 || size !in 10..24 || speed !in 1..5) throw IllegalArgumentException("تنظیمات نوار پیام خارج از محدوده‌اند")
                    editor.putInt("ticker_color",color).putInt("ticker_size",size).putInt("ticker_speed",speed)
                        .putBoolean("ticker_moving",v[10].toBooleanStrictOrNull() ?: throw IllegalArgumentException("حالت حرکت نوار پیام نامعتبر است"))
                        .putString("ticker_position",if(v[11]=="bottom") "bottom" else "top")
                }
            }
            if(!editor.commit()) throw IllegalStateException("ذخیره تنظیمات پروفایل انجام نشد")
            val launcher=prefs.getInt("launcher_icon",0).coerceIn(0,3)
            val aliases=arrayOf("LauncherEmerald","LauncherGold","LauncherBlue","LauncherModern")
            aliases.forEachIndexed { i,alias ->
                val component=android.content.ComponentName(this,"ir.kambiz.daftar.$alias")
                packageManager.setComponentEnabledSetting(component,if(i==launcher) android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED else android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,android.content.pm.PackageManager.DONT_KILL_APP)
            }
            toast("پروفایل «$name» اعمال شد");showHome()
        }catch(e:Exception){toast("اعمال پروفایل ممکن نشد: ${e.message?:"خطای نامشخص"}")}
    }

    private fun validateAppearanceProfileSettings(values:Map<String,Any>){
        fun intValue(key:String,range:IntRange){ (values[key] as? Int)?.let { if(it !in range) throw IllegalArgumentException("تنظیم «$key» خارج از محدوده است") } }
        intValue("customization_mode",0..1)
        intValue("theme",homePalettes.indices)
        intValue("home_layout",0..7)
        intValue("icon_style",0..5)
        intValue("ticker_color",0..5)
        intValue("ticker_size",10..24)
        intValue("ticker_speed",1..5)
        intValue("appearance_night_start",0..1439)
        intValue("appearance_night_end",0..1439)
        intValue("appearance_background_alpha",35..220)
        intValue("launcher_icon",0..3)
        (values["font_scale"] as? Float)?.let { if(it !in 0.85f..1.30f) throw IllegalArgumentException("اندازه نوشته‌ها خارج از محدوده است") }
        (values["ticker_position"] as? String)?.let { if(it !in setOf("top","bottom")) throw IllegalArgumentException("جایگاه نوار پیام نامعتبر است") }
        (values["appearance_schedule_mode"] as? String)?.let { if(it !in setOf(AppearanceSchedule.MODE_OFF,AppearanceSchedule.MODE_SCHEDULED)) throw IllegalArgumentException("حالت زمان‌بندی نامعتبر است") }
        if(values["appearance_schedule_mode"]==AppearanceSchedule.MODE_SCHEDULED){
            val start=values["appearance_night_start"] as? Int
            val end=values["appearance_night_end"] as? Int
            if(start!=null && end!=null && start==end) throw IllegalArgumentException("شروع و پایان تم شب نمی‌توانند برابر باشند")
        }
    }

    private fun showAppearanceProfiles(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val entries=synchronized(appearanceProfileLock){appearanceProfileEntries(prefs)}
        if(entries.isEmpty()){toast("هنوز پروفایل ظاهری ذخیره نشده است");return}
        AlertDialog.Builder(this).setTitle("پروفایل‌های ظاهری").setItems(entries.map{it.first}.toTypedArray()){_,index ->
            val (name,key,_)=entries[index]
            val raw=synchronized(appearanceProfileLock){prefs.getString(key,"") ?: ""}
            AlertDialog.Builder(this).setTitle(name).setItems(arrayOf("اعمال پروفایل","ذخیره با نام جدید (کپی)","تغییر نام","حذف پروفایل")){_,action ->
                when(action){
                    0 -> applyAppearanceProfile(name,raw)
                    1,2 -> {
                        val input=EditText(this).apply { setText(if(action==1) "$name - کپی" else name);hint="نام پروفایل" }
                        AlertDialog.Builder(this).setTitle(if(action==1) "کپی پروفایل" else "تغییر نام پروفایل").setView(input).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_ ->
                            val newName=input.text.toString().trim()
                            if(!validAppearanceProfileName(newName)){toast("نام باید بین ۱ تا ۴۰ نویسه باشد");return@setPositiveButton}
                            synchronized(appearanceProfileLock){
                                if(!prefs.contains(key)){toast("این پروفایل دیگر وجود ندارد");return@synchronized}
                                if(action==2 && normalizeAppearanceProfileName(newName)==normalizeAppearanceProfileName(name)){toast("نام جدید با نام فعلی یکسان است");return@synchronized}
                                val newKey=appearanceProfileKey(newName)
                                val duplicate=appearanceProfileEntries(prefs).firstOrNull {
                                    normalizeAppearanceProfileName(it.first)==normalizeAppearanceProfileName(newName) && it.second!=key
                                }
                                if(duplicate!=null){toast("پروفایلی با این نام یا شکل نوشتاری مشابه وجود دارد");return@synchronized}
                                if(action==1 && appearanceProfileEntries(prefs).size>=30){toast("حداکثر ۳۰ پروفایل قابل ذخیره است");return@synchronized}
                                if(newKey==key){toast("نام پروفایل تغییری نکرده است");return@synchronized}
                                val editor=prefs.edit().putString(newKey,raw)
                                if(action==2) editor.remove(key)
                                if(editor.commit()) toast(if(action==1) "کپی پروفایل ذخیره شد" else "نام پروفایل تغییر کرد") else toast("ذخیره تغییر نام ناموفق بود")
                            }
                            showAppearanceProfiles()
                        }.show()
                    }
                    3 -> AlertDialog.Builder(this).setMessage("پروفایل «$name» حذف شود؟ تنظیمات فعلی برنامه تغییر نمی‌کند.").setNegativeButton("انصراف",null).setPositiveButton("حذف"){_,_ ->
                        val deleted=synchronized(appearanceProfileLock){ if(prefs.contains(key)) prefs.edit().remove(key).commit() else false }
                        toast(if(deleted) "پروفایل حذف شد" else "حذف پروفایل انجام نشد یا پروفایل قبلاً حذف شده است")
                        showAppearanceProfiles()
                    }.show()
                }
            }.show()
        }.show()
    }
    private fun showAppearancePolicySettings(){
        val prefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8)}
        val full=styledCheckBox().apply{text="اجازه آزادی کامل شخصی‌سازی";isChecked=prefs.getBoolean("policy_allow_full",true)}
        val themes=styledCheckBox().apply{text="اجازه تغییر تم رنگی";isChecked=prefs.getBoolean("policy_allow_theme",true)}
        val layouts=styledCheckBox().apply{text="اجازه تغییر چیدمان";isChecked=prefs.getBoolean("policy_allow_layout",true)}
        val icons=styledCheckBox().apply{text="اجازه تغییر سبک آیکون";isChecked=prefs.getBoolean("policy_allow_icons",true)}
        val backgrounds=styledCheckBox().apply{text="اجازه تغییر پس‌زمینه دلخواه";isChecked=prefs.getBoolean("policy_allow_background",true)}
        val motion=styledCheckBox().apply{text="اجازه جلوه‌های حرکتی";isChecked=prefs.getBoolean("policy_allow_motion",true)}
        listOf(full,themes,layouts,icons,backgrounds,motion).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("سیاست شخصی‌سازی مدیر دستگاه").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره سیاست‌ها"){_,_->prefs.edit().putBoolean("policy_allow_full",full.isChecked).putBoolean("policy_allow_theme",themes.isChecked).putBoolean("policy_allow_layout",layouts.isChecked).putBoolean("policy_allow_icons",icons.isChecked).putBoolean("policy_allow_background",backgrounds.isChecked).putBoolean("policy_allow_motion",motion.isChecked).apply();toast("سیاست‌های محلی ذخیره شد")}.show()
    }
    private fun catalogPrefs() = getSharedPreferences("catalog_customization", Context.MODE_PRIVATE)
    /** انتقال تنظیمات نمایشی شاخه قدیمی ۱۰۳ به جایگاه جاری ۲۲؛ شناسه قابلیت‌ها تغییر نمی‌کنند. */
    private fun migrateCatalogSection103To22(){
        val prefs=catalogPrefs();val editor=prefs.edit()
        listOf("section_names","section_icons","section_colors").forEach{key->
            val obj=try{JSONObject(prefs.getString(key,"{}")?:"{}")}catch(_:Exception){JSONObject()}
            if(!obj.has("22")&&obj.has("103"))obj.put("22",obj.opt("103"))
            obj.remove("103");editor.putString(key,obj.toString())
        }
        listOf("feature_parents","feature_previous_parent").forEach{key->
            val obj=try{JSONObject(prefs.getString(key,"{}")?:"{}")}catch(_:Exception){JSONObject()}
            val keys=obj.keys();val updates=mutableListOf<String>()
            while(keys.hasNext()){val k=keys.next();if(obj.optInt(k,-1)==103)updates.add(k)}
            updates.forEach{obj.put(it,22)};editor.putString(key,obj.toString())
        }
        val oldFeatureOrder=prefs.getString("feature_order_103",null)
        if(prefs.getString("feature_order_22",null)==null&&oldFeatureOrder!=null)editor.putString("feature_order_22",oldFeatureOrder)
        editor.remove("feature_order_103")
        val order=try{JSONArray(prefs.getString("section_order","[]")?:"[]")}catch(_:Exception){JSONArray()}
        val migrated=JSONArray();val seen=mutableSetOf<Int>()
        for(i in 0 until order.length()){val n=if(order.optInt(i)==103)22 else order.optInt(i);if(n>0&&seen.add(n))migrated.put(n)}
        if(order.length()>0)editor.putString("section_order",migrated.toString())
        editor.apply()
    }
    private fun catalogJson(key:String):JSONObject = try { JSONObject(catalogPrefs().getString(key,"{}") ?: "{}") } catch(_:Exception) { JSONObject() }
    private fun catalogArray(key:String):JSONArray = try { JSONArray(catalogPrefs().getString(key,"[]") ?: "[]") } catch(_:Exception) { JSONArray() }
    private fun saveCatalogJson(key:String,obj:JSONObject){catalogPrefs().edit().putString(key,obj.toString()).apply()}
    private fun featureParents():JSONObject = catalogJson("feature_parents")
    private fun favoriteIds():MutableSet<Int>{val a=catalogArray("favorite_ids");return (0 until a.length()).mapNotNull{a.optInt(it,-1).takeIf{x->x>0}}.toMutableSet()}
    private fun catalogFeatureName(id:Int,default:String):String = catalogJson("feature_names").optString(id.toString(),default)
    private fun catalogFeatureIcon(id:Int,default:String):String = catalogJson("feature_icons").optString(id.toString(),default)
    private fun catalogFeatureColor(id:Int):Int = catalogJson("feature_colors").optInt(id.toString(),0xff263b50.toInt())
    private fun sectionDisplayName(sec:ProgramCatalogSection):String = catalogJson("section_names").optString(sec.number.toString(),sec.title)
    private fun sectionDisplayIcon(sec:ProgramCatalogSection):String = catalogJson("section_icons").optString(sec.number.toString(),sec.icon)
    private fun sectionDisplayColor(sec:ProgramCatalogSection):Int = catalogJson("section_colors").optInt(sec.number.toString(),0xffd8e9f8.toInt())
    private fun catalogSectionsForUi():List<ProgramCatalogSection>{
        val parents=featureParents(); val fav=favoriteIds()
        val base=ProgramCatalog.sections.filter{it.number!=104}.map{sec->
            val fs=ProgramCatalog.sections.flatMap{owner->owner.features.filter{f->(parents.optInt(f.first.toString(),owner.number)==sec.number) && !fav.contains(f.first)}}
            val order=catalogArray("feature_order_${sec.number}");val rank=(0 until order.length()).associate{order.optInt(it) to it}
            sec.copy(title=sectionDisplayName(sec),icon=sectionDisplayIcon(sec),features=fs.sortedBy{rank[it.first]?:Int.MAX_VALUE})
        }
        val favorites=ProgramCatalog.sections.flatMap{it.features}.filter{fav.contains(it.first)}
        val order=catalogArray("section_order");val rank=(0 until order.length()).associate{order.optInt(it) to it}
        return base.sortedBy{rank[it.number]?:Int.MAX_VALUE} + ProgramCatalogSection(104,"منتخب‌ها","⭐",favorites)
    }
    private fun setFeatureFavorite(id:Int,enabled:Boolean){
        val fav=favoriteIds(); if(enabled)fav.add(id) else fav.remove(id)
        val a=JSONArray();fav.sorted().forEach{a.put(it)};catalogPrefs().edit().putString("favorite_ids",a.toString()).apply()
        val parents=featureParents(); if(enabled){val previous=catalogJson("feature_previous_parent");previous.put(id.toString(),parents.optInt(id.toString(),ProgramCatalog.sections.firstOrNull{sec->sec.features.any{it.first==id}}?.number?:1));saveCatalogJson("feature_previous_parent",previous);parents.put(id.toString(),104)} else {val previous=catalogJson("feature_previous_parent");val original=previous.optInt(id.toString(),ProgramCatalog.sections.firstOrNull{sec->sec.features.any{it.first==id}}?.number?:1);parents.put(id.toString(),original);previous.remove(id.toString());saveCatalogJson("feature_previous_parent",previous)};saveCatalogJson("feature_parents",parents)
        catalogHistory("favorite",id,"${if(enabled)"منتخب‌ها" else "بخش اصلی"}")
    }
    private fun moveCatalogFeature(id:Int,destination:Int){
        val from=featureParents().optInt(id.toString(),ProgramCatalog.sections.firstOrNull{sec->sec.features.any{it.first==id}}?.number ?: 1)
        val parents=featureParents();if(destination==104){val previous=catalogJson("feature_previous_parent");previous.put(id.toString(),from);saveCatalogJson("feature_previous_parent",previous)};parents.put(id.toString(),destination);saveCatalogJson("feature_parents",parents)
        val fav=favoriteIds();if(destination==104)fav.add(id) else {fav.remove(id);val previous=catalogJson("feature_previous_parent");previous.remove(id.toString());saveCatalogJson("feature_previous_parent",previous)};val a=JSONArray();fav.sorted().forEach{a.put(it)};catalogPrefs().edit().putString("favorite_ids",a.toString()).apply()
        catalogHistory("move",id,"$from → $destination")
    }
    private fun moveCatalogFeatureOrder(sectionNumber:Int,id:Int,direction:Int){
        val section=catalogSectionsForUi().firstOrNull{it.number==sectionNumber}?:return
        val ids=section.features.map{it.first}.toMutableList();val index=ids.indexOf(id);val target=index+direction
        if(index<0||target !in ids.indices)return
        val value=ids[index];ids[index]=ids[target];ids[target]=value
        val order=JSONArray();ids.forEach{order.put(it)}
        catalogPrefs().edit().putString("feature_order_${sectionNumber}",order.toString()).apply()
        catalogHistory("feature_order",id,"جابجایی زیرشاخه در شاخه $sectionNumber")
    }
    private fun catalogHistory(action:String,id:Int,detail:String){
        val a=catalogArray("history");a.put(JSONObject().put("action",action).put("feature_id",id).put("detail",detail).put("at",System.currentTimeMillis()));catalogPrefs().edit().putString("history",a.toString()).apply()
    }
    private fun editCatalogSection(sec:ProgramCatalogSection,refresh:()->Unit){
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8)}
        val name=EditText(this).apply{hint="نام نمایشی بخش";setText(sectionDisplayName(sec))};val icon=EditText(this).apply{hint="آیکون یا ایموجی";setText(sectionDisplayIcon(sec))}
        layout.addView(name);layout.addView(icon)
        val colors=linkedMapOf("آبی" to 0xffd8e9f8.toInt(),"سبز" to 0xffd9efdf.toInt(),"طلایی" to 0xffffedc2.toInt(),"بنفش" to 0xffe9ddf7.toInt(),"صورتی" to 0xffffe0e8.toInt(),"خاکستری" to 0xffe5e7eb.toInt())
        var chosen=sectionDisplayColor(sec);val colorButton=Button(this).apply{text="انتخاب رنگ";isAllCaps=false;setOnClickListener{AlertDialog.Builder(this@MainActivity).setTitle("رنگ بخش").setItems(colors.keys.toTypedArray()){_,i->chosen=colors.values.elementAt(i);setBackgroundColor(chosen)}.show()}}
        layout.addView(colorButton)
        AlertDialog.Builder(this).setTitle("شخصی‌سازی بخش ${sec.number}").setView(layout).setNegativeButton("انصراف",null).setNeutralButton("بازگشت به پیش‌فرض"){_,_->listOf("section_names","section_icons","section_colors").forEach{key->val o=catalogJson(key);o.remove(sec.number.toString());saveCatalogJson(key,o)};refresh()}.setPositiveButton("پیش‌نمایش"){_,_->
            val n=name.text.toString().trim();val ic=icon.text.toString().trim();if(n.isEmpty()||ic.isEmpty()){toast("نام و آیکون نباید خالی باشند");return@setPositiveButton}
            AlertDialog.Builder(this).setTitle("پیش‌نمایش تغییرات").setMessage("$ic  $n\nرنگ انتخابی: $chosen\nشناسه بخش ${sec.number} بدون تغییر می‌ماند.").setNegativeButton("بازگشت به ویرایش",null).setPositiveButton("تأیید و ذخیره"){_,_->saveCatalogJson("section_names",catalogJson("section_names").put(sec.number.toString(),n));saveCatalogJson("section_icons",catalogJson("section_icons").put(sec.number.toString(),ic));saveCatalogJson("section_colors",catalogJson("section_colors").put(sec.number.toString(),chosen));catalogHistory("section_style",sec.number,"$n / $ic / $chosen");refresh()}.show()
        }.show()
    }
    private fun editCatalogFeature(id:Int,defaultName:String,defaultIcon:String,refresh:()->Unit){
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8)}
        val name=EditText(this).apply{hint="نام نمایشی قابلیت";setText(catalogFeatureName(id,defaultName))};val icon=EditText(this).apply{hint="آیکون";setText(catalogFeatureIcon(id,defaultIcon))};layout.addView(name);layout.addView(icon)
        val colors=linkedMapOf("آبی" to 0xff263b50.toInt(),"سبز" to 0xff247447.toInt(),"قرمز" to 0xffa83232.toInt(),"بنفش" to 0xff7040a0.toInt(),"نارنجی" to 0xffa65c12.toInt(),"خاکستری" to 0xff60656d.toInt());var chosen=catalogFeatureColor(id)
        val color=Button(this).apply{text="انتخاب رنگ قابلیت";isAllCaps=false;setOnClickListener{AlertDialog.Builder(this@MainActivity).setTitle("رنگ قابلیت").setItems(colors.keys.toTypedArray()){_,i->chosen=colors.values.elementAt(i);setTextColor(chosen)}.show()}};layout.addView(color)
        AlertDialog.Builder(this).setTitle("تنظیم قابلیت شماره $id").setView(layout).setNegativeButton("انصراف",null).setNeutralButton("بازگشت به پیش‌فرض"){_,_->listOf("feature_names","feature_icons","feature_colors").forEach{key->val o=catalogJson(key);o.remove(id.toString());saveCatalogJson(key,o)};refresh()}.setPositiveButton("پیش‌نمایش"){_,_->if(name.text.toString().isBlank()||icon.text.toString().isBlank()){toast("نام و آیکون لازم است");return@setPositiveButton};val n=name.text.toString().trim();val ic=icon.text.toString().trim();AlertDialog.Builder(this).setTitle("پیش‌نمایش قابلیت").setMessage("$ic  $id. $n\nرنگ: $chosen\nشناسه قابلیت ثابت می‌ماند.").setNegativeButton("بازگشت به ویرایش",null).setPositiveButton("تأیید و ذخیره"){_,_->saveCatalogJson("feature_names",catalogJson("feature_names").put(id.toString(),n));saveCatalogJson("feature_icons",catalogJson("feature_icons").put(id.toString(),ic));saveCatalogJson("feature_colors",catalogJson("feature_colors").put(id.toString(),chosen));catalogHistory("feature_style",id,"$n / $ic / $chosen");refresh()}.show()}.show()
    }
    private fun showMoveFeatureDialog(id:Int,refresh:()->Unit){
        val sections=catalogSectionsForUi().filter{it.number!=104};val labels=sections.map{"${it.number}. ${it.title}"}.toTypedArray()
        AlertDialog.Builder(this).setTitle("انتقال قابلیت $id به بخش مقصد").setItems(labels){_,which->val dest=sections[which];AlertDialog.Builder(this).setMessage("قابلیت با شناسه ثابت $id از بخش فعلی به «${dest.title}» منتقل شود؟ داده و شناسه تغییر نمی‌کند.").setNegativeButton("انصراف",null).setPositiveButton("تأیید انتقال"){_,_->moveCatalogFeature(id,dest.number);refresh()}.show()}.setNegativeButton("انصراف",null).show()
    }
    private fun showProgramCatalog(query:String="", expanded:MutableSet<Int> = mutableSetOf()){
        base("فهرست کامل امکانات برنامه"){showHome()}
        val catalogPrefs=getSharedPreferences("home_dashboard",Context.MODE_PRIVATE)
        val catalogPalette=currentPalette()
        val catalogIconStyle=catalogPrefs.getInt("icon_style",0).coerceIn(0,5)
        root.setBackgroundColor(catalogPalette.background)
        root.addView(text("۱۰۲ شاخه فعال • زیرشاخه‌های ثبت‌شده • شناسه‌های پایه ۱ تا ۵۲۵ ثابت هستند",13f,0xff365b7d.toInt(),true))
        root.addView(btn("⚙️ مدیریت ظاهر و چیدمان بخش‌ها") { showCatalogManagement() })
        val search=field("جست‌وجوی نام بخش یا قابلیت");search.setText(query);root.addView(search)
        root.addView(btn("🔎 جست‌وجو") { val q=search.text.toString().trim();val matches=catalogSectionsForUi().filter{sec->q.isNotEmpty()&&(sec.title.contains(q,true)||sec.features.any{catalogFeatureName(it.first,it.second).contains(q,true)})}.map{it.number}.toMutableSet();showProgramCatalog(q,matches) })
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};actions.addView(btn("بازکردن همه"){showProgramCatalog(query,catalogSectionsForUi().map{it.number}.toMutableSet())},LinearLayout.LayoutParams(0,-2,1f));actions.addView(btn("بستن همه"){showProgramCatalog(query,mutableSetOf())},LinearLayout.LayoutParams(0,-2,1f));root.addView(actions)
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,4,0,12)};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val q=query.trim();val sections=catalogSectionsForUi();val matches=sections.filter{sec->q.isEmpty()||sec.title.contains(q,true)||sec.features.any{catalogFeatureName(it.first,it.second).contains(q,true)}}
        if(matches.isEmpty())list.addView(text("موردی با این عبارت پیدا نشد.",14f,red,true))
        matches.forEach{sec->
            val opened=expanded.contains(sec.number)
            val sectionTint=if(sec.number==104)catalogPalette.soft else sectionDisplayColor(ProgramCatalog.sections.firstOrNull{it.number==sec.number}?:sec)
            val card=card().apply{setBackgroundColor(catalogPalette.card);background=GradientDrawable().apply{setColor(catalogPalette.card);cornerRadius=18f;setStroke(2,sectionTint)}}
            val header=Button(this).apply{text="${sec.icon}  بخش ${sec.number}. ${sec.title}   ${if(opened)"⌃" else "⌄"}";isAllCaps=false;textSize=15f;gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL;setTextColor(catalogPalette.text);background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(sectionTint,catalogPalette.soft,catalogPalette.accent)).apply{cornerRadius=16f;setStroke(1,catalogPalette.deep)};elevation=if(catalogIconStyle==2||catalogIconStyle==3)9f else 3f;setOnClickListener{val next=expanded.toMutableSet();if(opened)next.remove(sec.number)else next.add(sec.number);showProgramCatalog(query,next)}}
            card.addView(header)
            if(opened){
                if(sec.number!=104)card.addView(btn("تنظیم نام، آیکون و رنگ این بخش"){editCatalogSection(sec){showProgramCatalog(query,expanded)}})
                if(sec.features.isEmpty())card.addView(text("فعلاً خالی است؛ قابلیت‌های پرکاربرد را خودتان به منتخب‌ها منتقل کنید.",13f,0xff54718c.toInt()))
                val titleMatches=q.isNotEmpty()&&sec.title.contains(q,true);val shown=if(q.isEmpty()||titleMatches)sec.features else sec.features.filter{catalogFeatureName(it.first,it.second).contains(q,true)}
                shown.forEach{feature->
                    val id=feature.first;val defaultIcon=featureIcon(feature.second);val label=catalogFeatureName(id,feature.second);val icon=catalogFeatureIcon(id,defaultIcon)
                    val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,6,8,6)}
                    val featureHead=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL}
                    val badgeColors=when(catalogIconStyle){0->intArrayOf(catalogPalette.soft,catalogPalette.accent);1->intArrayOf(0xffffffff.toInt(),catalogPalette.soft,catalogPalette.accent);2->intArrayOf(catalogPalette.accent,catalogPalette.deep);3->intArrayOf(catalogPalette.deep,catalogPalette.accent,catalogPalette.deep);4->intArrayOf(catalogPalette.card,catalogPalette.soft);else->intArrayOf(catalogPalette.accent,0xff8b6bd1.toInt(),catalogPalette.deep)}
                    val featureBadge=TextView(this).apply{text=icon;textSize=18f;gravity=Gravity.CENTER;background=GradientDrawable(GradientDrawable.Orientation.TL_BR,badgeColors).apply{shape=if(catalogIconStyle==4)GradientDrawable.RECTANGLE else GradientDrawable.OVAL;cornerRadius=if(catalogIconStyle==4)12f else 0f;setStroke(if(catalogIconStyle==3)3 else 1,if(catalogIconStyle==3)0xfff6d77a.toInt() else 0x55ffffff)};elevation=when(catalogIconStyle){2,3->10f;4->2f;else->5f};alpha=if(catalogIconStyle==1)0.98f else 1f}
                    featureHead.addView(featureBadge,LinearLayout.LayoutParams(42,42).apply{setMargins(3,2,8,2)})
                    featureHead.addView(text("$id. $label",13f,catalogFeatureColor(id)),LinearLayout.LayoutParams(0,-2,1f))
                    row.addView(featureHead)
                    val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
                    controls.addView(btn(if(sec.number==104)"↩ بازگرداندن" else "⭐ منتخب‌ها"){if(sec.number==104)setFeatureFavorite(id,false) else setFeatureFavorite(id,true);showProgramCatalog(query,expanded)},LinearLayout.LayoutParams(0,-2,1f))
                    controls.addView(btn("↑"){moveCatalogFeatureOrder(sec.number,id,-1);showProgramCatalog(query,expanded)},LinearLayout.LayoutParams(0,-2,0.65f))
                    controls.addView(btn("↓"){moveCatalogFeatureOrder(sec.number,id,1);showProgramCatalog(query,expanded)},LinearLayout.LayoutParams(0,-2,0.65f))
                    controls.addView(btn("⇄ انتقال"){showMoveFeatureDialog(id){showProgramCatalog(query,expanded)}},LinearLayout.LayoutParams(0,-2,1f))
                    controls.addView(btn("✏️ تنظیم"){editCatalogFeature(id,feature.second,defaultIcon){showProgramCatalog(query,expanded)}},LinearLayout.LayoutParams(0,-2,1f))
                    row.addView(controls);card.addView(row);line(card)
                }
                card.addView(text("${shown.size} قابلیت",11f,0xff54718c.toInt()))
            }else if(q.isNotEmpty()){val count=if(sec.title.contains(q,true))sec.features.size else sec.features.count{catalogFeatureName(it.first,it.second).contains(q,true)};card.addView(text("$count نتیجه مرتبط؛ برای نمایش لمس کن",11f,0xff54718c.toInt()))}
            list.addView(card);line(list)
        }
        root.addView(btn("مشاهده تاریخچه تغییرات ساختاری"){showCatalogHistory()});root.addView(btn("بازگشت به صفحه اصلی"){showHome()})
    }
    private fun showCatalogManagement(){
        base("مدیریت ساختار و ظاهر بخش‌ها"){showProgramCatalog()}
        root.setBackgroundColor(currentPalette().background)
        root.addView(text("تغییرات فقط روی نام و نمایش کاتالوگ اثر دارد؛ شناسه قابلیت‌ها ثابت می‌ماند.",13f,currentPalette().text))
        val ordered=catalogSectionsForUi().filter{it.number!=104}.toMutableList();ordered.forEachIndexed{index,sec->val c=card();c.addView(text("${sec.icon} بخش ${sec.number}: ${sec.title}",15f,green,true));c.addView(btn("شخصی‌سازی این بخش"){editCatalogSection(sec){showCatalogManagement()}});val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};controls.addView(btn("↑ بالاتر"){if(index>0){val list=ordered.map{it.number}.toMutableList();val x=list.removeAt(index);list.add(index-1,x);val a=JSONArray();list.forEach{a.put(it)};catalogPrefs().edit().putString("section_order",a.toString()).apply();catalogHistory("section_order",sec.number,"انتقال به جایگاه ${index}");showCatalogManagement()}} ,LinearLayout.LayoutParams(0,-2,1f));controls.addView(btn("↓ پایین‌تر"){if(index<ordered.lastIndex){val list=ordered.map{it.number}.toMutableList();val x=list.removeAt(index);list.add(index+1,x);val a=JSONArray();list.forEach{a.put(it)};catalogPrefs().edit().putString("section_order",a.toString()).apply();catalogHistory("section_order",sec.number,"انتقال به جایگاه ${index+2}");showCatalogManagement()}},LinearLayout.LayoutParams(0,-2,1f));c.addView(controls);root.addView(c)}
        root.addView(btn("بازگشت به فهرست"){showProgramCatalog()})
    }
    private fun showCatalogHistory(){
        base("تاریخچه تغییرات کاتالوگ"){showProgramCatalog()};val a=catalogArray("history");if(a.length()==0)root.addView(text("هنوز تغییری ثبت نشده است.")) else for(i in a.length()-1 downTo 0){val o=a.optJSONObject(i)?:continue;root.addView(text("${Date(o.optLong("at"))} | ${o.optString("action")} | شناسه ${o.optInt("feature_id")} | ${o.optString("detail")}",13f))};root.addView(btn("بازگشت"){showProgramCatalog()})
    }

    private fun financeMetric(label:String,value:String,valueColor:Int):LinearLayout {
        val p=currentPalette()
        return LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            setPadding(7,10,7,10)
            background=GradientDrawable().apply { setColor(p.card); cornerRadius=16f; setStroke(1,p.soft) }
            addView(text(label,12f,p.text,true).apply { gravity=Gravity.CENTER })
            addView(text(value,14f,valueColor,true).apply { gravity=Gravity.CENTER; maxLines=2 })
        }
    }
    private fun financeSection(title:String) {
        root.addView(text(title,16f,currentPalette().accent,true).apply { setPadding(2,12,2,5) })
    }
    private fun showFinance(){
        base("امور مالی و حسابداری")
        val summary=db.summary()
        val metrics=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,4,0,8) }
        metrics.addView(financeMetric("دریافت‌ها",fmt(summary.income),currentPalette().accent),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,2,3,2)})
        metrics.addView(financeMetric("پرداخت‌ها",fmt(summary.expense),0xffc34d4d.toInt()),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,2,3,2)})
        metrics.addView(financeMetric("مانده نقدی",fmt(summary.balance),if(summary.balance>=0)currentPalette().accent else 0xffc34d4d.toInt()),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,2,3,2)})
        root.addView(metrics)
        financeSection("ثبت عملیات")
        val entryRow1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        entryRow1.addView(btn("＋ دریافت وجه"){financeEntryDialog("دریافت وجه")},LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,2,3,2)})
        entryRow1.addView(btn("－ پرداخت وجه"){financeEntryDialog("پرداخت وجه")},LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,2,3,2)})
        root.addView(entryRow1)
        val entryRow2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        entryRow2.addView(btn("＋ درآمد مستقل"){financeEntryDialog("درآمد")},LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,2,3,2)})
        entryRow2.addView(btn("－ هزینه مستقل"){financeEntryDialog("هزینه")},LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(3,2,3,2)})
        root.addView(entryRow2)
        financeSection("مدیریت و پیگیری")
        val tools=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        tools.addView(btn("صندوق‌ها و حساب‌ها"){showAccounts()})
        tools.addView(btn("چک، سفته و سررسیدها"){showInstruments()})
        tools.addView(btn("مدیریت اقساط"){showInstallments()})
        tools.addView(btn("مغایرت‌گیری و سوابق آن"){reconcileDialog()})
        tools.addView(btn("گزارش روزانه، ماهانه و سالانه"){reportDialog()})
        root.addView(tools)
        financeSection("دفتر گردش نقدی")
        val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list)
        root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.transactions().filter{it.kind in listOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")}
        if(rows.isEmpty()) list.addView(text("گردش نقدی خالی است.")) else rows.forEach{list.addView(txCard(it,true));line(list)}
        root.addView(btn("بازگشت به خانه"){showHome()})
    }
    private fun showPeople(q:String="", filter:Int=peopleFilter, sort:Int=peopleSort, groupFilter:String?=null){
        peopleFilter=filter.coerceIn(0,3); peopleSort=sort.coerceIn(0,3)
        getSharedPreferences("people_list",Context.MODE_PRIVATE).edit().putInt("filter",peopleFilter).putInt("sort",peopleSort).apply()
        base("اشخاص و دفتر حساب")
        root.addView(btn("＋ افزودن شخص جدید") { addPersonDialog() }); root.addView(btn("پرونده‌های بایگانی‌شده") { showArchivedPeople() })
        val search=field("جست‌وجوی نام، تلفن، کد ملی یا برچسب");search.setText(q);root.addView(search);root.addView(btn("جست‌وجو") { showPeople(search.text.toString(),peopleFilter,peopleSort) })
        val filterNames=arrayOf("همه اشخاص","فقط طلبکاران","فقط بدهکاران","فقط تسویه‌شده‌ها")
        val sortNames=arrayOf("نام: الف تا ی","بیشترین طلب","بیشترین بدهی","بیشترین مانده خالص")
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        controls.addView(btn("فیلتر: ${filterNames[peopleFilter]}") { peopleFilterDialog(q) },LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(btn("مرتب‌سازی: ${sortNames[peopleSort]}") { peopleSortDialog(q) },LinearLayout.LayoutParams(0,-2,1f))
        root.addView(controls)
        root.addView(btn("گروه اشخاص: ${groupFilter ?: "همه گروه‌ها"}") { peopleGroupDialog(q,groupFilter) })
        val all=db.people(q).let { rows -> if(groupFilter==null) rows else rows.filter{it.groupName==groupFilter} }
        val totalReceivable=all.sumOf{it.receivable}
        val totalPayable=all.sumOf{it.payable}
        val net=totalReceivable-totalPayable
        val summary=card().apply {
            addView(text("خلاصه دفتر اشخاص",16f,green,true))
            val totals=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            fun metric(label:String,value:String,color:Int):LinearLayout {
                return LinearLayout(this@MainActivity).apply {
                    orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER
                    setPadding(4,8,4,8)
                    addView(text(label,11f,0xff66736d.toInt(),true))
                    addView(text(value,13f,color,true))
                }
            }
            totals.addView(metric("مجموع طلب",fmt(totalReceivable),green),LinearLayout.LayoutParams(0,-2,1f))
            totals.addView(metric("مجموع بدهی",fmt(totalPayable),red),LinearLayout.LayoutParams(0,-2,1f))
            totals.addView(metric("خالص دفتر",fmt(kotlin.math.abs(net))+if(net<0)" بدهی" else if(net>0)" طلب" else " تسویه",if(net<0)red else green),LinearLayout.LayoutParams(0,-2,1f))
            addView(totals)
            addView(text("${all.size} پرونده • ${all.count{it.receivable>0}} طلبکار • ${all.count{it.payable>0}} بدهکار • ${all.count{it.balance==0L}} تسویه‌شده",11f))
        }
        root.addView(summary)
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val filtered=when(peopleFilter){1->all.filter{it.receivable>0};2->all.filter{it.payable>0};3->all.filter{it.balance==0L};else->all}
        val people=when(peopleSort){1->filtered.sortedWith(compareByDescending<Person>{it.receivable}.thenBy{it.name});2->filtered.sortedWith(compareByDescending<Person>{it.payable}.thenBy{it.name});3->filtered.sortedWith(compareByDescending<Person>{kotlin.math.abs(it.balance)}.thenBy{it.name});else->filtered.sortedBy{it.name}}
        list.addView(text("${people.size} شخص از ${all.size} نتیجه جست‌وجو",12f))
        if(people.isEmpty()) list.addView(text(if(all.isEmpty())"شخصی با این مشخصات ثبت نشده است." else "در این فیلتر شخصی پیدا نشد.")) else people.forEach { p ->
            val c=card()
            val heading=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            if(p.photoData.isNotBlank()) heading.addView(personPhotoView(p.photoData,52),LinearLayout.LayoutParams(52,52))
            heading.addView(text(p.name,18f,green,true),LinearLayout.LayoutParams(0,-2,1f))
            heading.addView(btn("⚙ نمایش بر اساس") { personDisplaySettings(p) })
            c.addView(heading)
            when(db.personDisplayMode(p.id)) {
                1 -> c.addView(text("طلب: ${fmt(p.receivable)} ${moneyUnit()}",15f,green,true))
                2 -> c.addView(text("بدهی: ${fmt(p.payable)} ${moneyUnit()}",15f,red,true))
                3 -> c.addView(text(netBalanceLabel(p),15f,if(p.balance<0)red else green,true))
                4 -> {
                    c.addView(text("طلب: ${fmt(p.receivable)} ${moneyUnit()}",14f,green,true))
                    c.addView(text("بدهی: ${fmt(p.payable)} ${moneyUnit()}",14f,red,true))
                    c.addView(text(netBalanceLabel(p),15f,if(p.balance<0)red else green,true))
                }
                5 -> c.addView(text("طلب ${fmt(p.receivable)}  |  بدهی ${fmt(p.payable)}  |  ${if(p.balance<0)"بدهکار" else if(p.balance>0)"طلبکار" else "تسویه"} ${fmt(kotlin.math.abs(p.balance))} ${moneyUnit()}",13f))
            }
            if(p.groupName.isNotBlank()) c.addView(text("گروه: ${p.groupName}",12f,0xff52635a.toInt()))
            if(p.roles.isNotBlank() || p.relation.isNotBlank()) c.addView(text("نقش‌ها: ${(listOf(p.relation)+p.roles.split(',')).filter{it.isNotBlank()}.distinct().joinToString("، ")}",12f,0xff52635a.toInt()))
            if(p.phone.isNotBlank()) c.addView(text(p.phone,13f))
            c.addView(btn("پرونده و گردش حساب") { personPage(p.id) })
            list.addView(c); line(list)
        }
        root.addView(btn("بازگشت به خانه") { showHome() })
    }
    private fun peopleGroupDialog(q:String,current:String?){
        val options=arrayOf("همه گروه‌ها","اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده")
        val selected=options.indexOf(current ?: "همه گروه‌ها").coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("گروه‌بندی اشخاص").setSingleChoiceItems(options,selected){dialog,which->dialog.dismiss();showPeople(q,peopleFilter,peopleSort,if(which==0)null else options[which])}.setNegativeButton("انصراف",null).show()
    }
    private fun peopleFilterDialog(q:String){
        val options=arrayOf("همه اشخاص","فقط طلبکاران (مانده طلب مثبت)","فقط بدهکاران (مانده بدهی مثبت)","فقط تسویه‌شده‌ها (مانده صفر)")
        AlertDialog.Builder(this).setTitle("فیلتر فهرست اشخاص").setSingleChoiceItems(options,peopleFilter){dialog,which->dialog.dismiss();showPeople(q,which,peopleSort)}.setNegativeButton("انصراف",null).show()
    }
    private fun peopleSortDialog(q:String){
        val options=arrayOf("نام: الف تا ی","بیشترین طلب","بیشترین بدهی","بیشترین مانده خالص")
        AlertDialog.Builder(this).setTitle("مرتب‌سازی اشخاص").setSingleChoiceItems(options,peopleSort){dialog,which->dialog.dismiss();showPeople(q,peopleFilter,which)}.setNegativeButton("انصراف",null).show()
    }
    private fun netBalanceLabel(p:Person):String = when {
        p.balance>0 -> "مانده خالص: ${fmt(p.balance)} ${moneyUnit()} طلب"
        p.balance<0 -> "مانده خالص: ${fmt(-p.balance)} ${moneyUnit()} بدهی"
        else -> "مانده خالص: تسویه"
    }
    private fun personDisplaySettings(p:Person) {
        val options=arrayOf(
            "۱. فقط طلب",
            "۲. فقط بدهی",
            "۳. فقط مانده خالص",
            "۴. طلب + بدهی + مانده خالص",
            "۵. نمایش فشرده در یک خط"
        )
        val current=db.personDisplayMode(p.id)-1
        AlertDialog.Builder(this).setTitle("نمایش بر اساس • ${p.name}")
            .setSingleChoiceItems(options,current) { dialog,which ->
                db.setPersonDisplayMode(p.id,which+1)
                dialog.dismiss()
                showPeople()
            }
            .setNegativeButton("انصراف",null).show()
    }
    private fun decodePersonPhoto(data:String,targetSize:Int):Bitmap? {
        return try {
            val bytes=Base64.decode(data,Base64.DEFAULT)
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds)
            var sample=1
            while(bounds.outWidth/sample>targetSize*2 || bounds.outHeight/sample>targetSize*2) sample*=2
            val options=BitmapFactory.Options().apply{inSampleSize=sample}
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,options)
        } catch(_:Exception){null}
    }
    private fun personPhotoView(data:String,size:Int):ImageView {
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(pale) }
        image.setImageBitmap(decodePersonPhoto(data,size))
        image.layoutParams=LinearLayout.LayoutParams(size,size)
        return image
    }
    private fun encodePersonPhoto(bitmap:Bitmap):String {
        val maxSide=900
        val scale=minOf(1f,maxSide.toFloat()/maxOf(bitmap.width,bitmap.height))
        val resized=if(scale<1f) Bitmap.createScaledBitmap(bitmap,(bitmap.width*scale).toInt().coerceAtLeast(1),(bitmap.height*scale).toInt().coerceAtLeast(1),true) else bitmap
        val bytes=ByteArrayOutputStream();resized.compress(Bitmap.CompressFormat.JPEG,82,bytes)
        if(resized!==bitmap) resized.recycle()
        return Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP)
    }
    private fun refreshActivePhoto(){
        val data=activePersonPhotoData
        activePersonPhotoPreview?.setImageBitmap(if(data.isNotBlank()) decodePersonPhoto(data,112) else null)
    }
    private fun savePersonPhoto(uri:Uri):String {
        val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
        contentResolver.openInputStream(uri).use { input -> if(input==null) throw IllegalStateException("خواندن عکس ممکن نیست"); BitmapFactory.decodeStream(input,null,bounds) }
        if(bounds.outWidth<=0 || bounds.outHeight<=0) throw IllegalArgumentException("فایل عکس معتبر نیست")
        var sample=1
        while(bounds.outWidth/sample>1800 || bounds.outHeight/sample>1800) sample*=2
        val options=BitmapFactory.Options().apply{inSampleSize=sample}
        val bitmap=contentResolver.openInputStream(uri).use { input -> if(input==null) throw IllegalStateException("خواندن عکس ممکن نیست"); BitmapFactory.decodeStream(input,null,options) ?: throw IllegalArgumentException("خواندن عکس ناموفق بود") }
        return encodePersonPhoto(bitmap)
    }
    private fun saveCameraPhoto(bitmap:Bitmap):String = encodePersonPhoto(bitmap)
    private fun personPhotoControls(box:LinearLayout){
        val preview=ImageView(this).apply { layoutParams=LinearLayout.LayoutParams(112,112).apply{gravity=Gravity.CENTER}; scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(pale) }
        activePersonPhotoPreview=preview; box.addView(preview)
        box.addView(btn("انتخاب از مخاطبین گوشی") {
            try { startActivityForResult(Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI),requestPickContact) }
            catch(e:Exception){toast("دسترسی به مخاطبین گوشی ممکن نیست")}
        })
        box.addView(btn("گرفتن عکس با دوربین") {
            try { startActivityForResult(Intent("android.media.action.IMAGE_CAPTURE"),requestTakePersonPhoto) }
            catch(e:Exception){toast("دوربین در دسترس نیست")}
        })
        box.addView(btn("بارگذاری عکس از گالری یا فایل‌ها") {
            try { val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"};startActivityForResult(intent,requestChoosePersonPhoto) }
            catch(e:Exception){toast("انتخاب عکس ممکن نیست")}
        })
    }
    private val connectionSections= linkedMapOf("finance" to "امور مالی و حسابداری","ledger" to "دفتر حساب","invoices" to "فاکتورها و صورتحساب‌ها","sales" to "خرید و فروش","contracts" to "قراردادها و تعهدات","instruments" to "چک، سفته و اقساط","bank_accounts" to "حساب‌های بانکی","family" to "خانواده و بستگان","friends" to "دوستان و آشنایان","reminders" to "یادآوری‌ها و پیگیری‌ها","documents" to "اسناد و مدارک","other" to "سایر بخش‌ها")
    private fun sectionTitle(key:String)=connectionSections[key] ?: key
    private fun showPersonConnectionSettings(){
        base("مدیریت اتصال اطلاعات اشخاص"){showHome()}
        root.addView(text("یک پرونده مرکزی برای هر شخص؛ بخش‌ها از همان پرونده اطلاعات موردنیاز را فراخوانی می‌کنند.",13f))
        connectionSections.forEach { (key,title) ->
            val c=card();c.addView(text(title,16f,green,true))
            val settings=db.sectionFieldSettings(key)
            c.addView(text("فیلدهای قابل نمایش: ${settings.count{it.third}} از ${settings.size}",12f))
            c.addView(btn("تنظیم فیلدهای این بخش") { editSectionFields(key) })
            c.addView(btn("مدیریت اشخاص متصل (${db.sectionPeople(key).size})") { showSectionPeople(key) })
            root.addView(c);line(root)
        }
        root.addView(btn("بازگشت به صفحه اصلی"){showHome()})
    }
    private fun showSectionPeople(sectionKey:String){
        base("اشخاص • ${sectionTitle(sectionKey)}"){showPersonConnectionSettings()}
        root.addView(text("این فهرست از بانک مرکزی اشخاص خوانده می‌شود. هر شخص فقط با شناسه ثابت خودش به این بخش متصل می‌شود.",13f))
        root.addView(btn("＋ اتصال شخص موجود از بانک مرکزی") { chooseCentralPersonForSection(sectionKey) })
        val linked=db.sectionPeople(sectionKey)
        if(linked.isEmpty()) root.addView(text("هنوز شخصی به این بخش متصل نشده است."))
        linked.forEach { item ->
            val c=card();c.addView(text(item.second,15f,green,true));c.addView(btn("بازکردن پرونده مرکزی شخص") { personPage(item.first) });root.addView(c);line(root)
        }
        root.addView(btn("بازگشت به مدیریت اتصال‌ها") { showPersonConnectionSettings() })
    }
    private fun chooseCentralPersonForSection(sectionKey:String){
        val people=db.people()
        if(people.isEmpty()){toast("ابتدا شخص را در بانک مرکزی اشخاص ثبت کنید");return}
        val labels=people.map { "${it.name}  •  ${it.phone}" }
        AlertDialog.Builder(this).setTitle("انتخاب از بانک مرکزی اشخاص").setItems(labels.toTypedArray()){_,which->
            val p=people[which]
            if(db.hasPersonSectionLink(p.id,sectionKey)){toast("این شخص قبلاً به این بخش متصل شده است");return@setItems}
            val role=field("نقش شخص در این بخش؛ مثلاً خریدار یا فروشنده")
            val note=field("توضیحات تکمیلی")
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0);addView(text("شخص انتخاب‌شده: ${p.name}",14f,green,true));addView(role);addView(note)}
            AlertDialog.Builder(this).setTitle("ثبت اتصال به ${sectionTitle(sectionKey)}").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ثبت اتصال"){_,_->
                if(db.hasPersonSectionLink(p.id,sectionKey)){toast("این اتصال قبلاً ثبت شده است")}else{db.addPersonSectionLink(p.id,sectionKey,role.text.toString().trim(),note.text.toString().trim());toast("اتصال شخص با شناسه مرکزی ثبت شد");showSectionPeople(sectionKey)}
            }.show()
        }.setNegativeButton("انصراف",null).show()
    }
    private fun editSectionFields(sectionKey:String){
        base("تنظیم فیلدها • ${sectionTitle(sectionKey)}"){showPersonConnectionSettings()}
        root.addView(text("انتخاب کن کدام مشخصات از پرونده مرکزی در این بخش نمایش داده شود. تغییرات فقط تنظیم نمایش هستند و اطلاعات اصلی شخص را حذف نمی‌کنند.",13f))
        val settings=db.sectionFieldSettings(sectionKey)
        settings.forEach { item ->
            val check=styledCheckBox().apply{text=item.second;isChecked=item.third;setTextSize(15f);setOnCheckedChangeListener{_,checked->db.setSectionFieldVisible(sectionKey,item.first,checked)}}
            root.addView(check);line(root)
        }
        root.addView(btn("بازگشت به فهرست بخش‌ها"){showPersonConnectionSettings()})
    }
    private fun addPersonSectionLinkDialog(p:Person){
        val keys=connectionSections.keys.toList();val labels=keys.map{sectionTitle(it)}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val section=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,labels)}
        val role=field("نقش یا نوع ارتباط در این بخش؛ مثلاً خریدار، فروشنده، طرف قرارداد")
        val note=field("توضیحات تکمیلی")
        box.addView(text("بخش مقصد"));box.addView(section);box.addView(role);box.addView(note)
        AlertDialog.Builder(this).setTitle("اتصال پرونده ${p.name}").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ثبت اتصال"){_,_->
            db.addPersonSectionLink(p.id,keys[section.selectedItemPosition],role.text.toString().trim(),note.text.toString().trim());personPage(p.id)
        }.show()
    }
    private fun addPersonDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val n=field("نام و نام خانوادگی");val father=field("نام پدر");val ph=field("شماره تماس");val second=field("شماره تماس دوم");val landline=field("تلفن ثابت");val email=field("پست الکترونیکی");val rel=field("نوع ارتباط اصلی");val roles=field("نقش‌های دیگر با ویرگول؛ مشتری، فروشنده، دوست...");val group=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده"))};val ad=field("نشانی کامل");val note=field("توضیحات");val nid=field("کد ملی",true);val birth=field("تاریخ تولد شمسی (مثلاً ۱۳۶۵/۰۵/۲۰)");val job=field("شغل");val workplace=field("محل کار");val source=field("منبع آشنایی");val tags=field("برچسب‌ها با ویرگول: مشتری، فروشنده...");val location=field("موقعیت مکانی یا نشانی تکمیلی");val rating=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("عادی","معتبر","نیازمند احتیاط","نامشخص"))}
        activePersonName=n;activePersonPhone=ph;activePersonPhotoData=""
        personPhotoControls(box);box.addView(text("گروه اصلی"));box.addView(group);listOf(n,father,ph,second,landline,email,nid,birth,rel,roles,ad,location,job,workplace,source,tags,note).forEach{box.addView(it)};box.addView(text("درجه اعتبار"));box.addView(rating)
        val formScroll=ScrollView(this);formScroll.addView(box)
        AlertDialog.Builder(this).setTitle("افزودن شخص").setView(styleDialogView(formScroll)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->
            if(n.text.toString().trim().isEmpty()) toast("نام را وارد کنید") else {val duplicates=db.duplicatePeople(n.text.toString().trim(),ph.text.toString().trim(),nid.text.toString().trim());if(duplicates.isNotEmpty()){AlertDialog.Builder(this).setTitle("احتمال شخص تکراری").setMessage(duplicates.joinToString("\n")+"\nآیا با وجود این شباهت ثبت شود؟").setNegativeButton("بازبینی",null).setPositiveButton("ثبت به هر حال"){_,_->saveNewPerson(n,ph,ad,rel,note,second,nid,birth,job,workplace,source,rating,tags,location,father,landline,email,group,roles)}.show()}else saveNewPerson(n,ph,ad,rel,note,second,nid,birth,job,workplace,source,rating,tags,location,father,landline,email,group,roles)}
        }.show()
    }
    private fun saveNewPerson(n:EditText,ph:EditText,ad:EditText,rel:EditText,note:EditText,second:EditText,nid:EditText,birth:EditText,job:EditText,workplace:EditText,source:EditText,rating:Spinner,tags:EditText,location:EditText,father:EditText,landline:EditText,email:EditText,group:Spinner,roles:EditText){
        val id=db.addPerson(n.text.toString().trim(),ph.text.toString().trim(),ad.text.toString().trim(),rel.text.toString().trim(),note.text.toString().trim(),activePersonPhotoData)
        db.updatePersonExtra(id,second.text.toString().trim(),nid.text.toString().trim(),birth.text.toString().trim(),job.text.toString().trim(),workplace.text.toString().trim(),source.text.toString().trim(),rating.selectedItem.toString(),tags.text.toString().trim(),location.text.toString().trim(),father.text.toString().trim(),landline.text.toString().trim(),email.text.toString().trim(),group.selectedItem.toString(),roles.text.toString().trim())
        showPeople()
    }
    private fun personPage(id:Long){
        val p=db.people().firstOrNull{it.id==id}?:return showPeople()
        val opening=db.personOpeningBalance(id)
        base(p.name){showPeople()}
        if(p.photoData.isNotBlank()) root.addView(personPhotoView(p.photoData,120),LinearLayout.LayoutParams(120,120).apply{gravity=Gravity.CENTER})
        val c=card().apply{setBackgroundColor(pale)}
        c.addView(text("طلب از شخص: ${fmt(p.receivable)} ${moneyUnit()}",15f,green,true))
        c.addView(text("بدهی به شخص: ${fmt(p.payable)} ${moneyUnit()}",15f,red,true))
        c.addView(text(if(p.balance>0)"مانده خالص: ${fmt(p.balance)} ${moneyUnit()} طلب" else if(p.balance<0)"مانده خالص: ${fmt(-p.balance)} ${moneyUnit()} بدهی" else "مانده خالص: تسویه",17f,green,true))
        root.addView(c)
        val details=card();details.addView(text("اطلاعات پرونده",16f,green,true));listOf("نام پدر: ${p.fatherName}","شماره تماس: ${p.phone}","شماره دوم: ${p.secondPhone}","تلفن ثابت: ${p.landline}","ایمیل: ${p.email}","گروه اصلی: ${p.groupName}","نقش‌ها: ${p.roles}","کد ملی: ${p.nationalId}","تاریخ تولد: ${p.birthDate}","نوع ارتباط: ${p.relation}","شغل: ${p.job}","محل کار: ${p.workplace}","نشانی: ${p.address}","موقعیت: ${p.location}","منبع آشنایی: ${p.source}","اعتبار: ${p.rating}","برچسب‌ها: ${p.tags}","یادداشت: ${p.notes}").filter{it.substringAfter(": ").isNotBlank()}.forEach{details.addView(text(it,13f))};root.addView(details)
        val links=db.personSectionLinks(p.id)
        val linksCard=card();linksCard.addView(text("اتصال این پرونده به بخش‌های برنامه",16f,green,true))
        if(links.isEmpty()) linksCard.addView(text("هنوز اتصال اختصاصی به بخش‌های دیگر ثبت نشده است.",12f)) else links.forEach { link -> linksCard.addView(text("${sectionTitle(link.first)} • ${link.second}",13f)) }
        linksCard.addView(btn("＋ تعریف اتصال به یک بخش") { addPersonSectionLinkDialog(p) });root.addView(linksCard)
        root.addView(btn("＋ افزودن مدرک یا تصویر به پرونده") { addPersonDocument(p) })
        root.addView(btn("مشاهده مدارک (${db.documents(p.id).size})") { showPersonDocuments(p) })
        root.addView(btn("＋ ثبت یادآوری تماس یا پیگیری") { addPersonReminder(p) })
        db.reminders(p.id).forEach { rem -> root.addView(btn("یادآوری: ${rem.second} • ${jalali(rem.third)} (انجام شد)") { db.completeReminder(rem.first);personPage(p.id) }) }
        root.addView(btn("اشتراک‌گذاری خلاصه پرونده") { sharePerson(p) })
        root.addView(btn("تهیه گزارش PDF پرونده") { exportPersonPdf(p) })
        if(opening!=null) {
            val openingCard=card()
            openingCard.addView(text("مانده اول دوره فعال: ${fmt(opening.amount)} ${moneyUnit()} ${opening.balanceType}",15f,green,true))
            openingCard.addView(text("تاریخ مبنا: ${jalali(opening.baseDate)}",13f))
            if(opening.description.isNotBlank()) openingCard.addView(text("توضیحات: ${opening.description}",13f))
            root.addView(openingCard)
        } else {
            root.addView(text("برای این شخص هنوز مانده اول دوره ثبت نشده است.",13f))
        }
        root.addView(btn(if(opening==null)"ثبت مانده اول دوره" else "ثبت / اصلاح مانده اول دوره") { personOpeningDialog(p,opening) })
        root.addView(btn("＋ ثبت عملیات حساب این شخص") { personEntryDialog(p) })
        root.addView(btn("ویرایش مشخصات شخص") { editPersonInfo(p) })
        root.addView(btn("بایگانی پرونده شخص") { archivePersonConfirm(p) })
        showPersonLedger(p)
    }
    private fun showPersonLedger(p:Person,start:Long?=null,endExclusive:Long?=null) {
        root.addView(text("دفتر حساب ${p.name}",17f,green,true))
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        controls.addView(btn("فیلتر تاریخ") { personLedgerFilterDialog(p) },LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(btn("نمایش همه") { personPage(p.id) },LinearLayout.LayoutParams(0,-2,1f))
        root.addView(controls)
        val opening=db.personOpeningBalance(p.id)
        val requestedStart=start ?: (opening?.baseDate ?: 0L)
        val baseAt=maxOf(requestedStart,opening?.baseDate ?: 0L)
        val endAt=endExclusive ?: Long.MAX_VALUE
        val openingBalance=db.personBalanceBefore(p.id,baseAt)
        val rows=db.personLedgerRows(p.id,baseAt,endAt)
        var running=openingBalance
        var increaseReceivable=0L
        var increasePayable=0L
        val impacts=rows.map { it to db.personLedgerImpact(it) }
        impacts.forEach { (_,delta)->if(delta>0)increaseReceivable+=delta else increasePayable+=-delta }
        val summary=card().apply {
            addView(text("بازه: ${if(start==null)"از ابتدای دفتر" else jalali(start)} تا ${if(endExclusive==null)"امروز" else jalali(endExclusive-1)}",13f))
            addView(text("مانده ابتدای بازه: ${balanceLabel(openingBalance)}",14f,green,true))
            addView(text("افزایش طلب / کاهش بدهی: ${fmt(increaseReceivable)} ${moneyUnit()}",13f,green,true))
            addView(text("افزایش بدهی / کاهش طلب: ${fmt(increasePayable)} ${moneyUnit()}",13f,red,true))
            val closing=openingBalance+impacts.sumOf{it.second}
            addView(text("مانده پایان بازه: ${balanceLabel(closing)}",16f,if(closing>=0)green else red,true))
            addView(text("تعداد عملیات: ${rows.size}",12f))
        }
        root.addView(summary)
        root.addView(btn("اشتراک‌گذاری صورتحساب این بازه") { sharePersonLedger(p,baseAt,endAt,openingBalance,rows) })
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        if(rows.isEmpty()) list.addView(text("در این بازه تراکنشی ثبت نشده است."))
        impacts.forEach { (tx,delta)->
            running+=delta
            val c=txCard(tx,true)
            c.addView(text("اثر در مانده: ${if(delta>=0)"+" else "−"}${fmt(kotlin.math.abs(delta))} ${moneyUnit()}",12f,if(delta>=0)green else red,true))
            c.addView(text("مانده پس از عملیات: ${balanceLabel(running)}",13f,if(running>=0)green else red,true))
            list.addView(c);line(list)
        }
    }
    private fun balanceLabel(value:Long):String = when { value>0 -> "${fmt(value)} ${moneyUnit()} طلب از شخص"; value<0 -> "${fmt(-value)} ${moneyUnit()} بدهی به شخص"; else -> "تسویه کامل" }
    private fun personLedgerFilterDialog(p:Person) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val today=System.currentTimeMillis();val from=dateFields(box,today,"از تاریخ");val to=dateFields(box,today,"تا تاریخ")
        AlertDialog.Builder(this).setTitle("فیلتر گردش حساب ${p.name}").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("اعمال فیلتر"){_,_->
            val start=readDate(from);val end=readDate(to)
            if(start==null||end==null||end<start){toast("بازه شمسی معتبر وارد کنید");return@setPositiveButton}
            val opening=db.personOpeningBalance(p.id)
            if(opening!=null && start<opening.baseDate){toast("شروع بازه نباید قبل از تاریخ مبنای مانده اول دوره (${jalali(opening.baseDate)}) باشد؛ سوابق قدیمی در تاریخچه حفظ شده‌اند.");return@setPositiveButton}
            val endX=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis
            base("دفتر حساب ${p.name}"){personPage(p.id)}
            showPersonLedger(p,start,endX)
        }.show()
    }
    private fun sharePersonLedger(p:Person,start:Long,endExclusive:Long,opening:Long,rows:List<Tx>) {
        val out=StringBuilder("صورتحساب: ${p.name}\nشماره تماس: ${p.phone}\nاز ${jalali(start)} تا ${if(endExclusive==Long.MAX_VALUE)"بدون محدودیت" else jalali(endExclusive-1)}\nمانده ابتدای بازه: ${balanceLabel(opening)}\n\n")
        var running=opening
        rows.forEach { tx->val delta=db.personLedgerImpact(tx);running+=delta;out.append("${jalali(tx.createdAt)} | ${tx.kind} | ${fmt(tx.amount)} ${moneyUnit()} | اثر: ${if(delta>=0)"+" else "-"}${fmt(kotlin.math.abs(delta))} | مانده: ${balanceLabel(running)}\nشرح: ${tx.note}\nحساب: ${tx.account}\n----------------------\n") }
        out.append("\nمانده پایان بازه: ${balanceLabel(running)}\nتعداد عملیات: ${rows.size}")
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,out.toString()),"اشتراک‌گذاری صورتحساب"))
    }
    private fun personOpeningDialog(p:Person,current:PersonOpening?) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val amount=field("مبلغ مانده اول دوره به تومان",true).apply{if(current!=null)setText(current.amount.toString())}
        val type=styledSpinner().apply{
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("طلب","بدهی"))
            if(current!=null)setSelection(if(current.balanceType=="بدهی")1 else 0)
        }
        val note=field("توضیحات").apply{if(current!=null)setText(current.description)}
        val date=dateFields(box,current?.baseDate ?: System.currentTimeMillis(),"تاریخ مبنای مانده اول دوره")
        box.addView(text("نوع مانده"));box.addView(type);box.addView(amount);box.addView(note)
        AlertDialog.Builder(this).setTitle(if(current==null)"ثبت مانده اول دوره ${p.name}" else "اصلاح مانده اول دوره ${p.name}")
            .setMessage("تراکنش‌های قبل از تاریخ مبنا در مانده جاری محاسبه نمی‌شوند، اما در تاریخچه باقی می‌مانند. هر اصلاح، سابقه قبلی را حفظ می‌کند.")
            .setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره") { _,_->
                val a=parseLongDigits(amount.text.toString())
                val at=readDate(date)
                if(a==null || a<0L) { toast("مبلغ معتبر وارد کنید"); return@setPositiveButton }
                if(at==null) { toast("تاریخ شمسی معتبر وارد کنید"); return@setPositiveButton }
                try {
                    db.setPersonOpeningBalance(p.id,a,type.selectedItem.toString(),at,note.text.toString().trim())
                    personPage(p.id)
                } catch(e:Exception) { toast("ثبت مانده اول دوره ناموفق بود: ${e.message ?: "خطا"}") }
            }.show()
    }
    private fun archivePersonConfirm(p:Person) {
        val count=db.personTransactionCount(p.id)
        val msg=if(count>0) "این پرونده $count تراکنش دارد. با بایگانی، فقط از فهرست فعال خارج می‌شود و تمام گردش حساب و سوابق مالی حفظ می‌شوند. هر زمان بخواهید قابل بازیابی است." else "این پرونده از فهرست فعال خارج می‌شود و هر زمان بخواهید قابل بازیابی است."
        AlertDialog.Builder(this).setTitle("بایگانی پرونده ${p.name}").setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("بایگانی") { _,_-> db.archivePerson(p.id); showPeople() }.show()
    }
    private fun showArchivedPeople() {
        base("پرونده‌های بایگانی‌شده") { showPeople() }
        val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; sc.addView(list); root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.deletedPeople()
        if(rows.isEmpty()) list.addView(text("پرونده بایگانی‌شده‌ای وجود ندارد.")) else rows.forEach { p ->
            val c=card(); c.addView(text(p.name,17f,green,true)); c.addView(text("تراکنش‌های ثبت‌شده: ${db.personTransactionCount(p.id)}"));
            c.addView(text(if(p.balance>0) "مانده طلب: ${fmt(p.balance)} ${moneyUnit()}" else if(p.balance<0) "مانده بدهی: ${fmt(-p.balance)} ${moneyUnit()}" else "مانده خالص: صفر"))
            if(p.groupName.isNotBlank()) c.addView(text("گروه: ${p.groupName}",12f,0xff52635a.toInt()))
            if(p.roles.isNotBlank() || p.relation.isNotBlank()) c.addView(text("نقش‌ها: ${(listOf(p.relation)+p.roles.split(',')).filter{it.isNotBlank()}.distinct().joinToString("، ")}",12f,0xff52635a.toInt()))
            if(p.phone.isNotBlank()) c.addView(text(p.phone,13f))
            c.addView(btn("بازیابی پرونده") { AlertDialog.Builder(this).setTitle("بازیابی ${p.name}؟").setMessage("پرونده دوباره در فهرست اشخاص فعال نمایش داده می‌شود و سوابق قبلی آن حفظ خواهد شد.").setNegativeButton("انصراف",null).setPositiveButton("بازیابی") { _,_-> db.restorePerson(p.id); showArchivedPeople() }.show() })
            list.addView(c); line(list)
        }
        root.addView(btn("بازگشت به اشخاص") { showPeople() })
    }
    private fun editPersonInfo(p:Person){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val n=field("نام",false).apply{setText(p.name)};val father=field("نام پدر").apply{setText(p.fatherName)};val ph=field("شماره تماس").apply{setText(p.phone)};val landline=field("تلفن ثابت").apply{setText(p.landline)};val email=field("پست الکترونیکی").apply{setText(p.email)};val roles=field("نقش‌های دیگر با ویرگول").apply{setText(p.roles)};val group=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده"));setSelection(arrayOf("اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده").indexOf(p.groupName).coerceAtLeast(0))};val rel=field("نوع ارتباط").apply{setText(p.relation)};val ad=field("نشانی").apply{setText(p.address)};val note=field("توضیحات").apply{setText(p.notes)};val second=field("شماره تماس دوم").apply{setText(p.secondPhone)};val nid=field("کد ملی",true).apply{setText(p.nationalId)};val birth=field("تاریخ تولد شمسی").apply{setText(p.birthDate)};val job=field("شغل").apply{setText(p.job)};val workplace=field("محل کار").apply{setText(p.workplace)};val source=field("منبع آشنایی").apply{setText(p.source)};val tags=field("برچسب‌ها با ویرگول").apply{setText(p.tags)};val location=field("موقعیت مکانی یا نشانی تکمیلی").apply{setText(p.location)};val rating=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("عادی","معتبر","نیازمند احتیاط","نامشخص"));setSelection(arrayOf("عادی","معتبر","نیازمند احتیاط","نامشخص").indexOf(p.rating).coerceAtLeast(0))}
        activePersonName=n;activePersonPhone=ph;activePersonPhotoData=p.photoData
        personPhotoControls(box);refreshActivePhoto();box.addView(text("گروه اصلی"));box.addView(group);listOf(n,father,ph,second,landline,email,nid,birth,rel,roles,ad,location,job,workplace,source,tags,note).forEach{box.addView(it)};box.addView(text("درجه اعتبار"));box.addView(rating)
        box.addView(btn("حذف عکس شخص") { activePersonPhotoData="";activePersonPhotoPreview?.setImageDrawable(null) })
        val formScroll=ScrollView(this);formScroll.addView(box)
        AlertDialog.Builder(this).setTitle("ویرایش شخص").setView(styleDialogView(formScroll)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->
            db.writableDatabase.execSQL("UPDATE people SET name=?,phone=?,relation=?,address=?,notes=?,photo_data=? WHERE id=?",arrayOf(n.text.toString(),ph.text.toString(),rel.text.toString(),ad.text.toString(),note.text.toString(),activePersonPhotoData,p.id));db.updatePersonExtra(p.id,second.text.toString().trim(),nid.text.toString().trim(),birth.text.toString().trim(),job.text.toString().trim(),workplace.text.toString().trim(),source.text.toString().trim(),rating.selectedItem.toString(),tags.text.toString().trim(),location.text.toString().trim(),father.text.toString().trim(),landline.text.toString().trim(),email.text.toString().trim(),group.selectedItem.toString(),roles.text.toString().trim())
            db.writableDatabase.execSQL("INSERT INTO audit_log(action,target,target_id,details,created_at) VALUES(?,?,?,?,?)",arrayOf("ویرایش","شخص",p.id,n.text.toString(),System.currentTimeMillis()));personPage(p.id)
        }.show()
    }
    private var pendingDocumentPersonId:Long=0L
    private fun addPersonDocument(p:Person){
        pendingDocumentPersonId=p.id
        val title=field("عنوان مدرک؛ مانند کارت ملی، قرارداد، برگه مشخصات")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};box.addView(title)
        AlertDialog.Builder(this).setTitle("افزودن مدرک به پرونده").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setNeutralButton("عکس با دوربین"){_,_->
            pendingDocumentTitle=title.text.toString().trim().ifBlank{"مدرک شخص"}
            try{startActivityForResult(Intent("android.media.action.IMAGE_CAPTURE"),4112)}catch(e:Exception){toast("دوربین در دسترس نیست")}
        }.setPositiveButton("انتخاب از گالری / فایل‌ها"){_,_->
            pendingDocumentTitle=title.text.toString().trim().ifBlank{"مدرک شخص"}
            try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},4110)}catch(e:Exception){toast("انتخاب فایل ممکن نیست")}
        }.show()
    }
    private var pendingDocumentTitle="مدرک شخص"
    private fun showPersonDocuments(p:Person){
        val docs=db.documents(p.id)
        if(docs.isEmpty()){toast("مدرکی برای این شخص ثبت نشده است");return}
        AlertDialog.Builder(this).setTitle("مدارک ${p.name}").setItems(docs.map{it.second}.toTypedArray()){_,which->
            val item=docs[which];val data=db.documentData(item.first) ?: return@setItems
            val image=personPhotoView(data,260).apply{layoutParams=LinearLayout.LayoutParams(260,260).apply{gravity=Gravity.CENTER}}
            AlertDialog.Builder(this).setTitle(item.second).setView(image).setNegativeButton("بستن",null).setPositiveButton("حذف مدرک"){_,_->db.deleteDocument(item.first);personPage(p.id)}.show()
        }.setNegativeButton("بستن",null).show()
    }
    private fun addPersonReminder(p:Person){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val title=field("عنوان یادآوری؛ مثلاً تماس برای تسویه")
        val note=field("توضیحات")
        val date=dateFields(box,System.currentTimeMillis(),"تاریخ یادآوری شمسی")
        box.addView(title);box.addView(note)
        AlertDialog.Builder(this).setTitle("یادآوری برای ${p.name}").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره یادآوری"){_,_->
            val at=readDate(date);if(title.text.toString().isBlank()||at==null){toast("عنوان و تاریخ معتبر وارد کنید");return@setPositiveButton}
            val reminderId=db.addReminder(p.id,title.text.toString().trim(),note.text.toString().trim(),at);schedulePersonReminder(p.id,reminderId,p.name,title.text.toString().trim(),at);personPage(p.id)
        }.show()
    }
    private fun schedulePersonReminder(personId:Long,reminderId:Long,personName:String,title:String,day:Long){
        try{
            val alarm=getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent=Intent(this,PersonReminderReceiver::class.java).apply{putExtra("person_name",personName);putExtra("reminder_title",title);putExtra("reminder_id",reminderId)}
            val pending=PendingIntent.getBroadcast(this,(reminderId%Int.MAX_VALUE).toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val at=day+9L*60L*60L*1000L
            if(at>System.currentTimeMillis()) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending)
            if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),4120)
        }catch(e:Exception){toast("یادآوری ذخیره شد؛ تنظیم هشدار خودکار ممکن نشد")}
    }
    private fun sharePerson(p:Person){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,12,24,12)}
        val scroll=ScrollView(this).apply{addView(box)}
        val choices=linkedMapOf<String,Pair<String,String>>()
        fun addChoice(key:String,label:String,value:String,checked:Boolean=false){
            val cb=styledCheckBox().apply{text=label;isChecked=checked}
            box.addView(cb); choices[key]=Pair(value,"")
            cb.tag=key
        }
        addChoice("name","نام و نام خانوادگی",p.name,true)
        addChoice("phone","شماره تماس اصلی",p.phone,true)
        addChoice("second_phone","شماره تماس دوم",p.secondPhone)
        addChoice("landline","تلفن ثابت",p.landline)
        addChoice("email","ایمیل",p.email)
        addChoice("address","نشانی",p.address)
        addChoice("job","شغل و محل کار",listOf(p.job,p.workplace).filter{it.isNotBlank()}.joinToString(" • "))
        addChoice("national_id","کد ملی (اطلاعات حساس)",p.nationalId)
        addChoice("birth","تاریخ تولد",p.birthDate)
        addChoice("roles","گروه و نقش‌ها",listOf(p.groupName,p.roles).filter{it.isNotBlank()}.joinToString(" • "))
        addChoice("notes","توضیحات",p.notes)
        val accountRows=mutableListOf<String>()
        try{db.readableDatabase.rawQuery("SELECT bank_name,owner_name,account_number,card_number,iban FROM finance_accounts WHERE is_deleted=0 AND is_active=1 AND owner_person_id=? ORDER BY id",arrayOf(p.id.toString())).use{c->while(c.moveToNext()){
            val parts=listOf(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4)).filter{!it.isNullOrBlank()}
            if(parts.isNotEmpty()) accountRows.add(parts.joinToString(" | "))
        }}}catch(_:Exception){}
        val accountCheck=styledCheckBox().apply{text="اطلاعات حساب‌های بانکی متصل (${accountRows.size})؛ شامل شماره حساب/کارت/شبا";isChecked=false;isEnabled=accountRows.isNotEmpty()}
        box.addView(accountCheck)
        AlertDialog.Builder(this).setTitle("انتخاب اطلاعات برای اشتراک‌گذاری").setView(scroll)
            .setNegativeButton("انصراف",null).setPositiveButton("پیش‌نمایش") { _,_->
                val lines=mutableListOf("اطلاعات انتخاب‌شده پرونده: ${p.name}")
                for(i in 0 until box.childCount){val v=box.getChildAt(i);if(v is CheckBox && v.isChecked && v!==accountCheck){val key=v.tag as? String ?: continue;val value=choices[key]?.first.orEmpty();if(value.isNotBlank())lines.add("${v.text}: $value")}}
                if(accountCheck.isChecked) accountRows.forEachIndexed{index,row->lines.add("حساب بانکی ${index+1}: $row")}
                val preview=lines.joinToString("\n")
                AlertDialog.Builder(this).setTitle("پیش‌نمایش اطلاعات قابل ارسال").setMessage(preview)
                    .setNegativeButton("بازگشت به انتخاب",null)
                    .setPositiveButton("تأیید و اشتراک‌گذاری"){_,_->
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,preview),"اشتراک‌گذاری اطلاعات انتخاب‌شده"))
                    }.show()
            }.show()
    }
    private var pendingPdfPerson:Person?=null
    private fun exportPersonPdf(p:Person){
        pendingPdfPerson=p
        try{
            val pdf=PdfDocument();val pageInfo=PdfDocument.PageInfo.Builder(595,842,1).create();val page=pdf.startPage(pageInfo)
            val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(28,28,28,28)}
            val title=TextView(this).apply{text="پرونده شخص: ${p.name}";textSize=20f;setTypeface(null,1);textDirection=View.TEXT_DIRECTION_RTL;gravity=Gravity.RIGHT}
            content.addView(title)
            listOf("نام پدر: ${p.fatherName}","شماره تماس: ${p.phone}","شماره دوم: ${p.secondPhone}","تلفن ثابت: ${p.landline}","ایمیل: ${p.email}","گروه اصلی: ${p.groupName}","نقش‌ها: ${p.roles}","کد ملی: ${p.nationalId}","تاریخ تولد: ${p.birthDate}","نوع ارتباط: ${p.relation}","شغل: ${p.job}","محل کار: ${p.workplace}","نشانی: ${p.address}","موقعیت: ${p.location}","منبع آشنایی: ${p.source}","اعتبار: ${p.rating}","برچسب‌ها: ${p.tags}","طلب: ${fmt(p.receivable)} ${moneyUnit()}","بدهی: ${fmt(p.payable)} ${moneyUnit()}","مانده خالص: ${fmt(p.balance)} ${moneyUnit()}","یادداشت: ${p.notes}").forEach{line->content.addView(TextView(this).apply{text=line;textSize=13f;textDirection=View.TEXT_DIRECTION_RTL;gravity=Gravity.RIGHT;setPadding(0,7,0,7)})}
            val w=540;val h=780;content.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.AT_MOST));content.layout(0,0,w,content.measuredHeight.coerceAtMost(h));content.draw(page.canvas);pdf.finishPage(page)
            val file=File(cacheDir,"person_${p.id}.pdf");FileOutputStream(file).use{pdf.writeTo(it)};pdf.close()
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/pdf";putExtra(Intent.EXTRA_TITLE,"پرونده-${p.name}.pdf")};startActivityForResult(intent,4111)
        }catch(e:Exception){toast("ساخت PDF ناموفق بود: ${e.message ?: "خطا"}")}
    }
    private fun personEntryDialog(p:Person){
        val types=arrayOf("طلب","بدهی","دریافت وجه","پرداخت وجه","دریافت کالا","تحویل کالا","فروش نسیه","خرید نسیه")
        entryDialog("ثبت عملیات برای ${p.name}",types,p.id)
    }
    private fun financeEntryDialog(preselect:String?=null){
        val types=arrayOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")
        entryDialog("ثبت تراکنش مالی",types,null,preselect)
    }
    private fun dateFields(parent:LinearLayout, initial:Long, label:String="تاریخ شمسی"):Triple<EditText,EditText,EditText> {
        val parts=jalali(initial).split("/"); val y=field("سال شمسی",true).apply{setText(parts[0])}; val m=field("ماه",true).apply{setText(parts[1])}; val d=field("روز",true).apply{setText(parts[2])}
        parent.addView(text("$label (سال / ماه / روز)")); val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; row.addView(y,LinearLayout.LayoutParams(0,-2,1.3f));row.addView(m,LinearLayout.LayoutParams(0,-2,1f));row.addView(d,LinearLayout.LayoutParams(0,-2,1f));parent.addView(row)
        return Triple(y,m,d)
    }
    private fun readDate(fields:Triple<EditText,EditText,EditText>):Long? = jalaliToMillis(parseLongDigits(fields.first.text.toString())?.toInt()?:-1,parseLongDigits(fields.second.text.toString())?.toInt()?:-1,parseLongDigits(fields.third.text.toString())?.toInt()?:-1)
    private fun entryDialog(title:String,types:Array<String>,personId:Long?,preselect:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val sp=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types);if(preselect!=null)setSelection(types.indexOf(preselect).coerceAtLeast(0))};val amount=field("مبلغ کل عملیات به تومان",true);val note=field("شرح / توضیحات");val account=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,db.accounts())};val peopleForEntry=if(personId==null) db.people("") else emptyList();val personOptions=listOf("بدون طرف‌حساب")+peopleForEntry.map{"${it.name}${if(it.phone.isBlank())"" else " • ${it.phone}"} • شناسه ${it.id}"};val personPicker=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,personOptions)};val methods=arrayOf("نقدی","کارت‌به‌کارت","واریز بانکی","چک","سفته","دریافت کالا/جنس","تهاتر","نسیه/تسویه بعدی");val method=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,methods)};val settled=field("مبلغ روش اول",true);val methods2=arrayOf("بدون روش دوم")+methods;val method2=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,methods2)};val settled2=field("مبلغ روش دوم (در صورت تسویه ترکیبی)",true);val reference=field("شماره پیگیری / شماره چک یا سفته");val details=field("جزئیات تسویه یا کالای دریافتی");val itemName=field("نام کالا (در صورت دریافت کالا)");val itemQty=field("تعداد کالا",true);val itemUnit=field("واحد کالا؛ کیلو، عدد و ...");val itemPrice=field("قیمت توافقی هر واحد به تومان",true);val bank=field("بانک صادرکننده (در صورت چک/سفته)");val date=dateFields(box,System.currentTimeMillis());val due=dateFields(box,System.currentTimeMillis(),"سررسید چک/سفته (در صورت نیاز)");box.addView(text("نوع عملیات"));box.addView(sp);if(personId==null){box.addView(text("انتخاب طرف‌حساب از بانک مرکزی اشخاص (اختیاری)"));box.addView(personPicker)};box.addView(amount);box.addView(note);box.addView(text("روش تسویه اول"));box.addView(method);box.addView(settled);box.addView(text("روش تسویه دوم؛ برای حالت ترکیبی"));box.addView(method2);box.addView(settled2);box.addView(reference);box.addView(details);box.addView(text("جزئیات کالای دریافتی (در صورت وجود)"));box.addView(itemName);box.addView(itemQty);box.addView(itemUnit);box.addView(itemPrice);box.addView(bank);box.addView(text("صندوق یا حساب بانکی"));box.addView(account)
        AlertDialog.Builder(this).setTitle(title).setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ثبت تراکنش"){_,_->val a=parseLongDigits(amount.text.toString());val whenAt=readDate(date);if(a==null||a<=0){toast("مبلغ معتبر وارد کنید");return@setPositiveButton};if(whenAt==null){toast("تاریخ شمسی معتبر وارد کنید");return@setPositiveButton};val methodName=methods[method.selectedItemPosition];val paid=parseLongDigits(settled.text.toString()) ?: if(methodName=="نسیه/تسویه بعدی")0L else a;val method2Name=methods2[method2.selectedItemPosition];val paid2=parseLongDigits(settled2.text.toString()) ?: 0L;if(paid<0||paid2<0||paid+paid2>a){toast("مجموع مبالغ تسویه نباید از مبلغ کل بیشتر باشد");return@setPositiveButton};if(types[sp.selectedItemPosition] in listOf("دریافت وجه","پرداخت وجه") && paid+paid2==0L){toast("برای دریافت یا پرداخت وجه، مبلغ تسویه‌شده باید بیشتر از صفر باشد");return@setPositiveButton};if(paid2>0&&method2Name=="بدون روش دوم"){toast("برای مبلغ روش دوم، روش تسویه دوم را انتخاب کنید");return@setPositiveButton};val needsInstrument=methodName=="چک"||methodName=="سفته"||(paid2>0&&(method2Name=="چک"||method2Name=="سفته"));val dueAt=if(needsInstrument)readDate(due) else null;if(needsInstrument&&(dueAt==null||dueAt<whenAt)){toast("برای چک یا سفته، سررسید معتبر و بعد از تاریخ عملیات وارد کنید");return@setPositiveButton};val goods="کالا: ${itemName.text}; تعداد: ${itemQty.text} ${itemUnit.text}; قیمت واحد: ${itemPrice.text}";val fullDetails=listOf(details.text.toString().trim(),goods).filter{it.isNotBlank() && it!="کالا: ; تعداد:  ; قیمت واحد: "}.joinToString(" | ");val operationPersonId=personId ?: peopleForEntry.getOrNull(personPicker.selectedItemPosition-1)?.id;val txId=db.addTx(operationPersonId,types[sp.selectedItemPosition],a,note.text.toString().trim(),account.selectedItem?.toString() ?: "نقدی",whenAt);if(paid>0)db.addSettlement(txId,methodName,paid,reference.text.toString().trim(),fullDetails);if(paid2>0)db.addSettlement(txId,method2Name,paid2,"",fullDetails);if((methodName=="چک"||methodName=="سفته")&&paid>0)db.addInstrument(txId,operationPersonId,methodName,reference.text.toString().trim(),bank.text.toString().trim(),operationPersonId?.let{db.personName(it)}?:"",paid,whenAt,dueAt!!,fullDetails);if(paid2>0&&(method2Name=="چک"||method2Name=="سفته"))db.addInstrument(txId,operationPersonId,method2Name,"",bank.text.toString().trim(),operationPersonId?.let{db.personName(it)}?:"",paid2,whenAt,dueAt!!,fullDetails);if(operationPersonId==null)showFinance()else personPage(operationPersonId)}.show()
    }
    private fun editTxDialog(t:Tx) {
        val types=if(t.personId==null) arrayOf("دریافت وجه","پرداخت وجه","درآمد","هزینه") else arrayOf("طلب","بدهی","دریافت وجه","پرداخت وجه","دریافت کالا","تحویل کالا","فروش نسیه","خرید نسیه")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val kind=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types);setSelection(types.indexOf(t.kind).coerceAtLeast(0))}
        val amount=field("مبلغ به تومان",true).apply{setText(t.amount.toString())};val note=field("شرح / توضیحات").apply{setText(t.note)};val date=dateFields(box,t.createdAt)
        val account=styledSpinner().apply{val items=db.accounts();adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);setSelection(items.indexOf(t.account).coerceAtLeast(0))}
        box.addView(text("نوع عملیات"));box.addView(kind);box.addView(amount);box.addView(note);box.addView(text("صندوق یا حساب"));box.addView(account)
        AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره تغییرات"){_,_->val a=parseLongDigits(amount.text.toString());if(a==null||a<=0){toast("مبلغ معتبر وارد کنید");return@setPositiveButton};val whenAt=readDate(date);if(whenAt==null){toast("تاریخ شمسی معتبر وارد کنید");return@setPositiveButton};try{db.updateTx(t.id,types[kind.selectedItemPosition],a,note.text.toString().trim(),account.selectedItem?.toString() ?: "نقدی",whenAt);if(t.personId==null)showFinance() else personPage(t.personId)}catch(e:Exception){toast(e.message?:"ویرایش ناموفق")}}.show()
    }
    private fun reportDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val today=System.currentTimeMillis();val from=dateFields(box,today,"از تاریخ");val to=dateFields(box,today,"تا تاریخ")
        AlertDialog.Builder(this).setTitle("گزارش بازه‌ای") .setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("نمایش گزارش"){_,_->
            val start=readDate(from);val end=readDate(to)
            if(start==null||end==null||end<start){toast("بازه تاریخ معتبر نیست");return@setPositiveButton}
            val endExclusive=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis
            showReport(start,endExclusive)
        }.show()
    }
    private fun showReport(start:Long,endExclusive:Long){
        base("گزارش مالی بازه انتخابی"){showFinance()}
        val rows=db.transactionsBetween(start,endExclusive)
        val totals=db.cashTotals(start,endExclusive);val income=totals.first;val expense=totals.second
        val opening=db.cashBalanceBefore(start); val closing=opening+income-expense
        val box=card().apply{setBackgroundColor(pale)}
        box.addView(text("از ${jalali(start)} تا ${jalali(endExclusive-1)}",14f,green,true))
        box.addView(text("مانده اول دوره: ${fmt(opening)} ${moneyUnit()}",15f,green,true))
        box.addView(text("تعداد تراکنش‌ها: ${rows.size}",14f))
        box.addView(text("مجموع دریافت و درآمد: ${fmt(income)} ${moneyUnit()}",15f,green,true))
        box.addView(text("مجموع پرداخت و هزینه: ${fmt(expense)} ${moneyUnit()}",15f,red,true))
        box.addView(text("خالص گردش نقدی این بازه: ${fmt(income-expense)} ${moneyUnit()}",15f,if(income>=expense)green else red,true))
        box.addView(text("مانده پایان دوره: ${fmt(closing)} ${moneyUnit()}",17f,if(closing>=0)green else red,true));root.addView(box)
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        if(rows.isEmpty())list.addView(text("در این بازه تراکنشی ثبت نشده است.")) else rows.forEach{list.addView(txCard(it,true));line(list)}
    }

    private fun showInstruments() {
        base("چک، سفته و سررسیدها"){showFinance()}
        root.addView(text("ابزارهای مالی ثبت‌شده؛ وضعیت اولیه هر مورد در انتظار است.",13f))
        val rows=db.instrumentRows()
        if(rows.isEmpty()) root.addView(text("هنوز چک یا سفته‌ای ثبت نشده است.")) else rows.forEach { item -> val c=card();c.addView(text(item.second,14f));c.addView(btn("تغییر وضعیت") { val statuses=arrayOf("در انتظار","وصول‌شده","پرداخت‌شده","برگشتی","باطل‌شده");AlertDialog.Builder(this).setTitle("وضعیت ابزار مالی").setItems(statuses){_,which->db.updateInstrumentStatus(item.first,statuses[which]);showInstruments()}.show() });root.addView(c);line(root) }
        root.addView(btn("بازگشت به امور مالی"){showFinance()})
    }
    private fun showInstallments() {
        base("مدیریت اقساط"){showFinance()}
        val rows=db.installmentRows()
        if(rows.isEmpty()) root.addView(text("برنامه قسط فعالی ثبت نشده است.")) else rows.forEach { item -> val c=card();c.addView(text(item.second,14f));c.addView(btn("ثبت پرداخت قسط") { val amount=field("مبلغ پرداخت‌شده به تومان",true);AlertDialog.Builder(this).setTitle("پرداخت قسط").setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت"){_,_->val a=parseLongDigits(amount.text.toString());if(a==null||a<=0){toast("مبلغ معتبر نیست");return@setPositiveButton};try{db.payInstallment(item.first,a);showInstallments()}catch(e:Exception){toast(e.message?:"ثبت پرداخت ناموفق")}}.show() });root.addView(c);line(root) }
        root.addView(btn("＋ ثبت برنامه اقساط"){installmentDialog()})
        root.addView(btn("بازگشت به امور مالی"){showFinance()})
    }
    private fun installmentDialog() {
        val ps=db.people(); if(ps.isEmpty()){toast("ابتدا یک شخص ثبت کنید");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val person=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,ps.map{it.name})}
        val title=field("عنوان قسط یا قرارداد");val total=field("مبلغ کل به تومان",true);val each=field("مبلغ هر قسط به تومان",true);val interval=field("فاصله اقساط به روز",true).apply{setText("30")};val notes=field("توضیحات");val date=dateFields(box,System.currentTimeMillis(),"تاریخ اولین سررسید")
        box.addView(text("شخص"));box.addView(person);box.addView(title);box.addView(total);box.addView(each);box.addView(interval);box.addView(notes)
        AlertDialog.Builder(this).setTitle("ثبت برنامه اقساط").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->val t=parseLongDigits(total.text.toString());val e=parseLongDigits(each.text.toString());val days=parseLongDigits(interval.text.toString())?.toInt();val at=readDate(date);if(title.text.isBlank()||t==null||e==null||days==null||at==null){toast("همه مقادیر ضروری را درست وارد کنید");return@setPositiveButton};try{db.addInstallment(ps[person.selectedItemPosition].id,title.text.toString(),t,e,days,at,notes.text.toString());showInstallments()}catch(ex:Exception){toast(ex.message?:"ثبت ناموفق")}}.show()
    }
    private fun reconcileDialog() {
        val accounts=db.accounts();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val account=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts)}
        val from=dateFields(box,System.currentTimeMillis(),"از تاریخ");val to=dateFields(box,System.currentTimeMillis(),"تا تاریخ");val statement=field("مانده صورت‌حساب بانک به تومان",true);val notes=field("توضیحات / علت اختلاف")
        box.addView(text("حساب مورد بررسی"));box.addView(account);box.addView(statement);box.addView(notes)
        AlertDialog.Builder(this).setTitle("مغایرت‌گیری حساب").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("مقایسه و ذخیره نتیجه"){_,_->val start=readDate(from);val end=readDate(to);val amount=parseLongDigits(statement.text.toString());if(start==null||end==null||end<start||amount==null){toast("تاریخ یا مانده صورت‌حساب معتبر نیست");return@setPositiveButton};val endX=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis;val result=db.reconcile(account.selectedItem.toString(),start,endX,amount,notes.text.toString());AlertDialog.Builder(this).setTitle(if(result.second==0L)"حساب مطابقت دارد" else "مغایرت شناسایی شد").setMessage("مانده محاسبه‌شده دفتر: ${fmt(result.first)} ${moneyUnit()}\nاختلاف صورت‌حساب با دفتر: ${fmt(result.second)} ${moneyUnit()}\n\nاین نتیجه ذخیره شد؛ اصلاح خودکار تراکنش‌ها انجام نمی‌شود.").setPositiveButton("متوجه شدم"){_,_->showReconcileHistory()}.show()}.show()
    }
    private fun showReconcileHistory() {
        base("سوابق مغایرت‌گیری"){showFinance()};val rows=db.reconciliationHistory();if(rows.isEmpty())root.addView(text("سابقه‌ای وجود ندارد")) else rows.forEach{root.addView(card().apply{addView(text(it,14f))});line(root)}
        root.addView(btn("مغایرت‌گیری جدید"){reconcileDialog()})
    }

    private fun showAccounts() {
        base("صندوق‌ها و حساب‌ها"){showHome()}
        root.addView(text("مانده هر حساب بر اساس دریافت‌ها و پرداخت‌های ثبت‌شده",13f))
        db.accountBalances().forEach { item -> val c=card();c.addView(text(item.first,17f,green,true));val detail=db.accountDetails(item.first);if(detail.isNotBlank())c.addView(text(detail,12f));c.addView(text("مانده: ${fmt(item.second)} ${moneyUnit()}",16f,if(item.second>=0)green else red,true));c.addView(btn("ثبت / اصلاح مانده اول دوره") { openingBalanceDialog(item.first) });c.addView(btn("گزارش این حساب") { accountReportDialog(item.first) });c.addView(btn("غیرفعال‌کردن حساب") { AlertDialog.Builder(this).setMessage("حساب برای ثبت‌های جدید غیرفعال شود؟ سوابق و تراکنش‌های قبلی حفظ می‌شوند.").setNegativeButton("انصراف",null).setPositiveButton("غیرفعال کن"){_,_->db.setAccountActive(item.first,false);showAccounts()}.show() });root.addView(c);line(root) }
        root.addView(btn("⇄ انتقال وجه بین دو حساب") { transferDialog() })
        root.addView(btn("سوابق اصلاح مانده اول دوره") { showOpeningHistory() })
        val inactive=db.inactiveAccounts()
        if(inactive.isNotEmpty()) { root.addView(text("حساب‌های غیرفعال",15f,red,true));inactive.forEach { name -> root.addView(btn("فعال‌سازی دوباره: $name") { db.setAccountActive(name,true);showAccounts() }) } }
        root.addView(btn("＋ افزودن صندوق یا حساب بانکی") {
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
            val name=field("عنوان دلخواه حساب؛ مثلاً بانک ملی شخصی");val bank=field("نام بانک");val types=arrayOf("صندوق","حساب جاری","پس‌انداز","کوتاه‌مدت","بلندمدت","کارت بانکی","سایر");val type=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types)};val number=field("شماره حساب");val cardNo=field("شماره کارت");val iban=field("شماره شبا");val owner=field("نام صاحب حساب (در صورت نیاز)");val ownerPeople=db.people();val ownerLink=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("بدون اتصال به پرونده شخص")+ownerPeople.map{it.name})};val notes=field("توضیحات")
            box.addView(name);box.addView(bank);box.addView(text("نوع حساب"));box.addView(type);box.addView(number);box.addView(cardNo);box.addView(iban);box.addView(owner);box.addView(text("اتصال به پرونده مرکزی صاحب حساب (اختیاری)"));box.addView(ownerLink);box.addView(notes)
            AlertDialog.Builder(this).setTitle("ثبت حساب مستقل").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->val ownerId=if(ownerLink.selectedItemPosition==0)null else ownerPeople[ownerLink.selectedItemPosition-1].id;if(db.addAccount(name.text.toString(),bank.text.toString(),types[type.selectedItemPosition],number.text.toString(),cardNo.text.toString(),iban.text.toString(),owner.text.toString(),ownerId,notes.text.toString()))showAccounts()else toast("عنوان خالی یا تکراری است")}.show()
        })
        root.addView(btn("بازگشت به خانه"){showHome()})
    }
    private fun showOpeningHistory() {
        base("سوابق اصلاح مانده اول دوره"){showAccounts()}
        val rows=mutableListOf<String>()
        db.readableDatabase.rawQuery("SELECT account,old_balance,old_at,new_balance,new_at,reason,changed_at FROM account_opening_history ORDER BY id DESC LIMIT 100",null).use { c -> while(c.moveToNext()) rows.add("${c.getString(0)}\nقبلی: ${fmt(c.getLong(1))} در ${jalali(c.getLong(2))}\nجدید: ${fmt(c.getLong(3))} در ${jalali(c.getLong(4))}${if(c.getString(5).isNullOrBlank())"" else "\nعلت: ${c.getString(5)}"}") }
        if(rows.isEmpty())root.addView(text("سابقه‌ای ثبت نشده است.")) else rows.forEach{root.addView(card().apply{addView(text(it,14f))});line(root)}
    }
    private fun openingBalanceDialog(account:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val existing=db.accountOpening(account);val amount=field("مانده اول دوره به تومان",true).apply{setText(existing.first.toString())};val reason=field("علت ثبت یا اصلاح (اختیاری)"); val date=dateFields(box,if(existing.second>0)existing.second else System.currentTimeMillis(),"تاریخ مبنای مانده")
        box.addView(text("مبلغ مثبت برای موجودی و مبلغ منفی برای کسری/بدهی وارد شود. تغییر تاریخ مبنا، محاسبه گردش‌های قدیمی‌تر را تغییر می‌دهد."));box.addView(amount);box.addView(reason)
        AlertDialog.Builder(this).setTitle("مانده اول دوره • $account").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->val a=parseLongDigits(amount.text.toString());val at=readDate(date);if(a==null||at==null){toast("مبلغ یا تاریخ معتبر نیست");return@setPositiveButton};db.setOpeningBalance(account,a,at,reason.text.toString());showAccounts()}.show()
    }
    private fun transferDialog() {
        val accounts=db.accounts();if(accounts.size<2){toast("برای انتقال، ابتدا حداقل دو حساب بسازید");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val from=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts)}
        val to=styledSpinner().apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts);setSelection(1)}
        val amount=field("مبلغ انتقال به تومان",true);val note=field("شرح انتقال");val date=dateFields(box,System.currentTimeMillis())
        box.addView(text("از حساب"));box.addView(from);box.addView(text("به حساب"));box.addView(to);box.addView(amount);box.addView(note)
        AlertDialog.Builder(this).setTitle("انتقال وجه بین حساب‌ها").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال"){_,_->val a=parseLongDigits(amount.text.toString());val at=readDate(date);if(from.selectedItemPosition==to.selectedItemPosition){toast("حساب مبدأ و مقصد باید متفاوت باشند");return@setPositiveButton};if(a==null||a<=0||at==null){toast("مبلغ یا تاریخ معتبر نیست");return@setPositiveButton};try{db.transfer(from.selectedItem.toString(),to.selectedItem.toString(),a,note.text.toString().trim(),at);showAccounts()}catch(e:Exception){toast(e.message?:"ثبت انتقال ناموفق بود")}}.show()
    }
    private fun accountReportDialog(account:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val today=System.currentTimeMillis();val from=dateFields(box,today,"از تاریخ");val to=dateFields(box,today,"تا تاریخ")
        AlertDialog.Builder(this).setTitle("گزارش حساب • $account").setView(styleDialogView(box)).setNegativeButton("انصراف",null).setPositiveButton("نمایش"){_,_->val start=readDate(from);val end=readDate(to);if(start==null||end==null||end<start){toast("بازه تاریخ معتبر نیست");return@setPositiveButton};val endX=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis;showAccountReport(account,start,endX)}.show()
    }
    private fun showAccountReport(account:String,start:Long,endExclusive:Long) {
        base("گزارش حساب • $account"){showAccounts()}
        val opening=db.accountBalanceBefore(account,start);val accountBaseDate=db.accountOpeningAt(account);val rows=db.transactionsBetween(start,endExclusive).filter{it.account==account && it.createdAt>=accountBaseDate};val totals=db.cashTotals(start,endExclusive,account);val income=totals.first;val expense=totals.second
        val transfers=db.accountTransfers(account,start,endExclusive);val transferTotals=db.accountTransferTotals(account,start,endExclusive);val transferIn=transferTotals.first;val transferOut=transferTotals.second
        val box=card().apply{setBackgroundColor(pale)};box.addView(text("از ${jalali(start)} تا ${jalali(endExclusive-1)}",14f,green,true));box.addView(text("مانده اول دوره: ${fmt(opening)} ${moneyUnit()}",15f,green,true));box.addView(text("دریافت و درآمد: ${fmt(income)} ${moneyUnit()}"));box.addView(text("پرداخت و هزینه: ${fmt(expense)} ${moneyUnit()}"));box.addView(text("واریز از حساب‌های دیگر: ${fmt(transferIn)} ${moneyUnit()}"));box.addView(text("انتقال به حساب‌های دیگر: ${fmt(transferOut)} ${moneyUnit()}"));val closing=opening+income-expense+transferIn-transferOut;box.addView(text("مانده پایان دوره: ${fmt(closing)} ${moneyUnit()}",17f,if(closing>=0)green else red,true));root.addView(box)
        root.addView(text("تراکنش‌های حساب (${rows.size})",16f,green,true));val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));if(rows.isEmpty())list.addView(text("تراکنش نقدی در این بازه وجود ندارد."))else rows.forEach{list.addView(txCard(it,true));line(list)}
        root.addView(text("انتقال‌های بین حسابی",16f,green,true));if(transfers.isEmpty())root.addView(text("انتقالی در این بازه ثبت نشده است."))else transfers.forEach{root.addView(text(it,13f))}
    }

    private fun txCard(t:Tx,allowDelete:Boolean):LinearLayout{
        val c=card();val color=when(t.kind){"دریافت وجه","درآمد","طلب","پرداخت وجه","تحویل کالا","فروش نسیه"->green;else->red};c.addView(text("${t.kind}  •  ${fmt(t.amount)} ${moneyUnit()}",16f,color,true));c.addView(text("${t.personName}  |  ${jalali(t.createdAt)}  |  ${t.account}",12f,0xff68736b.toInt()));if(t.note.isNotBlank())c.addView(text(t.note,14f));val settlement=db.settlementSummary(t.id);if(settlement.isNotBlank())c.addView(text("روش/جزئیات تسویه: $settlement",12f,0xff53645a.toInt()));val docs=db.txDocuments(t.id);if(docs.isNotEmpty())c.addView(btn("مشاهده ${docs.size} پیوست") { showTxDocuments(t.id) });if(allowDelete)c.addView(btn("افزودن عکس/مدرک به تراکنش") { pendingTxDocumentId=t.id;try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},requestChooseTxDocument)}catch(e:Exception){toast("انتخاب فایل ممکن نیست")} });if(allowDelete)c.addView(btn("ویرایش تراکنش") { editTxDialog(t) });if(allowDelete)c.addView(btn("انتقال به سطل بازیابی") { AlertDialog.Builder(this).setMessage("این تراکنش به سطل بازیابی منتقل شود؟").setNegativeButton("انصراف",null).setPositiveButton("انتقال"){_,_->db.deleteTx(t.id);if(t.personId==null)showFinance()else personPage(t.personId)}.show() });return c
    }
    private fun showTxDocuments(txId:Long) {
        val docs=db.txDocuments(txId);if(docs.isEmpty()){toast("پیوستی ثبت نشده است");return}
        AlertDialog.Builder(this).setTitle("پیوست‌های تراکنش").setItems(docs.map{it.second}.toTypedArray()){_,which->val item=docs[which];val data=db.txDocumentData(item.first)?:return@setItems;val image=personPhotoView(data,260).apply{layoutParams=LinearLayout.LayoutParams(260,260).apply{gravity=Gravity.CENTER}};AlertDialog.Builder(this).setTitle(item.second).setView(image).setNegativeButton("بستن",null).setPositiveButton("حذف پیوست"){_,_->db.deleteTxDocument(item.first);toast("پیوست حذف شد")}.show()}.setNegativeButton("بستن",null).show()
    }
    private fun showTrash(){base("سطل بازیابی"){showHome()};val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));val rows=db.deletedTx();if(rows.isEmpty())list.addView(text("سطل بازیابی خالی است.")) else rows.forEach{t->val c=card();c.addView(text("${t.kind} - ${fmt(t.amount)} ${moneyUnit()}",15f));c.addView(text(t.note));c.addView(btn("بازیابی تراکنش") { db.restoreTx(t.id);showTrash() });list.addView(c);line(list)}}

    private fun showBackup(){
        base("پشتیبان‌گیری و بازیابی اطلاعات"){showHome()}
        root.addView(text("نوع پشتیبان را پیش از ساخت انتخاب کنید. فایل خروجی نوع و محتوای خود را در مشخصات داخلی ثبت می‌کند.",14f))
        root.addView(btn("ساخت پشتیبان با انتخاب نوع") {
            val labels=arrayOf("فقط تنظیمات برنامه","فقط اطلاعات و داده‌ها","تنظیمات و اطلاعات با هم")
            AlertDialog.Builder(this).setTitle("نوع پشتیبان‌گیری").setItems(labels){_,which->
                pendingBackupType=when(which){0->"settings";1->"data";else->"both"}
                val summary=when(pendingBackupType){"settings"->"تنظیمات ظاهری بخش‌ها، منتخب‌ها، ترجیحات نمایش و فیلتر/مرتب‌سازی فهرست اشخاص";"data"->"پایگاه داده، پرونده‌ها، تراکنش‌ها، سوابق و پیوست‌های ذخیره‌شده در پایگاه داده";else->"همه تنظیمات و همه اطلاعات و داده‌های برنامه"}
                AlertDialog.Builder(this).setTitle("پیش‌نمایش محتویات پشتیبان").setMessage("نوع: ${labels[which]}\n\nمحتوا: $summary\n\nرمزهای بانکی و اطلاعات ورود محرمانه در این بسته قرار نمی‌گیرند.").setNegativeButton("انصراف",null).setPositiveButton("انتخاب محل ذخیره"){_,_->
                    val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip";putExtra(Intent.EXTRA_TITLE,"Modiriat_Zendegi_${pendingBackupType}_${System.currentTimeMillis()}.mzb")};startActivityForResult(intent,requestCreateBackup)
                }.show()
            }.show()
        })
        root.addView(btn("بازیابی از فایل پشتیبان") {
            AlertDialog.Builder(this).setTitle("انتخاب فایل پشتیبان").setMessage("ابتدا نوع و سلامت فایل بررسی می‌شود. پیش از هر جایگزینی، محتوای آن و اثر بازیابی به شما نمایش داده خواهد شد.").setNegativeButton("انصراف",null).setPositiveButton("انتخاب فایل"){_,_->val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"};startActivityForResult(intent,requestRestoreBackup)}.show()
        })
        root.addView(text("راهنما",16f,green,true))
        root.addView(text("• پشتیبان‌های جدید با رمز عبور و رمزگذاری احرازشده AES-256-GCM ذخیره می‌شوند.\n• رمز عبور را در جای امن نگهداری کنید؛ بدون آن بازیابی ممکن نیست.\n• پشتیبان‌های قدیمیِ بدون رمز همچنان قابل بازیابی هستند.\n• هنگام بازیابی فقط گروه موجود در فایل جایگزین می‌شود.",13f))
        root.addView(btn("بازگشت به خانه"){showHome()})
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK) return
        when(requestCode){
            4112 -> { val bitmap=data?.extras?.get("data") as? Bitmap ?: return;try{db.addDocument(pendingDocumentPersonId,pendingDocumentTitle,encodePersonPhoto(bitmap));personPage(pendingDocumentPersonId)}catch(e:Exception){toast("ثبت تصویر مدرک ناموفق بود")};return }
            4110 -> { val uri=data?.data ?: return; try{val encoded=savePersonPhoto(uri);db.addDocument(pendingDocumentPersonId,pendingDocumentTitle,encoded);personPage(pendingDocumentPersonId)}catch(e:Exception){toast("ثبت مدرک ناموفق بود")};return }
            4111 -> { val uri=data?.data ?: return; try{val p=pendingPdfPerson ?: return;val file=File(cacheDir,"person_${p.id}.pdf");contentResolver.openOutputStream(uri,"w").use{out->if(out==null)throw IllegalStateException("فایل مقصد باز نشد");FileInputStream(file).use{it.copyTo(out)}};toast("گزارش PDF ذخیره شد")}catch(e:Exception){toast("ذخیره PDF ناموفق بود")};return }
            requestExportInvoicesCsv -> { val uri=data?.data ?: return;try{val file=File(cacheDir,"invoices_export.csv");contentResolver.openOutputStream(uri,"w").use{out->if(out==null)throw IllegalStateException("فایل مقصد باز نشد");FileInputStream(file).use{it.copyTo(out)}};toast("خروجی فاکتورها ذخیره شد")}catch(e:Exception){toast("ذخیره خروجی فاکتورها ناموفق بود: ${e.message ?: "خطا"}")};return }
            requestPickContact -> {
                val uri=data?.data ?: return
                try { contentResolver.query(uri,arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER),null,null,null)?.use { c -> if(c.moveToFirst()){activePersonName?.setText(c.getString(0) ?: "");activePersonPhone?.setText(c.getString(1) ?: "")} } }
                catch(e:Exception){toast("خواندن مخاطب انتخاب‌شده ناموفق بود")}
                return
            }
            requestTakePersonPhoto -> {
                val bitmap=data?.extras?.get("data") as? Bitmap ?: run{toast("دوربین عکسی برنگرداند");return}
                try { activePersonPhotoData=saveCameraPhoto(bitmap);refreshActivePhoto() } catch(e:Exception){toast("ذخیره عکس ناموفق بود")}
                return
            }
            requestChoosePersonPhoto -> {
                val uri=data?.data ?: return
                try { activePersonPhotoData=savePersonPhoto(uri);refreshActivePhoto() } catch(e:Exception){toast("بارگذاری عکس ناموفق بود")}
                return
            }
            requestChooseAppearanceBackground -> {
                val uri=data?.data ?: return
                try {
                    val flags=data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    try{contentResolver.takePersistableUriPermission(uri,flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
                    getSharedPreferences("home_dashboard",Context.MODE_PRIVATE).edit().putString("appearance_background_uri",uri.toString()).apply()
                    toast("پس‌زمینه انتخاب شد");showAppearanceBackgroundSettings()
                } catch(e:Exception){toast("انتخاب پس‌زمینه ناموفق بود: ${e.message ?: "خطا"}")}
                return
            }
            requestChooseTxDocument -> {
                val uri=data?.data ?: return
                val txId=pendingTxDocumentId ?: return
                try { val encoded=savePersonPhoto(uri);db.addTxDocument(txId,"پیوست ${db.txDocuments(txId).size+1}",encoded);toast("پیوست تراکنش ذخیره شد");val tx=db.transactions().firstOrNull{it.id==txId};if(tx!=null){if(tx.personId==null)showFinance()else personPage(tx.personId)} } catch(e:Exception){toast("ذخیره پیوست ناموفق بود: ${e.message ?: "خطا"}")}
                pendingTxDocumentId=null
                return
            }
        }
        val uri=data?.data ?: return
        when(requestCode){
            requestCreateBackup -> askBackupPassword(true) { password -> exportBackup(uri, password) }
            requestRestoreBackup -> inspectBackup(uri)
        }
    }

    // تنظیمات صفحه اصلی نیز باید همراه سایر تنظیمات پشتیبان‌گیری شوند.
    private val backupPreferenceNames=listOf("catalog_customization","money_display","people_list","home_dashboard")
    // برای سازگاری با فایل‌های پشتیبان قدیمی، سه مجموعه قبلی همچنان الزامی‌اند؛
    // home_dashboard در پشتیبان‌های قدیمی وجود ندارد و در صورت نبود، تنظیمات فعلی آن حفظ می‌شود.
    private val requiredBackupPreferenceNames=listOf("catalog_customization","money_display","people_list")
    private fun collectBackupSettings():JSONObject{
        val all=JSONObject()
        backupPreferenceNames.forEach{name->
            val obj=JSONObject();getSharedPreferences(name,Context.MODE_PRIVATE).all.forEach{(k,v)->when(v){is String->obj.put(k,JSONObject().put("type","string").put("value",v));is Boolean->obj.put(k,JSONObject().put("type","boolean").put("value",v));is Int->obj.put(k,JSONObject().put("type","int").put("value",v));is Long->obj.put(k,JSONObject().put("type","long").put("value",v));is Float->obj.put(k,JSONObject().put("type","float").put("value",v.toDouble()));is Set<*>->{val a=JSONArray();v.filterIsInstance<String>().forEach{a.put(it)};obj.put(k,JSONObject().put("type","string_set").put("value",a))};else->{}}};all.put(name,obj)
        };return all
    }
    private fun restoreBackupSettings(settings:JSONObject){
        backupPreferenceNames.forEach{name->val obj=settings.optJSONObject(name)?:return@forEach;val edit=getSharedPreferences(name,Context.MODE_PRIVATE).edit().clear();val keys=obj.keys();while(keys.hasNext()){val k=keys.next();val item=obj.optJSONObject(k)?:continue;when(item.optString("type")){"string"->edit.putString(k,item.optString("value"));"boolean"->edit.putBoolean(k,item.optBoolean("value"));"int"->edit.putInt(k,item.optInt("value"));"long"->edit.putLong(k,item.optLong("value"));"float"->edit.putFloat(k,item.optDouble("value").toFloat());"string_set"->{val a=item.optJSONArray("value")?:JSONArray();val set=(0 until a.length()).map{a.optString(it)}.toSet();edit.putStringSet(k,set)}}};if(!edit.commit())throw IllegalStateException("ذخیره تنظیمات بازیابی‌شده ناموفق بود")}
    }
    private fun askBackupPassword(confirm:Boolean, onAccepted:(CharArray)->Unit){
        val first=EditText(this).apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;hint="حداقل ۸ نویسه"}
        val second=if(confirm) EditText(this).apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;hint="تکرار رمز عبور"} else null
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(36,12,36,4);addView(first);if(second!=null)addView(second)}
        AlertDialog.Builder(this).setTitle(if(confirm)"تعیین رمز پشتیبان" else "رمز فایل پشتیبان")
            .setMessage(if(confirm)"این رمز برای بازیابی فایل لازم است. آن را فراموش نکنید." else "رمز فایل پشتیبان را وارد کنید.")
            .setView(box).setNegativeButton("انصراف",null).setPositiveButton("ادامه",null).create().also{dialog->
                dialog.setOnShowListener{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                    val a=first.text?.toString().orEmpty();val b=second?.text?.toString()
                    if(a.length<8){first.error="رمز باید حداقل ۸ نویسه باشد";return@setOnClickListener}
                    if(confirm&&a!=b){second?.error="تکرار رمز یکسان نیست";return@setOnClickListener}
                    dialog.dismiss();onAccepted(a.toCharArray());first.text?.clear();second?.text?.clear()
                }}
            }.show()
    }
    private fun exportBackup(uri:Uri, password:CharArray){
        val temp=File(cacheDir,"backup_${System.currentTimeMillis()}.mzb")
        try{
            val type=pendingBackupType
            // نسخه واقعی پایگاه داده پیش از بستن اتصال خوانده می‌شود.
            val databaseVersion=if(type!="settings") db.readableDatabase.version else null
            if(type!="data") {db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use{};db.close()}
            val appVersion=packageManager.getPackageInfo(packageName,0).versionName ?: "نامشخص"
            val manifest=JSONObject().put("format","ModiriatZendegiBackup").put("format_version",1).put("app_version",appVersion).put("database_version",databaseVersion ?: JSONObject.NULL).put("created_at",System.currentTimeMillis()).put("type",type).put("contains_settings",type!="data").put("contains_data",type!="settings")
            ZipOutputStream(FileOutputStream(temp)).use{zip->
                zip.putNextEntry(ZipEntry("manifest.json"));zip.write(manifest.toString().toByteArray(Charsets.UTF_8));zip.closeEntry()
                if(type!="settings") {val dbFile=getDatabasePath("ledger.db");if(!dbFile.exists())throw IllegalStateException("پایگاه داده پیدا نشد");zip.putNextEntry(ZipEntry("ledger.db"));FileInputStream(dbFile).use{it.copyTo(zip)};zip.closeEntry()}
                if(type!="data") {zip.putNextEntry(ZipEntry("settings.json"));zip.write(collectBackupSettings().toString().toByteArray(Charsets.UTF_8));zip.closeEntry()}
            }
            val encrypted=BackupCrypto.encrypt(temp.readBytes(),password)
            contentResolver.openOutputStream(uri,"w").use{out->if(out==null)throw IllegalStateException("فایل مقصد باز نشد");out.write(encrypted);out.flush()}
            encrypted.fill(0)
            toast("پشتیبان رمزگذاری‌شده ${when(type){"settings"->"تنظیمات";"data"->"داده‌ها";else->"کامل"}} ساخته شد")
        }catch(e:Exception){toast("ساخت پشتیبان ناموفق بود: ${e.message?:"خطا"}")}
        finally{password.fill('\u0000');temp.delete();try{db.close()}catch(_:Exception){};db=LedgerDb(this);showBackup()}
    }
    private fun inspectBackup(uri:Uri, password:CharArray?=null){
        val dir=File(cacheDir,"restore_${System.currentTimeMillis()}");dir.mkdirs()
        try{
            val raw=contentResolver.openInputStream(uri).use{input->if(input==null)throw IllegalArgumentException("فایل خوانده نشد");input.readBytes()}
            val payload=if(BackupCrypto.isEncrypted(raw)){
                if(password==null){raw.fill(0);dir.deleteRecursively();askBackupPassword(false){entered->inspectBackup(uri,entered)};return}
                try{BackupCrypto.decrypt(raw,password)}finally{password.fill('\u0000');raw.fill(0)}
            }else raw
            val zipInput=ByteArrayInputStream(payload)
            ZipInputStream(zipInput).use{zip->var entry=zip.nextEntry;while(entry!=null){if(entry.name !in setOf("manifest.json","settings.json","ledger.db"))throw IllegalArgumentException("محتوای ناشناخته در فایل پشتیبان");if(!entry.isDirectory){val out=File(dir,entry.name);if(out.exists())throw IllegalArgumentException("ورودی تکراری در فایل پشتیبان");FileOutputStream(out).use{zip.copyTo(it)};if(out.length()>536870912L)throw IllegalArgumentException("اندازه فایل پشتیبان بیش از حد مجاز است")};zip.closeEntry();entry=zip.nextEntry}}
            payload.fill(0)
            val manifestFile=File(dir,"manifest.json");if(!manifestFile.exists())throw IllegalArgumentException("قالب فایل پشتیبان شناخته نشد؛ نسخه‌های قدیمی SQLite در این مرحله بازیابی نمی‌شوند")
            val m=JSONObject(manifestFile.readText());if(m.optString("format")!="ModiriatZendegiBackup"||m.optInt("format_version")!=1)throw IllegalArgumentException("نسخه قالب پشتیبان پشتیبانی نمی‌شود")
            val hasSettings=m.optBoolean("contains_settings");val hasData=m.optBoolean("contains_data");if(!hasSettings&&!hasData)throw IllegalArgumentException("فایل هیچ محتوای قابل بازیابی ندارد")
            if(hasSettings&&!File(dir,"settings.json").exists())throw IllegalArgumentException("بخش تنظیمات ناقص است")
            if(hasSettings){val settingsCheck=JSONObject(File(dir,"settings.json").readText());if(requiredBackupPreferenceNames.any{!settingsCheck.has(it)})throw IllegalArgumentException("فهرست تنظیمات اصلی پشتیبان ناقص است")}
            if(hasData){val dbFile=File(dir,"ledger.db");if(!dbFile.exists())throw IllegalArgumentException("بخش اطلاعات ناقص است");val check=SQLiteDatabase.openDatabase(dbFile.absolutePath,null,SQLiteDatabase.OPEN_READONLY);try{var integrity="";check.rawQuery("PRAGMA integrity_check",null).use{c->if(c.moveToFirst())integrity=c.getString(0)};if(integrity!="ok")throw IllegalArgumentException("سلامت پایگاه داده تأیید نشد");val found=mutableSetOf<String>();check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'",null).use{c->while(c.moveToNext())found.add(c.getString(0))};if(!found.containsAll(setOf("people","transactions","finance_accounts","audit_log")))throw IllegalArgumentException("ساختار پایگاه داده ناقص است");if(check.version>LedgerDb.DATABASE_VERSION)throw IllegalArgumentException("پشتیبان متعلق به نسخه جدیدتری است")}finally{check.close()}}
            val desc=buildString{append("نوع فایل: ");append(when{hasSettings&&hasData->"تنظیمات و اطلاعات با هم";hasSettings->"فقط تنظیمات";else->"فقط اطلاعات و داده‌ها"});append("\nنسخه برنامه: ");append(m.optString("app_version"));append("\nتاریخ تهیه: ");append(Date(m.optLong("created_at")));append("\n\n") ;append(if(hasSettings)"تنظیمات برنامه بازیابی می‌شوند.\n" else "تنظیمات فعلی دست‌نخورده می‌مانند.\n");append(if(hasData)"پایگاه داده فعلی با داده‌های فایل جایگزین می‌شود.\n" else "اطلاعات و پایگاه داده فعلی دست‌نخورده می‌مانند.\n");append("پیش از جایگزینی، نسخه اضطراری از داده‌های فعلی نگهداری می‌شود.")}
            AlertDialog.Builder(this).setTitle("بررسی و تأیید بازیابی").setMessage(desc).setNegativeButton("انصراف"){_,_->dir.deleteRecursively()}.setPositiveButton("تأیید بازیابی"){_,_->restoreBackupPackage(dir,hasSettings,hasData)}.setOnCancelListener{dir.deleteRecursively()}.show()
        }catch(e:Exception){password?.fill('\u0000');dir.deleteRecursively();toast("فایل پشتیبان قابل بازیابی نیست: ${e.message?:"خطا"}")}
    }
    private fun restoreBackupPackage(dir:File,hasSettings:Boolean,hasData:Boolean){
        val stamp=System.currentTimeMillis();var safety:File?=null
        try{
            if(hasData){
                val live=getDatabasePath("ledger.db");db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use{};db.close()
                safety=File(filesDir,"ledger_before_restore_$stamp.sqlite");if(live.exists())FileInputStream(live).use{input->FileOutputStream(safety!!).use{input.copyTo(it)}}
                File(live.path+"-wal").delete();File(live.path+"-shm").delete()
                val candidate=File(live.parentFile,"ledger_restore_candidate_$stamp.sqlite");FileInputStream(File(dir,"ledger.db")).use{input->FileOutputStream(candidate).use{input.copyTo(it)}}
                if(live.exists()&&!live.delete())throw IllegalStateException("آماده‌سازی پایگاه فعلی ناموفق بود");if(!candidate.renameTo(live))throw IllegalStateException("جایگزینی پایگاه داده ناموفق بود")
                db=LedgerDb(this);db.readableDatabase
            }
            if(hasSettings){val settings=JSONObject(File(dir,"settings.json").readText());restoreBackupSettings(settings)}
            toast("بازیابی بخش‌های انتخاب‌شده با موفقیت انجام شد");dir.deleteRecursively();showHome()
        }catch(e:Exception){
            try{db.close()}catch(_:Exception){}
            if(safety!=null&&safety!!.exists()){val live=getDatabasePath("ledger.db");File(live.path+"-wal").delete();File(live.path+"-shm").delete();if(live.exists())live.delete();FileInputStream(safety!!).use{input->FileOutputStream(live).use{input.copyTo(it)}}}
            db=LedgerDb(this);dir.deleteRecursively();toast("بازیابی ناموفق بود؛ نسخه اضطراری حفظ/بازگردانی شد: ${e.message?:"خطا"}");showBackup()
        }
    }

    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    @Deprecated("Deprecated in Android") override fun onBackPressed(){showHome()}
}

class PersonReminderReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel="person_reminders"
        if(android.os.Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel(channel,"یادآوری‌های اشخاص",NotificationManager.IMPORTANCE_DEFAULT))
        val title=intent.getStringExtra("reminder_title") ?: "یادآوری"
        val person=intent.getStringExtra("person_name") ?: ""
        val notification=if(android.os.Build.VERSION.SDK_INT>=26) Notification.Builder(context,channel) else Notification.Builder(context)
        if(android.os.Build.VERSION.SDK_INT<33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==android.content.pm.PackageManager.PERMISSION_GRANTED) manager.notify((intent.getLongExtra("reminder_id",System.currentTimeMillis())%Int.MAX_VALUE).toInt(),notification.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(person).setAutoCancel(true).build())
    }
}
