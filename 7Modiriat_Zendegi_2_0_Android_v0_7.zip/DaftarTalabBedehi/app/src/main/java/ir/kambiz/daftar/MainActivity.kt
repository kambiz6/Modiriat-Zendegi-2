package ir.kambiz.daftar

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.text.DecimalFormat
import java.util.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import android.net.Uri
import android.database.sqlite.SQLiteDatabase

data class Person(val id: Long, val name: String, val phone: String, val address: String, val relation: String, val notes: String, val balance: Long, val receivable: Long, val payable: Long)
data class Tx(val id: Long, val personId: Long?, val personName: String, val kind: String, val amount: Long, val note: String, val createdAt: Long, val account: String)
data class Summary(val income: Long, val expense: Long, val balance: Long, val receivable: Long, val payable: Long)

class LedgerDb(ctx: Context) : SQLiteOpenHelper(ctx, "ledger.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', address TEXT DEFAULT '', relation TEXT DEFAULT '', notes TEXT DEFAULT '', is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)")
        createTransactions(db)
        db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target TEXT NOT NULL, target_id INTEGER, details TEXT DEFAULT '', created_at INTEGER NOT NULL)")
        createAccounts(db)
        createTransfers(db)
        db.execSQL("CREATE INDEX idx_tx_date ON transactions(created_at)")
        db.execSQL("CREATE INDEX idx_tx_person ON transactions(person_id)")
    }
    private fun createTransactions(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NULL, kind TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), note TEXT DEFAULT '', created_at INTEGER NOT NULL, account TEXT DEFAULT 'نقدی', is_deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(person_id) REFERENCES people(id))")
    }
    private fun createAccounts(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS finance_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, opening_balance INTEGER NOT NULL DEFAULT 0, opening_at INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("INSERT OR IGNORE INTO finance_accounts(name,created_at) VALUES('نقدی',?)", arrayOf(System.currentTimeMillis()))
    }
    private fun createTransfers(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS account_transfers(id INTEGER PRIMARY KEY AUTOINCREMENT, from_account TEXT NOT NULL, to_account TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), note TEXT DEFAULT '', created_at INTEGER NOT NULL, is_deleted INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transfer_date ON account_transfers(created_at)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE people ADD COLUMN address TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN relation TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN notes TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE people ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0")
            createTransactions(db)
            db.execSQL("INSERT INTO transactions(person_id,kind,amount,note,created_at) SELECT e.person_id,e.kind,e.amount,e.note,e.created_at FROM entries e")
            db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target TEXT NOT NULL, target_id INTEGER, details TEXT DEFAULT '', created_at INTEGER NOT NULL)")
            db.execSQL("CREATE INDEX idx_tx_date ON transactions(created_at)")
            db.execSQL("CREATE INDEX idx_tx_person ON transactions(person_id)")
        }
        if (oldVersion < 3) {
            createAccounts(db)
            db.execSQL("INSERT OR IGNORE INTO finance_accounts(name,created_at) SELECT DISTINCT CASE WHEN TRIM(COALESCE(account,''))='' THEN 'نقدی' ELSE account END, ? FROM transactions", arrayOf(System.currentTimeMillis()))
        }
        if (oldVersion < 4) {
            val columns=mutableSetOf<String>()
            db.rawQuery("PRAGMA table_info(finance_accounts)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
            if(!columns.contains("opening_balance")) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN opening_balance INTEGER NOT NULL DEFAULT 0")
            if(!columns.contains("opening_at")) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN opening_at INTEGER NOT NULL DEFAULT 0")
            createTransfers(db)
        }
    }
    override fun onOpen(db: SQLiteDatabase) { super.onOpen(db); db.setForeignKeyConstraintsEnabled(true) }
    fun accounts(): List<String> {
        val out= mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM finance_accounts WHERE is_deleted=0 ORDER BY id",null).use { c -> while(c.moveToNext()) out.add(c.getString(0)) }
        if(out.isEmpty()) out.add("نقدی")
        return out
    }
    fun addAccount(name:String): Boolean {
        val n=name.trim(); if(n.isEmpty()) return false
        return try { writableDatabase.insertOrThrow("finance_accounts",null,android.content.ContentValues().apply { put("name",n); put("created_at",System.currentTimeMillis()) }); audit("ایجاد","حساب مالی",-1,n); true } catch (_:Exception) { false }
    }
    fun accountBalanceBefore(account:String, timestamp:Long):Long {
        var opening=0L; var openingAt=0L
        readableDatabase.rawQuery("SELECT opening_balance,opening_at FROM finance_accounts WHERE name=? AND is_deleted=0",arrayOf(account)).use { c -> if(c.moveToFirst()){opening=c.getLong(0);openingAt=c.getLong(1)} }
        if(openingAt>timestamp) return 0L
        var balance=opening
        readableDatabase.rawQuery("SELECT kind,amount FROM transactions WHERE is_deleted=0 AND account=? AND created_at>=? AND created_at<?",arrayOf(account,openingAt.toString(),timestamp.toString())).use { c -> while(c.moveToNext()){val k=c.getString(0);val a=c.getLong(1);if(k=="دریافت وجه"||k=="درآمد")balance+=a else if(k=="پرداخت وجه"||k=="هزینه")balance-=a} }
        readableDatabase.rawQuery("SELECT t.from_account,t.to_account,t.amount FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=MAX(fa.opening_at,ta.opening_at) AND t.created_at<? AND (t.from_account=? OR t.to_account=?)",arrayOf(timestamp.toString(),account,account)).use { c -> while(c.moveToNext()){val a=c.getLong(2);if(c.getString(0)==account)balance-=a else balance+=a} }
        return balance
    }
    fun accountBalances(): List<Pair<String,Long>> = accounts().map { Pair(it,accountBalanceBefore(it,Long.MAX_VALUE)) }
    fun setOpeningBalance(account:String,amount:Long,at:Long) {
        writableDatabase.execSQL("UPDATE finance_accounts SET opening_balance=?,opening_at=? WHERE name=? AND is_deleted=0",arrayOf(amount,at,account))
        audit("ثبت مانده اول دوره","حساب مالی",-1,"$account: $amount @ $at")
    }
    fun transfer(from:String,to:String,amount:Long,note:String,at:Long) {
        require(from!=to) { "حساب مبدأ و مقصد باید متفاوت باشند" }; require(amount>0) { "مبلغ باید بیشتر از صفر باشد" }
        val d=writableDatabase; d.beginTransaction()
        try { d.execSQL("INSERT INTO account_transfers(from_account,to_account,amount,note,created_at) VALUES(?,?,?,?,?)",arrayOf(from,to,amount,note,at)); audit("انتقال وجه بین حساب‌ها","انتقال",-1,"$from ← $to: $amount"); d.setTransactionSuccessful() } finally { d.endTransaction() }
    }
    fun accountTransfers(account:String,start:Long,endExclusive:Long):List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT t.from_account,t.to_account,t.amount,t.note,t.created_at FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=MAX(fa.opening_at,ta.opening_at) AND t.created_at>=? AND t.created_at<? AND (t.from_account=? OR t.to_account=?) ORDER BY t.created_at DESC,t.id DESC",arrayOf(start.toString(),endExclusive.toString(),account,account)).use { c -> while(c.moveToNext()){val incoming=c.getString(1)==account;out.add("${if(incoming)"واریز از ${c.getString(0)}" else "انتقال به ${c.getString(1)}"} • ${fmt(c.getLong(2))} تومان • ${jalali(c.getLong(4))}${if(c.getString(3).isNullOrBlank())"" else " • ${c.getString(3)}"}")} }
        return out
    }
    fun accountTransferTotals(account:String,start:Long,endExclusive:Long):Pair<Long,Long> {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN t.to_account=? THEN t.amount ELSE 0 END),0),COALESCE(SUM(CASE WHEN t.from_account=? THEN t.amount ELSE 0 END),0) FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=MAX(fa.opening_at,ta.opening_at) AND t.created_at>=? AND t.created_at<? AND (t.from_account=? OR t.to_account=?)",arrayOf(account,account,start.toString(),endExclusive.toString(),account,account)).use { c -> return if(c.moveToFirst()) Pair(c.getLong(0),c.getLong(1)) else Pair(0L,0L) }
    }
    fun accountOpeningAt(account:String):Long { readableDatabase.rawQuery("SELECT opening_at FROM finance_accounts WHERE name=?",arrayOf(account)).use { c -> return if(c.moveToFirst())c.getLong(0) else 0L } }
    fun accountOpening(account:String):Pair<Long,Long> { readableDatabase.rawQuery("SELECT opening_balance,opening_at FROM finance_accounts WHERE name=?",arrayOf(account)).use { c -> return if(c.moveToFirst())Pair(c.getLong(0),c.getLong(1)) else Pair(0L,0L) } }
    fun updateTx(id:Long, kind:String, amount:Long, note:String, account:String, createdAt:Long) {
        writableDatabase.execSQL("UPDATE transactions SET kind=?,amount=?,note=?,account=?,created_at=? WHERE id=? AND is_deleted=0",arrayOf(kind,amount,note,account,createdAt,id)); audit("ویرایش","تراکنش",id,"$kind - $amount")
    }
    private fun balances(personId: Long): Pair<Long,Long> {
        var receivable=0L; var payable=0L
        readableDatabase.rawQuery("SELECT kind,amount FROM transactions WHERE person_id=? AND is_deleted=0 ORDER BY created_at,id", arrayOf(personId.toString())).use { c ->
            while(c.moveToNext()) {
                val kind=c.getString(0); val amount=c.getLong(1)
                val increasesReceivable = kind in listOf("طلب","پرداخت وجه","تحویل کالا","فروش نسیه")
                if(increasesReceivable) {
                    val offset=minOf(payable,amount); payable-=offset; receivable+=amount-offset
                } else if(kind in listOf("بدهی","دریافت وجه","دریافت کالا","خرید نسیه")) {
                    val offset=minOf(receivable,amount); receivable-=offset; payable+=amount-offset
                }
            }
        }
        return Pair(receivable,payable)
    }
    fun people(q: String = ""): List<Person> {
        val out= mutableListOf<Person>()
        readableDatabase.rawQuery("SELECT id,name,phone,address,relation,notes FROM people WHERE is_deleted=0 AND (name LIKE ? OR phone LIKE ?) ORDER BY name", arrayOf("%$q%", "%$q%")).use { c ->
            while(c.moveToNext()) { val id=c.getLong(0); val b=balances(id); out.add(Person(id,c.getString(1),c.getString(2),c.getString(3) ?: "",c.getString(4) ?: "",c.getString(5) ?: "",b.first-b.second,b.first,b.second)) }
        }
        return out
    }
    fun addPerson(name: String, phone: String, address: String, relation: String, notes: String) {
        val id = writableDatabase.insertOrThrow("people", null, android.content.ContentValues().apply { put("name",name); put("phone",phone); put("address",address); put("relation",relation); put("notes",notes); put("created_at",System.currentTimeMillis()) })
        audit("ایجاد", "شخص", id, name)
    }
    fun archivePerson(id:Long) {
        writableDatabase.execSQL("UPDATE people SET is_deleted=1 WHERE id=? AND is_deleted=0",arrayOf(id))
        audit("بایگانی", "شخص", id, "پرونده از فهرست فعال خارج شد؛ سوابق مالی حفظ شدند")
    }
    fun restorePerson(id:Long) {
        writableDatabase.execSQL("UPDATE people SET is_deleted=0 WHERE id=? AND is_deleted=1",arrayOf(id))
        audit("بازیابی", "شخص", id, "بازگشت پرونده به فهرست فعال")
    }
    fun deletedPeople():List<Person> {
        val out=mutableListOf<Person>()
        readableDatabase.rawQuery("SELECT id,name,phone,address,relation,notes FROM people WHERE is_deleted=1 ORDER BY name",null).use { c ->
            while(c.moveToNext()) { val id=c.getLong(0); val b=balances(id); out.add(Person(id,c.getString(1),c.getString(2) ?: "",c.getString(3) ?: "",c.getString(4) ?: "",c.getString(5) ?: "",b.first-b.second,b.first,b.second)) }
        }
        return out
    }
    fun personTransactionCount(id:Long):Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM transactions WHERE person_id=?",arrayOf(id.toString())).use { c -> return if(c.moveToFirst()) c.getInt(0) else 0 }
    }
    fun addTx(personId: Long?, kind: String, amount: Long, note: String, account: String, createdAt:Long) {
        val id = writableDatabase.insertOrThrow("transactions", null, android.content.ContentValues().apply { if(personId==null) putNull("person_id") else put("person_id",personId); put("kind",kind); put("amount",amount); put("note",note); put("account",account.ifBlank { "نقدی" }); put("created_at",createdAt) })
        audit("ثبت", "تراکنش", id, "$kind - $amount")
    }
    private fun audit(action:String,target:String,id:Long,details:String) { writableDatabase.execSQL("INSERT INTO audit_log(action,target,target_id,details,created_at) VALUES(?,?,?,?,?)", arrayOf(action,target,id,details,System.currentTimeMillis())) }
    fun summary(): Summary {
        var inc=0L; var exp=0L
        readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN t.kind IN ('دریافت وجه','درآمد') THEN t.amount ELSE 0 END),0), COALESCE(SUM(CASE WHEN t.kind IN ('پرداخت وجه','هزینه') THEN t.amount ELSE 0 END),0) FROM transactions t LEFT JOIN finance_accounts a ON a.name=t.account WHERE t.is_deleted=0 AND t.created_at>=COALESCE(a.opening_at,0)",null).use { if(it.moveToFirst()){inc=it.getLong(0);exp=it.getLong(1)} }
        val ps=people(); val cash=accountBalances().sumOf{it.second}
        return Summary(inc,exp,cash,ps.sumOf{if(it.balance>0) it.balance else 0L},ps.sumOf{if(it.balance<0) -it.balance else 0L})
    }
    fun transactions(personId: Long? = null, limit: Int = 300): List<Tx> {
        val out= mutableListOf<Tx>()
        val where=if(personId==null) "t.is_deleted=0" else "t.is_deleted=0 AND t.person_id=?"
        val args=if(personId==null) null else arrayOf(personId.toString())
        readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id WHERE $where ORDER BY t.created_at DESC,t.id DESC LIMIT $limit",args).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }
        return out
    }
    fun cashBalanceBefore(timestamp:Long):Long = accounts().sumOf { accountBalanceBefore(it,timestamp) }
    fun transactionsBetween(start:Long,endExclusive:Long):List<Tx> {
        val out= mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id LEFT JOIN finance_accounts a ON a.name=t.account WHERE t.is_deleted=0 AND t.created_at>=? AND t.created_at<? AND t.created_at>=COALESCE(a.opening_at,0) ORDER BY t.created_at DESC,t.id DESC",arrayOf(start.toString(),endExclusive.toString())).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }
        return out
    }
    fun deleteTx(id:Long) { writableDatabase.execSQL("UPDATE transactions SET is_deleted=1 WHERE id=?",arrayOf(id)); audit("حذف نرم", "تراکنش", id, "انتقال به سطل بازیابی") }
    fun restoreTx(id:Long) { writableDatabase.execSQL("UPDATE transactions SET is_deleted=0 WHERE id=?",arrayOf(id)); audit("بازیابی", "تراکنش", id, "بازیابی از سطل") }
    fun deletedTx(): List<Tx> {
        val out= mutableListOf<Tx>(); readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id WHERE t.is_deleted=1 ORDER BY t.created_at DESC",null).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }; return out
    }
}

private fun fmt(n: Long): String = DecimalFormat("#,###").format(n)
private fun jalali(millis:Long):String {
    val cal=Calendar.getInstance().apply { timeInMillis=millis }; val gy=cal.get(Calendar.YEAR); val gm=cal.get(Calendar.MONTH)+1; val gd=cal.get(Calendar.DAY_OF_MONTH)
    val gdm=arrayOf(0,31,if(isLeap(gy))29 else 28,31,30,31,30,31,31,30,31,30,31)
    var gy2=gy-1600; var gm2=gm-1; var gd2=gd-1
    var gdn=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400
    for(i in 0 until gm2) gdn+=gdm[i+1]
    gdn+=gd2
    var jdn=gdn-79; val jnp=jdn/12053; jdn%=12053
    var jy=979+33*jnp+4*(jdn/1461); jdn%=1461
    if(jdn>=366){jy+=(jdn-1)/365; jdn=(jdn-1)%365}
    val jm=if(jdn<186) 1+(jdn/31).toInt() else 7+((jdn-186)/30).toInt()
    val jd=if(jdn<186) 1+(jdn%31).toInt() else 1+((jdn-186)%30).toInt()
    return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
}
private fun isLeap(y:Int)= (y%4==0 && y%100!=0)||y%400==0
private fun jalaliToMillis(jy:Int,jm:Int,jd:Int):Long? {
    if(jy<1200 || jy>1600 || jm !in 1..12 || jd !in 1..31) return null
    val base=Calendar.getInstance().apply { clear(); set(jy+621,Calendar.MARCH,18,0,0,0) }
    var start:Calendar?=null
    for(offset in 0..5) {
        val candidate=(base.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH,offset) }
        val label=jalali(candidate.timeInMillis)
        if(label=="%04d/01/01".format(Locale.US,jy)){start=candidate;break}
    }
    val first=start ?: return null
    val maxDay=if(jm<=6)31 else if(jm<=11)30 else if(isJalaliLeap(jy))30 else 29
    if(jd>maxDay) return null
    val dayOffset=if(jm<=6)(jm-1)*31+(jd-1) else 186+(jm-7)*30+(jd-1)
    first.add(Calendar.DAY_OF_MONTH,dayOffset)
    return first.timeInMillis
}
private fun isJalaliLeap(year:Int):Boolean {
    val a=jalaliToMillisRawStart(year) ?: return false
    val b=jalaliToMillisRawStart(year+1) ?: return false
    return (b-a)/86400000L>365
}
private fun jalaliToMillisRawStart(jy:Int):Long? {
    val base=Calendar.getInstance().apply { clear(); set(jy+621,Calendar.MARCH,18,0,0,0) }
    for(offset in 0..5) { val c=(base.clone() as Calendar).apply{add(Calendar.DAY_OF_MONTH,offset)}; if(jalali(c.timeInMillis)=="%04d/01/01".format(Locale.US,jy)) return c.timeInMillis }
    return null
}
private fun jalaliInput(millis:Long):String = jalali(millis)


class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private val requestCreateBackup = 4101
    private val requestRestoreBackup = 4102
    private lateinit var root: LinearLayout
    private val green=0xff21634a.toInt(); private val red=0xffa74636.toInt(); private val bg=0xfff4f7f4.toInt(); private val pale=0xffe8f1eb.toInt()
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); db=LedgerDb(this); showHome()}
    private fun base(title:String, back:(()->Unit)?=null){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,12,16,10);layoutDirection=View.LAYOUT_DIRECTION_RTL;setBackgroundColor(bg)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        if(back!=null) head.addView(btn("‹") { back() },LinearLayout.LayoutParams(52,-2))
        head.addView(text(title,22f,green,true),LinearLayout.LayoutParams(0,-2,1f)); root.addView(head); setContentView(root)
    }
    private fun text(s:String,size:Float=15f,color:Int=0xff26332b.toInt(),bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);if(bold)typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL;setPadding(4,7,4,7)}
    private fun btn(s:String,action:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setOnClickListener{action()}}
    private fun field(hint:String,number:Boolean=false)=EditText(this).apply{this.hint=hint;textSize=15f;setSingleLine(true);layoutDirection=View.LAYOUT_DIRECTION_RTL;if(number)inputType=InputType.TYPE_CLASS_NUMBER}
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,8,12,8);setBackgroundColor(-1)}
    private fun line(parent:LinearLayout){parent.addView(View(this).apply{setBackgroundColor(0xffe1e7e2.toInt())},LinearLayout.LayoutParams(-1,1))}
    private fun showHome(){
        base("مدیریت زندگی ۲.۰")
        val s=db.summary(); val box=card().apply{setBackgroundColor(pale)}
        box.addView(text("خلاصه امور مالی",17f,green,true)); box.addView(text("دریافت: ${fmt(s.income)} تومان     پرداخت: ${fmt(s.expense)} تومان",15f)); box.addView(text("مانده نقدی: ${fmt(s.balance)} تومان",17f,if(s.balance>=0)green else red,true)); box.addView(text("طلب از اشخاص: ${fmt(s.receivable)}   |   بدهی به اشخاص: ${fmt(s.payable)}",14f))
        root.addView(box); root.addView(text("انتخاب بخش",17f,green,true))
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; nav.addView(btn("امور مالی") { showFinance() },LinearLayout.LayoutParams(0,-2,1f)); nav.addView(btn("اشخاص و دفتر حساب") { showPeople() },LinearLayout.LayoutParams(0,-2,1f)); root.addView(nav)
        root.addView(btn("＋ ثبت دریافت / پرداخت / درآمد / هزینه") { financeEntryDialog() })
        root.addView(btn("＋ افزودن شخص") { addPersonDialog() })
        root.addView(btn("مدیریت صندوق‌ها و حساب‌ها") { showAccounts() })
        root.addView(btn("سطل بازیابی تراکنش‌ها") { showTrash() })
        root.addView(btn("پشتیبان‌گیری و بازیابی اطلاعات") { showBackup() })
        root.addView(text("آخرین تراکنش‌ها",17f,green,true)); val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; sc.addView(list); root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.transactions(null,20); if(rows.isEmpty())list.addView(text("هنوز تراکنشی ثبت نشده است.")) else rows.forEach{list.addView(txCard(it,false))}
    }
    private fun showFinance(){
        base("امور مالی و حسابداری")
        val s=db.summary(); val b=card().apply{setBackgroundColor(pale)}; b.addView(text("دریافت‌ها: ${fmt(s.income)} تومان",16f,green,true)); b.addView(text("پرداخت‌ها: ${fmt(s.expense)} تومان",16f,red,true)); b.addView(text("مانده نقدی: ${fmt(s.balance)} تومان",17f,green,true)); root.addView(b)
        root.addView(btn("＋ ثبت دریافت وجه") { financeEntryDialog("دریافت وجه") }); root.addView(btn("＋ ثبت پرداخت وجه") { financeEntryDialog("پرداخت وجه") }); root.addView(btn("＋ ثبت درآمد مستقل") { financeEntryDialog("درآمد") }); root.addView(btn("＋ ثبت هزینه مستقل") { financeEntryDialog("هزینه") }); root.addView(btn("مدیریت صندوق‌ها و حساب‌ها") { showAccounts() }); root.addView(btn("گزارش بازه‌ای روزانه / ماهانه / سالانه") { reportDialog() }); root.addView(btn("بازگشت به خانه") { showHome() })
        root.addView(text("دفتر گردش نقدی",17f,green,true)); val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.transactions().filter{it.kind in listOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")}; if(rows.isEmpty())list.addView(text("گردش نقدی خالی است.")) else rows.forEach{list.addView(txCard(it,true))}
    }
    private fun showPeople(q:String=""){
        base("اشخاص و دفتر حساب")
        root.addView(btn("＋ افزودن شخص جدید") { addPersonDialog() }); root.addView(btn("پرونده‌های بایگانی‌شده") { showArchivedPeople() }); val search=field("جست‌وجوی نام یا شماره تماس");search.setText(q);root.addView(search);root.addView(btn("جست‌وجو") { showPeople(search.text.toString()) })
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f)); val people=db.people(q)
        if(people.isEmpty())list.addView(text("شخصی ثبت نشده است.")) else people.forEach{p->val c=card();c.addView(text(p.name,18f,green,true));c.addView(text(if(p.balance>0)"طلب شما از این شخص: ${fmt(p.balance)} تومان" else if(p.balance<0)"بدهی شما به این شخص: ${fmt(-p.balance)} تومان" else "حساب تسویه است",15f,if(p.balance<0)red else green,true));c.addView(text("طلب ثبت‌شده: ${fmt(p.receivable)}  |  بدهی ثبت‌شده: ${fmt(p.payable)}",13f));if(p.phone.isNotBlank())c.addView(text(p.phone,13f));c.addView(btn("پرونده و گردش حساب") { personPage(p.id) });list.addView(c);line(list)}
        root.addView(btn("بازگشت به خانه") { showHome() })
    }
    private fun addPersonDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val n=field("نام و نام خانوادگی");val ph=field("شماره تماس");val rel=field("نوع ارتباط: مشتری، فروشنده، دوست...");val ad=field("نشانی");val note=field("توضیحات")
        listOf(n,ph,rel,ad,note).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("افزودن شخص") .setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->if(n.text.toString().trim().isEmpty())toast("نام را وارد کنید")else{db.addPerson(n.text.toString().trim(),ph.text.toString().trim(),ad.text.toString().trim(),rel.text.toString().trim(),note.text.toString().trim());showPeople()}}.show()
    }
    private fun personPage(id:Long){
        val p=db.people().firstOrNull{it.id==id}?:return showPeople();base(p.name){showPeople()}
        val c=card().apply{setBackgroundColor(pale)};c.addView(text("طلب از شخص: ${fmt(p.receivable)} تومان",15f,green,true));c.addView(text("بدهی به شخص: ${fmt(p.payable)} تومان",15f,red,true));c.addView(text(if(p.balance>0)"مانده خالص: ${fmt(p.balance)} تومان طلب" else if(p.balance<0)"مانده خالص: ${fmt(-p.balance)} تومان بدهی" else "مانده خالص: تسویه",17f,green,true));root.addView(c)
        root.addView(btn("＋ ثبت عملیات حساب این شخص") { personEntryDialog(p) });root.addView(btn("ویرایش مشخصات شخص") { editPersonInfo(p) });root.addView(btn("بایگانی پرونده شخص") { archivePersonConfirm(p) });root.addView(text("گردش حساب",17f,green,true))
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));val rows=db.transactions(id)
        if(rows.isEmpty())list.addView(text("گردش حساب خالی است.")) else rows.forEach{list.addView(txCard(it,true))}
    }
    private fun archivePersonConfirm(p:Person) {
        val count=db.personTransactionCount(p.id)
        val msg=if(count>0) "این پرونده $count تراکنش دارد. با بایگانی، فقط از فهرست فعال خارج می‌شود و تمام گردش حساب و سوابق مالی حفظ می‌شوند. هر زمان بخواهید قابل بازیابی است." else "این پرونده از فهرست فعال خارج می‌شود و هر زمان بخواهید قابل بازیابی است."
        AlertDialog.Builder(this).setTitle("بایگانی پرونده ${p.name}").setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("بایگانی") { _,_-> db.archivePerson(p.id); showPeople() }.show()
    }
    private fun showArchivedPeople() {
        base("پرونده‌های بایگانی‌شده") { showPeople() }
        val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; sc.addView(list); root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.deletedPeople()
        if(rows.isEmpty()) list.addView(text("پرونده بایگانی‌شده‌ای وجود ندارد.")) else rows.forEach { p ->
            val c=card(); c.addView(text(p.name,17f,green,true)); c.addView(text("تراکنش‌های ثبت‌شده: ${db.personTransactionCount(p.id)}"));
            c.addView(text(if(p.balance>0) "مانده طلب: ${fmt(p.balance)} تومان" else if(p.balance<0) "مانده بدهی: ${fmt(-p.balance)} تومان" else "مانده خالص: صفر"))
            if(p.phone.isNotBlank()) c.addView(text(p.phone,13f))
            c.addView(btn("بازیابی پرونده") { AlertDialog.Builder(this).setTitle("بازیابی ${p.name}؟").setMessage("پرونده دوباره در فهرست اشخاص فعال نمایش داده می‌شود و سوابق قبلی آن حفظ خواهد شد.").setNegativeButton("انصراف",null).setPositiveButton("بازیابی") { _,_-> db.restorePerson(p.id); showArchivedPeople() }.show() })
            list.addView(c); line(list)
        }
        root.addView(btn("بازگشت به اشخاص") { showPeople() })
    }
    private fun editPersonInfo(p:Person){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val n=field("نام",false).apply{setText(p.name)};val ph=field("شماره تماس").apply{setText(p.phone)};val rel=field("نوع ارتباط").apply{setText(p.relation)};val ad=field("نشانی").apply{setText(p.address)};val note=field("توضیحات").apply{setText(p.notes)};listOf(n,ph,rel,ad,note).forEach{box.addView(it)}
        AlertDialog.Builder(this).setTitle("ویرایش شخص").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->db.writableDatabase.execSQL("UPDATE people SET name=?,phone=?,relation=?,address=?,notes=? WHERE id=?",arrayOf(n.text.toString(),ph.text.toString(),rel.text.toString(),ad.text.toString(),note.text.toString(),p.id));db.writableDatabase.execSQL("INSERT INTO audit_log(action,target,target_id,details,created_at) VALUES(?,?,?,?,?)",arrayOf("ویرایش","شخص",p.id,n.text.toString(),System.currentTimeMillis()));personPage(p.id)}.show()
    }
    private fun personEntryDialog(p:Person){
        val types=arrayOf("طلب","بدهی","دریافت وجه","پرداخت وجه","دریافت کالا","تحویل کالا","فروش نسیه","خرید نسیه")
        entryDialog("ثبت عملیات برای ${p.name}",types,p.id)
    }
    private fun financeEntryDialog(preselect:String?=null){
        val types=arrayOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")
        entryDialog("ثبت تراکنش مالی",types,null,preselect)
    }
    private fun dateFields(parent:LinearLayout, initial:Long, label:String="تاریخ شمسی"):Triple<EditText,EditText,EditText> {
        val parts=jalali(initial).split("/"); val y=field("سال شمسی",true).apply{setText(parts[0])}; val m=field("ماه",true).apply{setText(parts[1])}; val d=field("روز",true).apply{setText(parts[2])}
        parent.addView(text("$label (سال / ماه / روز)")); val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; row.addView(y,LinearLayout.LayoutParams(0,-2,1.3f));row.addView(m,LinearLayout.LayoutParams(0,-2,1f));row.addView(d,LinearLayout.LayoutParams(0,-2,1f));parent.addView(row)
        return Triple(y,m,d)
    }
    private fun readDate(fields:Triple<EditText,EditText,EditText>):Long? = jalaliToMillis(fields.first.text.toString().toIntOrNull()?:-1,fields.second.text.toString().toIntOrNull()?:-1,fields.third.text.toString().toIntOrNull()?:-1)
    private fun entryDialog(title:String,types:Array<String>,personId:Long?,preselect:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val sp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types);if(preselect!=null)setSelection(types.indexOf(preselect).coerceAtLeast(0))};val amount=field("مبلغ به تومان",true);val note=field("شرح / توضیحات");val account=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,db.accounts())};val date=dateFields(box,System.currentTimeMillis());box.addView(text("نوع عملیات"));box.addView(sp);box.addView(amount);box.addView(note);box.addView(text("صندوق یا حساب بانکی"));box.addView(account)
        AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("انصراف",null).setPositiveButton("ثبت تراکنش"){_,_->val a=amount.text.toString().replace(",","").trim().toLongOrNull();val whenAt=readDate(date);if(a==null||a<=0){toast("مبلغ معتبر وارد کنید");return@setPositiveButton};if(whenAt==null){toast("تاریخ شمسی معتبر وارد کنید");return@setPositiveButton};db.addTx(personId,types[sp.selectedItemPosition],a,note.text.toString().trim(),account.selectedItem?.toString() ?: "نقدی",whenAt);if(personId==null)showFinance()else personPage(personId)}.show()
    }
    private fun editTxDialog(t:Tx) {
        val types=if(t.personId==null) arrayOf("دریافت وجه","پرداخت وجه","درآمد","هزینه") else arrayOf("طلب","بدهی","دریافت وجه","پرداخت وجه","دریافت کالا","تحویل کالا","فروش نسیه","خرید نسیه")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val kind=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types);setSelection(types.indexOf(t.kind).coerceAtLeast(0))}
        val amount=field("مبلغ به تومان",true).apply{setText(t.amount.toString())};val note=field("شرح / توضیحات").apply{setText(t.note)};val date=dateFields(box,t.createdAt)
        val account=Spinner(this).apply{val items=db.accounts();adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);setSelection(items.indexOf(t.account).coerceAtLeast(0))}
        box.addView(text("نوع عملیات"));box.addView(kind);box.addView(amount);box.addView(note);box.addView(text("صندوق یا حساب"));box.addView(account)
        AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره تغییرات"){_,_->val a=amount.text.toString().replace(",","").trim().toLongOrNull();if(a==null||a<=0){toast("مبلغ معتبر وارد کنید");return@setPositiveButton};val whenAt=readDate(date);if(whenAt==null){toast("تاریخ شمسی معتبر وارد کنید");return@setPositiveButton};db.updateTx(t.id,types[kind.selectedItemPosition],a,note.text.toString().trim(),account.selectedItem?.toString() ?: "نقدی",whenAt);if(t.personId==null)showFinance() else personPage(t.personId)}.show()
    }
    private fun reportDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val today=System.currentTimeMillis();val from=dateFields(box,today,"از تاریخ");val to=dateFields(box,today,"تا تاریخ")
        AlertDialog.Builder(this).setTitle("گزارش بازه‌ای") .setView(box).setNegativeButton("انصراف",null).setPositiveButton("نمایش گزارش"){_,_->
            val start=readDate(from);val end=readDate(to)
            if(start==null||end==null||end<start){toast("بازه تاریخ معتبر نیست");return@setPositiveButton}
            val endExclusive=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis
            showReport(start,endExclusive)
        }.show()
    }
    private fun showReport(start:Long,endExclusive:Long){
        base("گزارش مالی بازه انتخابی"){showFinance()}
        val rows=db.transactionsBetween(start,endExclusive).filter{it.kind in listOf("دریافت وجه","درآمد","پرداخت وجه","هزینه")}
        var income=0L;var expense=0L
        rows.forEach{if(it.kind in listOf("دریافت وجه","درآمد"))income+=it.amount else if(it.kind in listOf("پرداخت وجه","هزینه"))expense+=it.amount}
        val opening=db.cashBalanceBefore(start); val closing=opening+income-expense
        val box=card().apply{setBackgroundColor(pale)}
        box.addView(text("از ${jalali(start)} تا ${jalali(endExclusive-1)}",14f,green,true))
        box.addView(text("مانده اول دوره: ${fmt(opening)} تومان",15f,green,true))
        box.addView(text("تعداد تراکنش‌ها: ${rows.size}",14f))
        box.addView(text("مجموع دریافت و درآمد: ${fmt(income)} تومان",15f,green,true))
        box.addView(text("مجموع پرداخت و هزینه: ${fmt(expense)} تومان",15f,red,true))
        box.addView(text("خالص گردش نقدی این بازه: ${fmt(income-expense)} تومان",15f,if(income>=expense)green else red,true))
        box.addView(text("مانده پایان دوره: ${fmt(closing)} تومان",17f,if(closing>=0)green else red,true));root.addView(box)
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        if(rows.isEmpty())list.addView(text("در این بازه تراکنشی ثبت نشده است.")) else rows.forEach{list.addView(txCard(it,true));line(list)}
    }

    private fun showAccounts() {
        base("صندوق‌ها و حساب‌ها"){showHome()}
        root.addView(text("مانده هر حساب بر اساس دریافت‌ها و پرداخت‌های ثبت‌شده",13f))
        db.accountBalances().forEach { item -> val c=card();c.addView(text(item.first,17f,green,true));c.addView(text("مانده: ${fmt(item.second)} تومان",16f,if(item.second>=0)green else red,true));c.addView(btn("ثبت / اصلاح مانده اول دوره") { openingBalanceDialog(item.first) });c.addView(btn("گزارش این حساب") { accountReportDialog(item.first) });root.addView(c);line(root) }
        root.addView(btn("⇄ انتقال وجه بین دو حساب") { transferDialog() })
        root.addView(btn("＋ افزودن صندوق یا حساب") {
            val input=field("نام حساب؛ مثلاً بانک ملی یا صندوق دوم")
            AlertDialog.Builder(this).setTitle("افزودن حساب") .setView(input).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->if(db.addAccount(input.text.toString())) showAccounts() else toast("نام خالی یا تکراری است")}.show()
        })
        root.addView(btn("بازگشت به خانه"){showHome()})
    }
    private fun openingBalanceDialog(account:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val existing=db.accountOpening(account);val amount=field("مانده اول دوره به تومان",true).apply{setText(existing.first.toString())}; val date=dateFields(box,if(existing.second>0)existing.second else System.currentTimeMillis(),"تاریخ مبنای مانده")
        box.addView(text("مبلغ مثبت برای موجودی و مبلغ منفی برای کسری/بدهی وارد شود. تغییر تاریخ مبنا، محاسبه گردش‌های قدیمی‌تر را تغییر می‌دهد."));box.addView(amount)
        AlertDialog.Builder(this).setTitle("مانده اول دوره • $account").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->val a=amount.text.toString().replace(",","").trim().toLongOrNull();val at=readDate(date);if(a==null||at==null){toast("مبلغ یا تاریخ معتبر نیست");return@setPositiveButton};db.setOpeningBalance(account,a,at);showAccounts()}.show()
    }
    private fun transferDialog() {
        val accounts=db.accounts();if(accounts.size<2){toast("برای انتقال، ابتدا حداقل دو حساب بسازید");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val from=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts)}
        val to=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts);setSelection(1)}
        val amount=field("مبلغ انتقال به تومان",true);val note=field("شرح انتقال");val date=dateFields(box,System.currentTimeMillis())
        box.addView(text("از حساب"));box.addView(from);box.addView(text("به حساب"));box.addView(to);box.addView(amount);box.addView(note)
        AlertDialog.Builder(this).setTitle("انتقال وجه بین حساب‌ها").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال"){_,_->val a=amount.text.toString().replace(",","").trim().toLongOrNull();val at=readDate(date);if(from.selectedItemPosition==to.selectedItemPosition){toast("حساب مبدأ و مقصد باید متفاوت باشند");return@setPositiveButton};if(a==null||a<=0||at==null){toast("مبلغ یا تاریخ معتبر نیست");return@setPositiveButton};try{db.transfer(from.selectedItem.toString(),to.selectedItem.toString(),a,note.text.toString().trim(),at);showAccounts()}catch(e:Exception){toast(e.message?:"ثبت انتقال ناموفق بود")}}.show()
    }
    private fun accountReportDialog(account:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val today=System.currentTimeMillis();val from=dateFields(box,today,"از تاریخ");val to=dateFields(box,today,"تا تاریخ")
        AlertDialog.Builder(this).setTitle("گزارش حساب • $account").setView(box).setNegativeButton("انصراف",null).setPositiveButton("نمایش"){_,_->val start=readDate(from);val end=readDate(to);if(start==null||end==null||end<start){toast("بازه تاریخ معتبر نیست");return@setPositiveButton};val endX=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis;showAccountReport(account,start,endX)}.show()
    }
    private fun showAccountReport(account:String,start:Long,endExclusive:Long) {
        base("گزارش حساب • $account"){showAccounts()}
        val opening=db.accountBalanceBefore(account,start);val rows=db.transactionsBetween(start,endExclusive).filter{it.account==account && it.kind in listOf("دریافت وجه","درآمد","پرداخت وجه","هزینه")};var income=0L;var expense=0L
        rows.forEach{if(it.kind in listOf("دریافت وجه","درآمد"))income+=it.amount else if(it.kind in listOf("پرداخت وجه","هزینه"))expense+=it.amount}
        val transfers=db.accountTransfers(account,start,endExclusive);val transferTotals=db.accountTransferTotals(account,start,endExclusive);val transferIn=transferTotals.first;val transferOut=transferTotals.second
        val box=card().apply{setBackgroundColor(pale)};box.addView(text("از ${jalali(start)} تا ${jalali(endExclusive-1)}",14f,green,true));box.addView(text("مانده اول دوره: ${fmt(opening)} تومان",15f,green,true));box.addView(text("دریافت و درآمد: ${fmt(income)} تومان"));box.addView(text("پرداخت و هزینه: ${fmt(expense)} تومان"));box.addView(text("واریز از حساب‌های دیگر: ${fmt(transferIn)} تومان"));box.addView(text("انتقال به حساب‌های دیگر: ${fmt(transferOut)} تومان"));val closing=opening+income-expense+transferIn-transferOut;box.addView(text("مانده پایان دوره: ${fmt(closing)} تومان",17f,if(closing>=0)green else red,true));root.addView(box)
        root.addView(text("تراکنش‌های نقدی حساب (${rows.size})",16f,green,true));val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));if(rows.isEmpty())list.addView(text("تراکنش نقدی در این بازه وجود ندارد."))else rows.forEach{list.addView(txCard(it,true));line(list)}
        root.addView(text("انتقال‌های بین حسابی",16f,green,true));if(transfers.isEmpty())root.addView(text("انتقالی در این بازه ثبت نشده است."))else transfers.forEach{root.addView(text(it,13f))}
    }

    private fun txCard(t:Tx,allowDelete:Boolean):LinearLayout{
        val c=card();val color=when(t.kind){"دریافت وجه","درآمد","طلب","پرداخت وجه","تحویل کالا","فروش نسیه"->green;else->red};c.addView(text("${t.kind}  •  ${fmt(t.amount)} تومان",16f,color,true));c.addView(text("${t.personName}  |  ${jalali(t.createdAt)}  |  ${t.account}",12f,0xff68736b.toInt()));if(t.note.isNotBlank())c.addView(text(t.note,14f));if(allowDelete)c.addView(btn("ویرایش تراکنش") { editTxDialog(t) });if(allowDelete)c.addView(btn("انتقال به سطل بازیابی") { AlertDialog.Builder(this).setMessage("این تراکنش به سطل بازیابی منتقل شود؟").setNegativeButton("انصراف",null).setPositiveButton("انتقال"){_,_->db.deleteTx(t.id);if(t.personId==null)showFinance()else personPage(t.personId)}.show() });return c
    }
    private fun showTrash(){base("سطل بازیابی"){showHome()};val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));val rows=db.deletedTx();if(rows.isEmpty())list.addView(text("سطل بازیابی خالی است.")) else rows.forEach{t->val c=card();c.addView(text("${t.kind} - ${fmt(t.amount)} تومان",15f));c.addView(text(t.note));c.addView(btn("بازیابی تراکنش") { db.restoreTx(t.id);showTrash() });list.addView(c);line(list)}}

    private fun showBackup(){
        base("پشتیبان‌گیری و بازیابی اطلاعات"){showHome()}
        root.addView(text("برای محافظت از اطلاعات مالی، به‌طور منظم یک نسخه پشتیبان در محل امن ذخیره کنید.",14f))
        root.addView(btn("ساخت فایل پشتیبان") {
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type="application/octet-stream"
                putExtra(Intent.EXTRA_TITLE,"Modiriat_Zendegi_Backup_${System.currentTimeMillis()}.sqlite")
            }
            startActivityForResult(intent,requestCreateBackup)
        })
        root.addView(btn("بازیابی از فایل پشتیبان") {
            AlertDialog.Builder(this).setTitle("هشدار بازیابی")
                .setMessage("بازیابی، اطلاعات فعلی برنامه را با اطلاعات فایل پشتیبان جایگزین می‌کند. قبل از ادامه، از اطلاعات فعلی هم پشتیبان بگیرید. آیا فایل پشتیبان را انتخاب می‌کنید؟")
                .setNegativeButton("انصراف",null).setPositiveButton("انتخاب فایل") { _,_->
                    val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="*/*" }
                    startActivityForResult(intent,requestRestoreBackup)
                }.show()
        })
        root.addView(text("نکات مهم",16f,green,true))
        root.addView(text("• فایل پشتیبان شامل اطلاعات پایگاه داده و سوابق ثبت‌شده است.\n• فایل به‌صورت معمولی و بدون رمزگذاری صادر می‌شود؛ آن را در اختیار دیگران قرار ندهید.\n• هنگام بازیابی، داده‌های فعلی جایگزین می‌شوند.\n• فایل پشتیبان را در حافظه‌ای جدا از گوشی، مانند رایانه یا فضای امن دیگر، نگهداری کنید.",13f))
        root.addView(btn("بازگشت به خانه"){showHome()})
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK) return
        val uri=data?.data ?: return
        when(requestCode){
            requestCreateBackup -> exportBackup(uri)
            requestRestoreBackup -> {
                AlertDialog.Builder(this).setTitle("تأیید نهایی بازیابی")
                    .setMessage("اطلاعات فعلی جایگزین می‌شود. یک نسخه اضطراری از پایگاه داده فعلی در حافظه داخلی برنامه نگهداری خواهد شد. ادامه می‌دهید؟")
                    .setNegativeButton("انصراف",null).setPositiveButton("بله، بازیابی شود"){_,_->restoreBackup(uri)}.show()
            }
        }
    }

    private fun exportBackup(uri:Uri){
        try{
            db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use { }
            db.close()
            val source=getDatabasePath("ledger.db")
            if(!source.exists()) throw IllegalStateException("پایگاه داده پیدا نشد")
            contentResolver.openOutputStream(uri,"w").use { output ->
                if(output==null) throw IllegalStateException("فایل مقصد باز نشد")
                FileInputStream(source).use { input -> input.copyTo(output) }
                output.flush()
            }
            db=LedgerDb(this)
            toast("فایل پشتیبان با موفقیت ساخته شد")
            showBackup()
        }catch(e:Exception){
            db=LedgerDb(this)
            toast("ساخت پشتیبان ناموفق بود: ${e.message ?: "خطای ناشناخته"}")
        }
    }

    private fun restoreBackup(uri:Uri){
        val temp=File(cacheDir,"restore_check_${System.currentTimeMillis()}.sqlite")
        try{
            contentResolver.openInputStream(uri).use { input ->
                if(input==null) throw IllegalStateException("فایل انتخاب‌شده قابل خواندن نیست")
                FileOutputStream(temp).use { output -> input.copyTo(output) }
            }
            if(temp.length()<1024L) throw IllegalArgumentException("فایل بسیار کوچک یا نامعتبر است")
            val check=SQLiteDatabase.openDatabase(temp.absolutePath,null,SQLiteDatabase.OPEN_READONLY)
            try{
                var integrity=""
                check.rawQuery("PRAGMA integrity_check",null).use { c -> if(c.moveToFirst()) integrity=c.getString(0) }
                if(integrity!="ok") throw IllegalArgumentException("سلامت پایگاه داده تأیید نشد")
                val found=mutableSetOf<String>()
                check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'",null).use { c -> while(c.moveToNext()) found.add(c.getString(0)) }
                val version=check.version
                if(version>4) throw IllegalArgumentException("این فایل با نسخه جدیدتری از برنامه ساخته شده است")
                if(version<3) throw IllegalArgumentException("این فایل قدیمی است؛ ابتدا باید با نسخه سازگار تبدیل شود")
                val required=setOf("people","transactions","finance_accounts","audit_log")
                if(!found.containsAll(required) || (version>=4 && !found.contains("account_transfers"))) throw IllegalArgumentException("این فایل پشتیبان با نسخه فعلی برنامه سازگار نیست")
            }finally{check.close()}

            db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use { }
            db.close()
            val live=getDatabasePath("ledger.db")
            val stamp=System.currentTimeMillis()
            val candidate=File(live.parentFile,"ledger_restore_candidate_$stamp.sqlite")
            FileInputStream(temp).use { input -> FileOutputStream(candidate).use { output -> input.copyTo(output) } }
            if(live.exists()){
                val safety=File(filesDir,"ledger_before_restore_$stamp.sqlite")
                FileInputStream(live).use { input -> FileOutputStream(safety).use { output -> input.copyTo(output) } }
            }
            File(live.path+"-wal").delete(); File(live.path+"-shm").delete()
            val displaced=File(live.parentFile,"ledger_displaced_$stamp.sqlite")
            if(live.exists() && !live.renameTo(displaced)) throw IllegalStateException("امکان آماده‌سازی پایگاه فعلی وجود ندارد")
            if(!candidate.renameTo(live)){
                if(displaced.exists()) displaced.renameTo(live)
                throw IllegalStateException("جایگزینی فایل پایگاه داده انجام نشد")
            }
            displaced.delete()
            db=LedgerDb(this)
            db.readableDatabase
            toast("بازیابی با موفقیت انجام شد")
            showHome()
        }catch(e:Exception){
            try{db.close()}catch(_:Exception){}
            db=LedgerDb(this)
            toast("بازیابی انجام نشد: ${e.message ?: "فایل نامعتبر است"}")
            showBackup()
        }finally{temp.delete()}
    }

    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    @Deprecated("Deprecated in Android") override fun onBackPressed(){showHome()}
}
