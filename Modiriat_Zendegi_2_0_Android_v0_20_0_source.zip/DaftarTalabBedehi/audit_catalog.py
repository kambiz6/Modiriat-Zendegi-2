#!/usr/bin/env python3
"""Static integrity audit for the Management Life 2.0 Kotlin catalog.
Run from the project root: python3 audit_catalog.py
No Android SDK or third-party packages are required.
"""
from pathlib import Path
import re, sys, json

ROOT = Path(__file__).resolve().parent
CATALOG = ROOT / 'app/src/main/java/ir/kambiz/daftar/ProgramCatalog.kt'
MAIN = ROOT / 'app/src/main/java/ir/kambiz/daftar/MainActivity.kt'
errors, warnings = [], []
source = CATALOG.read_text(encoding='utf-8')
main = MAIN.read_text(encoding='utf-8')
sections = [(int(n), title, icon) for n, title, icon in re.findall(
    r'ProgramCatalogSection\((\d+),\s*"([^"]+)"\s*,\s*"([^"]+)"', source)]
feature_ids = [int(x) for x in re.findall(r'^\s*(\d+)\s+to\s+"', source, re.M)]

active = [n for n, _, _ in sections if n not in (22, 104)]
if len(active) != 102: errors.append(f'Expected 102 active sections, found {len(active)}')
if set(active) != (set(range(1, 104)) - {22}): errors.append('Active section numbers are not exactly 1..103 excluding 22')
if any(n == 22 for n, _, _ in sections): errors.append('Deleted section 22 is still present')
if not any(n == 104 and title == 'منتخب‌ها' for n, title, _ in sections): errors.append('Favorites container 104 is missing')
if any(not title.strip() or not icon.strip() for _, title, icon in sections): errors.append('A section has an empty title or icon')
if len(feature_ids) != len(set(feature_ids)): errors.append('Duplicate feature IDs found')
missing = sorted(set(range(1, 526)) - set(feature_ids))
if missing: errors.append(f'Missing base IDs: {missing[:20]}')
extra = [n for n in feature_ids if n >= 10000]
if len(extra) != 619: errors.append(f'Expected 619 supplementary IDs, found {len(extra)}')
if len(feature_ids) != 1144: errors.append(f'Expected 1144 catalog entries, found {len(feature_ids)}')
for token in ['fun setFeatureFavorite', 'fun moveCatalogFeature', 'fun editCatalogSection', 'fun editCatalogFeature', 'fun catalogSectionsForUi']:
    if token not in main: errors.append(f'Missing catalog function: {token}')
if 'ProgramCatalogSection(104,"منتخب‌ها"' not in main: errors.append('UI favorites section 104 is not assembled')
if 'catalog_customization' not in main: errors.append('Catalog customization storage is missing')

result = {
    'catalog_sections_including_internal_container': len(sections),
    'active_sections': len(active),
    'deleted_section_22_present': any(n == 22 for n, _, _ in sections),
    'favorites_container_104_present': any(n == 104 for n, _, _ in sections),
    'catalog_feature_rows': len(feature_ids),
    'unique_feature_ids': len(set(feature_ids)),
    'base_ids_1_to_525_complete': not missing,
    'supplementary_ids_count': len(extra),
    'errors': errors,
    'warnings': warnings,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(1 if errors else 0)
