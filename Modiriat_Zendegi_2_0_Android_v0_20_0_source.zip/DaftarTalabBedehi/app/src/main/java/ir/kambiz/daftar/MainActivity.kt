package ir.kambiz.daftar

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfDocument
import android.provider.ContactsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import java.text.DecimalFormat
import java.math.BigInteger
import java.util.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import android.util.Base64
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import android.database.DatabaseUtils
import org.json.JSONObject
import org.json.JSONArray
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class Person(val id: Long, val name: String, val phone: String, val address: String, val relation: String, val notes: String, val photoData: String, val balance: Long, val receivable: Long, val payable: Long, val secondPhone:String="", val nationalId:String="", val birthDate:String="", val job:String="", val workplace:String="", val source:String="", val rating:String="", val tags:String="", val location:String="", val fatherName:String="", val landline:String="", val email:String="", val groupName:String="سایر افراد و طرف‌حساب‌ها", val roles:String="")
data class Tx(val id: Long, val personId: Long?, val personName: String, val kind: String, val amount: Long, val note: String, val createdAt: Long, val account: String)
data class Summary(val income: Long, val expense: Long, val balance: Long, val receivable: Long, val payable: Long)
data class PersonOpening(val id: Long, val personId: Long, val amount: Long, val balanceType: String, val baseDate: Long, val description: String, val createdAt: Long)

class LedgerDb(ctx: Context) : SQLiteOpenHelper(ctx, "ledger.db", null, 11) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE people(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', address TEXT DEFAULT '', relation TEXT DEFAULT '', notes TEXT DEFAULT '', photo_data TEXT DEFAULT '', is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, display_mode INTEGER NOT NULL DEFAULT 4)")
        createTransactions(db)
        db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target TEXT NOT NULL, target_id INTEGER, details TEXT DEFAULT '', created_at INTEGER NOT NULL)")
        createAccounts(db)
        createTransfers(db)
        createPersonOpeningBalances(db)
        createPeopleExtras(db)
        createFinanceExtras(db)
        createPersonConnections(db)
        db.execSQL("CREATE INDEX idx_tx_date ON transactions(created_at)")
        db.execSQL("CREATE INDEX idx_tx_person ON transactions(person_id)")
    }
    private fun createTransactions(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NULL, kind TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), note TEXT DEFAULT '', created_at INTEGER NOT NULL, account TEXT DEFAULT 'نقدی', is_deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(person_id) REFERENCES people(id))")
    }
    private fun createAccounts(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS finance_accounts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, opening_balance INTEGER NOT NULL DEFAULT 0, opening_at INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("INSERT OR IGNORE INTO finance_accounts(name,created_at) VALUES('نقدی',?)", arrayOf(System.currentTimeMillis()))
    }
    private fun createTransfers(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS account_transfers(id INTEGER PRIMARY KEY AUTOINCREMENT, from_account TEXT NOT NULL, to_account TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), note TEXT DEFAULT '', created_at INTEGER NOT NULL, is_deleted INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_transfer_date ON account_transfers(created_at)")
    }
    private fun createPersonOpeningBalances(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS person_opening_balances(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, amount INTEGER NOT NULL CHECK(amount>=0), balance_type TEXT NOT NULL CHECK(balance_type IN ('طلب','بدهی')), base_date INTEGER NOT NULL, description TEXT DEFAULT '', is_active INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_person_opening_active ON person_opening_balances(person_id) WHERE is_active=1")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_opening_history ON person_opening_balances(person_id,created_at)")
    }
    private fun createPeopleExtras(db:SQLiteDatabase) {
        val columns=mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(people)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
        val additions=linkedMapOf("second_phone" to "TEXT DEFAULT ''", "national_id" to "TEXT DEFAULT ''", "birth_date" to "TEXT DEFAULT ''", "job" to "TEXT DEFAULT ''", "workplace" to "TEXT DEFAULT ''", "source" to "TEXT DEFAULT ''", "credit_rating" to "TEXT DEFAULT ''", "tags" to "TEXT DEFAULT ''", "location" to "TEXT DEFAULT ''", "father_name" to "TEXT DEFAULT ''", "landline" to "TEXT DEFAULT ''", "email" to "TEXT DEFAULT ''", "group_name" to "TEXT DEFAULT 'سایر افراد و طرف‌حساب‌ها'", "roles" to "TEXT DEFAULT ''")
        additions.forEach { (name,type) -> if(!columns.contains(name)) db.execSQL("ALTER TABLE people ADD COLUMN $name $type") }
        db.execSQL("CREATE TABLE IF NOT EXISTS person_documents(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, title TEXT NOT NULL, mime_type TEXT DEFAULT 'image/jpeg', data TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE TABLE IF NOT EXISTS person_reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, title TEXT NOT NULL, note TEXT DEFAULT '', remind_at INTEGER NOT NULL, is_done INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_docs ON person_documents(person_id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_reminders ON person_reminders(remind_at,is_done)")
    }
    private fun createFinanceExtras(db: SQLiteDatabase) {
        val accountColumns=mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(finance_accounts)",null).use { c -> while(c.moveToNext()) accountColumns.add(c.getString(1)) }
        val accountAdditions=linkedMapOf("bank_name" to "TEXT DEFAULT ''", "account_type" to "TEXT DEFAULT 'صندوق'", "account_number" to "TEXT DEFAULT ''", "card_number" to "TEXT DEFAULT ''", "iban" to "TEXT DEFAULT ''", "owner_name" to "TEXT DEFAULT ''", "owner_person_id" to "INTEGER", "is_active" to "INTEGER NOT NULL DEFAULT 1", "notes" to "TEXT DEFAULT ''")
        accountAdditions.forEach { (name,type) -> if(!accountColumns.contains(name)) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN $name $type") }
        db.execSQL("CREATE TABLE IF NOT EXISTS tx_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT, tx_id INTEGER NOT NULL, method TEXT NOT NULL, amount INTEGER NOT NULL CHECK(amount>0), reference TEXT DEFAULT '', details TEXT DEFAULT '', created_at INTEGER NOT NULL, FOREIGN KEY(tx_id) REFERENCES transactions(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_settlement_tx ON tx_settlements(tx_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS tx_documents(id INTEGER PRIMARY KEY AUTOINCREMENT, tx_id INTEGER NOT NULL, title TEXT NOT NULL, mime_type TEXT DEFAULT 'image/jpeg', data TEXT NOT NULL, created_at INTEGER NOT NULL, FOREIGN KEY(tx_id) REFERENCES transactions(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_documents ON tx_documents(tx_id)")
        db.execSQL("CREATE TABLE IF NOT EXISTS financial_instruments(id INTEGER PRIMARY KEY AUTOINCREMENT, tx_id INTEGER, person_id INTEGER, instrument_type TEXT NOT NULL, number TEXT DEFAULT '', bank TEXT DEFAULT '', issuer TEXT DEFAULT '', amount INTEGER NOT NULL CHECK(amount>0), issued_at INTEGER NOT NULL, due_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'در انتظار', notes TEXT DEFAULT '', is_deleted INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, FOREIGN KEY(tx_id) REFERENCES transactions(id), FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_instrument_due ON financial_instruments(due_at,status,is_deleted)")
        db.execSQL("CREATE TABLE IF NOT EXISTS installment_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, title TEXT NOT NULL, total_amount INTEGER NOT NULL CHECK(total_amount>0), installment_amount INTEGER NOT NULL CHECK(installment_amount>0), interval_days INTEGER NOT NULL DEFAULT 30, start_at INTEGER NOT NULL, next_due INTEGER NOT NULL, paid_amount INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'فعال', notes TEXT DEFAULT '', created_at INTEGER NOT NULL, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_installment_due ON installment_plans(next_due,status)")
        db.execSQL("CREATE TABLE IF NOT EXISTS account_reconciliations(id INTEGER PRIMARY KEY AUTOINCREMENT, account TEXT NOT NULL, from_at INTEGER NOT NULL, to_at INTEGER NOT NULL, book_balance INTEGER NOT NULL, statement_balance INTEGER NOT NULL, difference INTEGER NOT NULL, status TEXT NOT NULL, notes TEXT DEFAULT '', created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS account_opening_history(id INTEGER PRIMARY KEY AUTOINCREMENT, account TEXT NOT NULL, old_balance INTEGER NOT NULL, old_at INTEGER NOT NULL, new_balance INTEGER NOT NULL, new_at INTEGER NOT NULL, reason TEXT DEFAULT '', changed_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE people ADD COLUMN address TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN relation TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN notes TEXT DEFAULT ''")
            db.execSQL("ALTER TABLE people ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE people ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0")
            createTransactions(db)
            db.execSQL("INSERT INTO transactions(person_id,kind,amount,note,created_at) SELECT e.person_id,e.kind,e.amount,e.note,e.created_at FROM entries e")
            db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, target TEXT NOT NULL, target_id INTEGER, details TEXT DEFAULT '', created_at INTEGER NOT NULL)")
            db.execSQL("CREATE INDEX idx_tx_date ON transactions(created_at)")
            db.execSQL("CREATE INDEX idx_tx_person ON transactions(person_id)")
        }
        if (oldVersion < 3) {
            createAccounts(db)
            db.execSQL("INSERT OR IGNORE INTO finance_accounts(name,created_at) SELECT DISTINCT CASE WHEN TRIM(COALESCE(account,''))='' THEN 'نقدی' ELSE account END, ? FROM transactions", arrayOf(System.currentTimeMillis()))
        }
        if (oldVersion < 4) {
            val columns=mutableSetOf<String>()
            db.rawQuery("PRAGMA table_info(finance_accounts)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
            if(!columns.contains("opening_balance")) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN opening_balance INTEGER NOT NULL DEFAULT 0")
            if(!columns.contains("opening_at")) db.execSQL("ALTER TABLE finance_accounts ADD COLUMN opening_at INTEGER NOT NULL DEFAULT 0")
            createTransfers(db)
        }
        if (oldVersion < 5) {
            createPersonOpeningBalances(db)
        }
        if (oldVersion < 6) {
            val columns=mutableSetOf<String>()
            db.rawQuery("PRAGMA table_info(people)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
            if(!columns.contains("display_mode")) db.execSQL("ALTER TABLE people ADD COLUMN display_mode INTEGER NOT NULL DEFAULT 4")
        }
        if (oldVersion < 7) {
            val columns=mutableSetOf<String>()
            db.rawQuery("PRAGMA table_info(people)",null).use { c -> while(c.moveToNext()) columns.add(c.getString(1)) }
            if(!columns.contains("photo_data")) db.execSQL("ALTER TABLE people ADD COLUMN photo_data TEXT DEFAULT ''")
        }
        if(oldVersion < 8) createPeopleExtras(db)
        if(oldVersion < 9) createPeopleExtras(db)
        if(oldVersion < 10) createFinanceExtras(db)
        if(oldVersion < 11) createPersonConnections(db)
    }
    private fun createPersonConnections(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS person_section_links(id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, section_key TEXT NOT NULL, relation_label TEXT DEFAULT '', linked_record_id INTEGER, notes TEXT DEFAULT '', created_at INTEGER NOT NULL, is_deleted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(person_id) REFERENCES people(id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_section_links_person ON person_section_links(person_id,is_deleted)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_person_section_links_section ON person_section_links(section_key,is_deleted)")
        db.execSQL("CREATE TABLE IF NOT EXISTS section_person_field_settings(id INTEGER PRIMARY KEY AUTOINCREMENT, section_key TEXT NOT NULL, field_key TEXT NOT NULL, field_label TEXT NOT NULL, is_visible INTEGER NOT NULL DEFAULT 1, display_order INTEGER NOT NULL DEFAULT 0, is_required INTEGER NOT NULL DEFAULT 0, allow_edit INTEGER NOT NULL DEFAULT 0, UNIQUE(section_key,field_key))")
        val sections = linkedMapOf(
            "finance" to "امور مالی و حسابداری", "ledger" to "دفتر حساب", "invoices" to "فاکتورها و صورتحساب‌ها",
            "sales" to "خرید و فروش", "contracts" to "قراردادها و تعهدات", "instruments" to "چک، سفته و اقساط",
            "bank_accounts" to "حساب‌های بانکی", "family" to "خانواده و بستگان", "friends" to "دوستان و آشنایان",
            "reminders" to "یادآوری‌ها و پیگیری‌ها", "documents" to "اسناد و مدارک", "other" to "سایر بخش‌ها"
        )
        val fields = listOf("name" to "نام و نام خانوادگی", "national_id" to "کد ملی / شناسه", "phone" to "شماره تماس اصلی", "second_phone" to "شماره تماس دوم", "landline" to "تلفن ثابت", "email" to "ایمیل", "address" to "نشانی", "job" to "شغل", "workplace" to "محل کار", "roles" to "نقش‌ها", "group_name" to "گروه اصلی")
        sections.forEach { (key, _) -> fields.forEachIndexed { index, f ->
            db.execSQL("INSERT OR IGNORE INTO section_person_field_settings(section_key,field_key,field_label,is_visible,display_order,is_required,allow_edit) VALUES(?,?,?,?,?,?,?)", arrayOf(key,f.first,f.second,1,index,if(f.first=="name")1 else 0,0))
        } }
    }
    fun addPersonSectionLink(personId:Long, sectionKey:String, relationLabel:String, notes:String=""):Long {
        val existing=DatabaseUtils.longForQuery(readableDatabase,"SELECT COALESCE(MAX(id),0) FROM person_section_links WHERE person_id=? AND section_key=? AND is_deleted=0",arrayOf(personId.toString(),sectionKey))
        if(existing>0L) return existing
        val id=writableDatabase.insertOrThrow("person_section_links",null,android.content.ContentValues().apply { put("person_id",personId);put("section_key",sectionKey);put("relation_label",relationLabel);put("notes",notes);put("created_at",System.currentTimeMillis()) })
        audit("اتصال پرونده شخص به بخش برنامه","شخص",personId,sectionKey+" • "+relationLabel)
        return id
    }
    fun personSectionLinks(personId:Long):List<Pair<String,String>> {
        val out=mutableListOf<Pair<String,String>>()
        readableDatabase.rawQuery("SELECT section_key,relation_label FROM person_section_links WHERE person_id=? AND is_deleted=0 ORDER BY id DESC",arrayOf(personId.toString())).use { c -> while(c.moveToNext()) out.add(Pair(c.getString(0),c.getString(1) ?: "")) }
        return out
    }
    fun sectionPeople(sectionKey:String):List<Pair<Long,String>> {
        val out=mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT p.id,p.name,COALESCE(l.relation_label,'') FROM person_section_links l JOIN people p ON p.id=l.person_id WHERE l.section_key=? AND l.is_deleted=0 AND p.is_deleted=0 ORDER BY p.name COLLATE NOCASE",arrayOf(sectionKey)).use { c -> while(c.moveToNext()) out.add(Pair(c.getLong(0),c.getString(1)+if(c.getString(2).isNullOrBlank()) "" else " • "+c.getString(2))) }
        return out
    }
    fun hasPersonSectionLink(personId:Long,sectionKey:String):Boolean = DatabaseUtils.longForQuery(readableDatabase,"SELECT COUNT(*) FROM person_section_links WHERE person_id=? AND section_key=? AND is_deleted=0",arrayOf(personId.toString(),sectionKey))>0
    fun sectionFieldSettings(sectionKey:String):List<Triple<String,String,Boolean>> {
        val out=mutableListOf<Triple<String,String,Boolean>>()
        readableDatabase.rawQuery("SELECT field_key,field_label,is_visible FROM section_person_field_settings WHERE section_key=? ORDER BY display_order,id",arrayOf(sectionKey)).use { c -> while(c.moveToNext()) out.add(Triple(c.getString(0),c.getString(1),c.getInt(2)==1)) }
        return out
    }
    fun setSectionFieldVisible(sectionKey:String,fieldKey:String,visible:Boolean) {
        writableDatabase.execSQL("UPDATE section_person_field_settings SET is_visible=? WHERE section_key=? AND field_key=?",arrayOf(if(visible)1 else 0,sectionKey,fieldKey))
        audit("تنظیم نمایش فیلد اطلاعات شخص","تنظیم اتصال",-1L,sectionKey+" • "+fieldKey+" • "+visible)
    }
    override fun onOpen(db: SQLiteDatabase) { super.onOpen(db); db.setForeignKeyConstraintsEnabled(true) }
    fun accounts(includeInactive:Boolean=false): List<String> {
        val out= mutableListOf<String>()
        val sql=if(includeInactive)"SELECT name FROM finance_accounts WHERE is_deleted=0 ORDER BY id" else "SELECT name FROM finance_accounts WHERE is_deleted=0 AND is_active=1 ORDER BY id"
        readableDatabase.rawQuery(sql,null).use { c -> while(c.moveToNext()) out.add(c.getString(0)) }
        if(out.isEmpty()) out.add("نقدی")
        return out
    }
    fun addAccount(name:String,bank:String="",type:String="صندوق",number:String="",card:String="",iban:String="",owner:String="",ownerPersonId:Long?=null,notes:String=""): Boolean {
        val n=name.trim(); if(n.isEmpty()) return false
        return try { writableDatabase.insertOrThrow("finance_accounts",null,android.content.ContentValues().apply { put("name",n);put("bank_name",bank);put("account_type",type);put("account_number",number);put("card_number",card);put("iban",iban);put("owner_name",owner);if(ownerPersonId!=null)put("owner_person_id",ownerPersonId);put("notes",notes);put("created_at",System.currentTimeMillis()) }); audit("ایجاد","حساب مالی",-1,"$n • $bank • $type"); true } catch (_:Exception) { false }
    }
    fun accountDetails(name:String):String {
        readableDatabase.rawQuery("SELECT bank_name,account_type,account_number,card_number,iban,owner_name,notes FROM finance_accounts WHERE name=?",arrayOf(name)).use { c -> if(c.moveToFirst()) return listOf("بانک: ${c.getString(0) ?: ""}","نوع: ${c.getString(1) ?: ""}","شماره حساب: ${c.getString(2) ?: ""}","شماره کارت: ${c.getString(3) ?: ""}","شبا: ${c.getString(4) ?: ""}","صاحب حساب: ${c.getString(5) ?: ""}","توضیحات: ${c.getString(6) ?: ""}").filter{it.substringAfter(": ").isNotBlank()}.joinToString("\n") }
        return ""
    }
    fun setAccountActive(name:String,active:Boolean) { writableDatabase.execSQL("UPDATE finance_accounts SET is_active=? WHERE name=?",arrayOf(if(active)1 else 0,name));audit(if(active)"فعال‌سازی حساب" else "غیرفعال‌سازی حساب","حساب مالی",-1,name) }
    fun inactiveAccounts():List<String> { val out=mutableListOf<String>();readableDatabase.rawQuery("SELECT name FROM finance_accounts WHERE is_deleted=0 AND is_active=0 ORDER BY id",null).use{c->while(c.moveToNext())out.add(c.getString(0))};return out }
    fun accountIsActive(name:String):Boolean { readableDatabase.rawQuery("SELECT is_active FROM finance_accounts WHERE name=?",arrayOf(name)).use { c -> return c.moveToFirst() && c.getInt(0)==1 } }
    fun accountBalanceBefore(account:String, timestamp:Long):Long {
        var opening=0L; var openingAt=0L
        readableDatabase.rawQuery("SELECT opening_balance,opening_at FROM finance_accounts WHERE name=? AND is_deleted=0",arrayOf(account)).use { c -> if(c.moveToFirst()){opening=c.getLong(0);openingAt=c.getLong(1)} }
        if(openingAt>timestamp) return 0L
        var balance=opening
        val cashTotals=cashTotals(openingAt,timestamp,account)
        balance+=cashTotals.first-cashTotals.second
        readableDatabase.rawQuery("SELECT t.from_account,t.to_account,t.amount FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=CASE WHEN t.from_account=? THEN fa.opening_at ELSE ta.opening_at END AND t.created_at<? AND (t.from_account=? OR t.to_account=?)",arrayOf(account,timestamp.toString(),account,account)).use { c -> while(c.moveToNext()){val a=c.getLong(2);if(c.getString(0)==account)balance-=a else balance+=a} }
        return balance
    }
    fun cashTotals(start:Long,endExclusive:Long,account:String?=null):Pair<Long,Long> {
        var incoming=0L;var outgoing=0L
        val sql="SELECT t.id,t.kind,t.amount,(SELECT COUNT(*) FROM tx_settlements s WHERE s.tx_id=t.id),(SELECT COALESCE(SUM(CASE WHEN s.method IN ('نقدی','کارت‌به‌کارت','واریز بانکی') THEN s.amount WHEN s.method IN ('چک','سفته') AND EXISTS(SELECT 1 FROM financial_instruments i WHERE i.tx_id=t.id AND i.instrument_type=s.method AND i.amount=s.amount AND i.status IN ('وصول‌شده','پرداخت‌شده')) THEN s.amount ELSE 0 END),0) FROM tx_settlements s WHERE s.tx_id=t.id) FROM transactions t LEFT JOIN finance_accounts a ON a.name=t.account WHERE t.is_deleted=0 AND t.created_at>=? AND t.created_at<? AND t.created_at>=COALESCE(a.opening_at,0)"+(if(account==null)"" else " AND t.account=?")
        val args=if(account==null)arrayOf(start.toString(),endExclusive.toString()) else arrayOf(start.toString(),endExclusive.toString(),account)
        readableDatabase.rawQuery(sql,args).use { c -> while(c.moveToNext()) {
            val id=c.getLong(0);val kind=c.getString(1);val amount=c.getLong(2);val settlementCount=c.getInt(3);val settledCash=c.getLong(4)
            val cash=if(settlementCount==0) { if(kind in listOf("دریافت وجه","درآمد","پرداخت وجه","هزینه")) amount else 0L } else settledCash
            if(kind in listOf("دریافت وجه","درآمد","طلب","فروش نسیه","تحویل کالا")) incoming+=cash
            else if(kind in listOf("پرداخت وجه","هزینه","بدهی","خرید نسیه","دریافت کالا")) outgoing+=cash
        } }
        return Pair(incoming,outgoing)
    }
    fun accountBalances(includeInactive:Boolean=false): List<Pair<String,Long>> = accounts(includeInactive).map { Pair(it,accountBalanceBefore(it,Long.MAX_VALUE)) }
    fun setOpeningBalance(account:String,amount:Long,at:Long,reason:String="") {
        val d=writableDatabase
        val old=accountOpening(account)
        d.beginTransaction()
        try {
            d.execSQL("INSERT INTO account_opening_history(account,old_balance,old_at,new_balance,new_at,reason,changed_at) VALUES(?,?,?,?,?,?,?)",arrayOf(account,old.first,old.second,amount,at,reason,System.currentTimeMillis()))
            d.execSQL("UPDATE finance_accounts SET opening_balance=?,opening_at=? WHERE name=? AND is_deleted=0",arrayOf(amount,at,account))
            audit("ثبت/اصلاح مانده اول دوره","حساب مالی",-1,"$account: $old → $amount @ $at؛ $reason")
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun addTxDocument(txId:Long,title:String,data:String) { writableDatabase.execSQL("INSERT INTO tx_documents(tx_id,title,data,created_at) VALUES(?,?,?,?)",arrayOf(txId,title,data,System.currentTimeMillis()));audit("افزودن پیوست","تراکنش",txId,title) }
    fun txDocuments(txId:Long):List<Pair<Long,String>> { val out=mutableListOf<Pair<Long,String>>();readableDatabase.rawQuery("SELECT id,title FROM tx_documents WHERE tx_id=? ORDER BY id DESC",arrayOf(txId.toString())).use{c->while(c.moveToNext())out.add(Pair(c.getLong(0),c.getString(1)))};return out }
    fun txDocumentData(id:Long):String? { readableDatabase.rawQuery("SELECT data FROM tx_documents WHERE id=?",arrayOf(id.toString())).use{c->return if(c.moveToFirst())c.getString(0) else null} }
    fun deleteTxDocument(id:Long) { writableDatabase.delete("tx_documents","id=?",arrayOf(id.toString())) }
    fun addSettlement(txId:Long,method:String,amount:Long,reference:String,details:String) {
        require(amount>0) { "مبلغ تسویه باید بیشتر از صفر باشد" }
        writableDatabase.execSQL("INSERT INTO tx_settlements(tx_id,method,amount,reference,details,created_at) VALUES(?,?,?,?,?,?)",arrayOf(txId,method,amount,reference,details,System.currentTimeMillis()))
        audit("ثبت روش تسویه","تراکنش",txId,"$method: $amount؛ $reference؛ $details")
    }
    fun addInstrument(txId:Long?,personId:Long?,type:String,number:String,bank:String,issuer:String,amount:Long,issuedAt:Long,dueAt:Long,notes:String) {
        require(amount>0 && dueAt>=issuedAt) { "مبلغ یا سررسید ابزار مالی معتبر نیست" }
        writableDatabase.execSQL("INSERT INTO financial_instruments(tx_id,person_id,instrument_type,number,bank,issuer,amount,issued_at,due_at,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,'در انتظار',?,?)",arrayOf(txId,personId,type,number,bank,issuer,amount,issuedAt,dueAt,notes,System.currentTimeMillis()))
        audit("ثبت $type","ابزار مالی",-1,"$number • $amount • سررسید ${jalali(dueAt)}")
    }
    fun settlementSummary(txId:Long):String {
        val parts=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT method,amount,reference,details FROM tx_settlements WHERE tx_id=? ORDER BY id",arrayOf(txId.toString())).use { c -> while(c.moveToNext()) parts.add("${c.getString(0)}: ${fmt(c.getLong(1))} ${moneyUnit()}${if(c.getString(2).isNullOrBlank())"" else " • ${c.getString(2)}"}${if(c.getString(3).isNullOrBlank())"" else " • ${c.getString(3)}"}") }
        return parts.joinToString("\n")
    }
    fun instrumentRows():List<Pair<Long,String>> {
        val out=mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT id,instrument_type,number,bank,amount,due_at,status,notes FROM financial_instruments WHERE is_deleted=0 ORDER BY due_at",null).use { c -> while(c.moveToNext()) out.add(Pair(c.getLong(0),"${c.getString(1)} ${c.getString(2)} • ${c.getString(3)} • ${fmt(c.getLong(4))} ${moneyUnit()} • سررسید ${jalali(c.getLong(5))} • ${c.getString(6)}${if(c.getString(7).isNullOrBlank())"" else " • ${c.getString(7)}"}")) }
        return out
    }
    fun updateInstrumentStatus(id:Long,status:String) { writableDatabase.execSQL("UPDATE financial_instruments SET status=? WHERE id=?",arrayOf(status,id));audit("تغییر وضعیت ابزار مالی","ابزار مالی",id,status) }
    fun installmentRows():List<Pair<Long,String>> {
        val out=mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT i.id,p.name,i.title,i.total_amount,i.installment_amount,i.paid_amount,i.next_due,i.status FROM installment_plans i JOIN people p ON p.id=i.person_id WHERE i.status='فعال' ORDER BY i.next_due",null).use { c -> while(c.moveToNext()) out.add(Pair(c.getLong(0),"${c.getString(1)} • ${c.getString(2)}\nکل: ${fmt(c.getLong(3))}؛ هر قسط: ${fmt(c.getLong(4))}؛ پرداخت‌شده: ${fmt(c.getLong(5))}\nسررسید بعدی: ${jalali(c.getLong(6))} • ${c.getString(7)}")) }
        return out
    }
    fun payInstallment(id:Long,amount:Long) {
        require(amount>0) { "مبلغ پرداخت معتبر نیست" }
        val d=writableDatabase;d.beginTransaction()
        try {
            var total=0L;var paid=0L;var each=0L;var interval=30;var due=System.currentTimeMillis()
            d.rawQuery("SELECT total_amount,paid_amount,installment_amount,interval_days,next_due FROM installment_plans WHERE id=? AND status='فعال'",arrayOf(id.toString())).use { c -> if(!c.moveToFirst()) throw IllegalArgumentException("برنامه فعال پیدا نشد");total=c.getLong(0);paid=c.getLong(1);each=c.getLong(2);interval=c.getInt(3);due=c.getLong(4) }
            require(paid+amount<=total) { "مبلغ پرداخت از مانده اقساط بیشتر است" }
            val newPaid=paid+amount;val completedSteps=(newPaid/each)-(paid/each)
            val next=Calendar.getInstance().apply{timeInMillis=due;add(Calendar.DAY_OF_MONTH,(interval*completedSteps).toInt())}.timeInMillis
            d.execSQL("UPDATE installment_plans SET paid_amount=?,next_due=?,status=? WHERE id=?",arrayOf(newPaid,next,if(newPaid==total)"تسویه‌شده" else "فعال",id))
            audit("ثبت پرداخت قسط","برنامه اقساط",id,"$amount؛ مجموع پرداخت ${paid+amount}")
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    fun instruments():List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT instrument_type,number,bank,amount,due_at,status,notes FROM financial_instruments WHERE is_deleted=0 ORDER BY due_at",null).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} ${c.getString(1)} • ${c.getString(2)} • ${fmt(c.getLong(3))} ${moneyUnit()} • سررسید ${jalali(c.getLong(4))} • ${c.getString(5)}${if(c.getString(6).isNullOrBlank())"" else " • ${c.getString(6)}"}") }
        return out
    }
    fun addInstallment(personId:Long,title:String,total:Long,each:Long,interval:Int,start:Long,notes:String) {
        require(total>0 && each>0 && each<=total && interval>0) { "مقادیر قسط معتبر نیستند" }
        writableDatabase.execSQL("INSERT INTO installment_plans(person_id,title,total_amount,installment_amount,interval_days,start_at,next_due,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(personId,title,total,each,interval,start,start,notes,System.currentTimeMillis()))
        audit("ثبت برنامه اقساط","شخص",personId,"$title • $total • قسط $each")
    }
    fun installments():List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT p.name,i.title,i.total_amount,i.installment_amount,i.paid_amount,i.next_due,i.status FROM installment_plans i JOIN people p ON p.id=i.person_id WHERE i.status='فعال' ORDER BY i.next_due",null).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} • ${c.getString(1)}\nکل: ${fmt(c.getLong(2))}؛ هر قسط: ${fmt(c.getLong(3))}؛ پرداخت‌شده: ${fmt(c.getLong(4))}\nسررسید بعدی: ${jalali(c.getLong(5))} • ${c.getString(6)}") }
        return out
    }
    fun reconcile(account:String,start:Long,end:Long,statement:Long,notes:String):Pair<Long,Long> {
        val book=accountBalanceBefore(account,end)
        val diff=statement-book
        writableDatabase.execSQL("INSERT INTO account_reconciliations(account,from_at,to_at,book_balance,statement_balance,difference,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)",arrayOf(account,start,end,book,statement,diff,if(diff==0L)"مطابق" else "دارای مغایرت",notes,System.currentTimeMillis()))
        audit("مغایرت‌گیری حساب","حساب مالی",-1,"$account • دفتر $book • صورت‌حساب $statement • اختلاف $diff")
        return Pair(book,diff)
    }
    fun reconciliationHistory():List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT account,from_at,to_at,book_balance,statement_balance,difference,status,notes FROM account_reconciliations ORDER BY id DESC LIMIT 100",null).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} • ${jalali(c.getLong(1))} تا ${jalali(c.getLong(2))}\nدفتر: ${fmt(c.getLong(3))}؛ صورت‌حساب: ${fmt(c.getLong(4))}؛ اختلاف: ${fmt(c.getLong(5))} • ${c.getString(6)}${if(c.getString(7).isNullOrBlank())"" else " • ${c.getString(7)}"}") }
        return out
    }

    fun transfer(from:String,to:String,amount:Long,note:String,at:Long) {
        require(from!=to) { "حساب مبدأ و مقصد باید متفاوت باشند" }; require(amount>0) { "مبلغ باید بیشتر از صفر باشد" }
        val d=writableDatabase; d.beginTransaction()
        try { d.execSQL("INSERT INTO account_transfers(from_account,to_account,amount,note,created_at) VALUES(?,?,?,?,?)",arrayOf(from,to,amount,note,at)); audit("انتقال وجه بین حساب‌ها","انتقال",-1,"$from ← $to: $amount"); d.setTransactionSuccessful() } finally { d.endTransaction() }
    }
    fun accountTransfers(account:String,start:Long,endExclusive:Long):List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT t.from_account,t.to_account,t.amount,t.note,t.created_at FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=CASE WHEN t.from_account=? THEN fa.opening_at ELSE ta.opening_at END AND t.created_at>=? AND t.created_at<? AND (t.from_account=? OR t.to_account=?) ORDER BY t.created_at DESC,t.id DESC",arrayOf(account,start.toString(),endExclusive.toString(),account,account)).use { c -> while(c.moveToNext()){val incoming=c.getString(1)==account;out.add("${if(incoming)"واریز از ${c.getString(0)}" else "انتقال به ${c.getString(1)}"} • ${fmt(c.getLong(2))} ${moneyUnit()} • ${jalali(c.getLong(4))}${if(c.getString(3).isNullOrBlank())"" else " • ${c.getString(3)}"}")} }
        return out
    }
    fun accountTransferTotals(account:String,start:Long,endExclusive:Long):Pair<Long,Long> {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN t.to_account=? THEN t.amount ELSE 0 END),0),COALESCE(SUM(CASE WHEN t.from_account=? THEN t.amount ELSE 0 END),0) FROM account_transfers t JOIN finance_accounts fa ON fa.name=t.from_account JOIN finance_accounts ta ON ta.name=t.to_account WHERE t.is_deleted=0 AND t.created_at>=CASE WHEN t.from_account=? THEN fa.opening_at ELSE ta.opening_at END AND t.created_at>=? AND t.created_at<? AND (t.from_account=? OR t.to_account=?)",arrayOf(account,account,account,start.toString(),endExclusive.toString(),account,account)).use { c -> return if(c.moveToFirst()) Pair(c.getLong(0),c.getLong(1)) else Pair(0L,0L) }
    }
    fun accountOpeningAt(account:String):Long { readableDatabase.rawQuery("SELECT opening_at FROM finance_accounts WHERE name=?",arrayOf(account)).use { c -> return if(c.moveToFirst())c.getLong(0) else 0L } }
    fun accountOpening(account:String):Pair<Long,Long> { readableDatabase.rawQuery("SELECT opening_balance,opening_at FROM finance_accounts WHERE name=?",arrayOf(account)).use { c -> return if(c.moveToFirst())Pair(c.getLong(0),c.getLong(1)) else Pair(0L,0L) } }
    fun updateTx(id:Long, kind:String, amount:Long, note:String, account:String, createdAt:Long) {
        val settled=DatabaseUtils.longForQuery(readableDatabase,"SELECT COALESCE(SUM(amount),0) FROM tx_settlements WHERE tx_id=?",arrayOf(id.toString()))
        require(amount>=settled) { "مبلغ عملیات از مجموع تسویه‌های ثبت‌شده کمتر است؛ ابتدا جزئیات تسویه را اصلاح کنید" }
        writableDatabase.execSQL("UPDATE transactions SET kind=?,amount=?,note=?,account=?,created_at=? WHERE id=? AND is_deleted=0",arrayOf(kind,amount,note,account,createdAt,id)); audit("ویرایش","تراکنش",id,"$kind - $amount")
    }
    fun personOpeningBalance(personId:Long):PersonOpening? {
        readableDatabase.rawQuery("SELECT id,person_id,amount,balance_type,base_date,description,created_at FROM person_opening_balances WHERE person_id=? AND is_active=1 LIMIT 1",arrayOf(personId.toString())).use { c ->
            return if(c.moveToFirst()) PersonOpening(c.getLong(0),c.getLong(1),c.getLong(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6)) else null
        }
    }
    fun setPersonOpeningBalance(personId:Long,amount:Long,balanceType:String,baseDate:Long,description:String) {
        require(amount>=0) { "مبلغ مانده اولیه نمی‌تواند منفی باشد" }
        require(balanceType=="طلب" || balanceType=="بدهی") { "نوع مانده اولیه نامعتبر است" }
        val d=writableDatabase
        d.beginTransaction()
        try {
            d.execSQL("UPDATE person_opening_balances SET is_active=0 WHERE person_id=? AND is_active=1",arrayOf(personId))
            d.execSQL("INSERT INTO person_opening_balances(person_id,amount,balance_type,base_date,description,is_active,created_at) VALUES(?,?,?,?,?,1,?)",arrayOf(personId,amount,balanceType,baseDate,description,System.currentTimeMillis()))
            audit("ثبت/اصلاح مانده اول دوره","شخص",personId,"$balanceType: $amount @ $baseDate؛ $description")
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }
    private fun balances(personId: Long): Pair<Long,Long> {
        val opening=personOpeningBalance(personId)
        var receivable=if(opening?.balanceType=="طلب") opening.amount else 0L
        var payable=if(opening?.balanceType=="بدهی") opening.amount else 0L
        val baseDate=opening?.baseDate ?: 0L
        readableDatabase.rawQuery("SELECT t.id,t.kind,t.amount,(SELECT COUNT(*) FROM tx_settlements s WHERE s.tx_id=t.id),(SELECT COALESCE(SUM(CASE WHEN s.method!='نسیه/تسویه بعدی' THEN s.amount ELSE 0 END),0) FROM tx_settlements s WHERE s.tx_id=t.id) FROM transactions t WHERE t.person_id=? AND t.is_deleted=0 AND t.created_at>=? ORDER BY t.created_at,t.id", arrayOf(personId.toString(),baseDate.toString())).use { c ->
            while(c.moveToNext()) {
                val kind=c.getString(1); val grossAmount=c.getLong(2);val settlementCount=c.getInt(3);val settled=c.getLong(4);val amount=if(kind in listOf("دریافت وجه","پرداخت وجه") && settlementCount>0)settled else grossAmount
                val increasesReceivable = kind in listOf("طلب","پرداخت وجه","تحویل کالا","فروش نسیه")
                if(increasesReceivable) {
                    val offset=minOf(payable,amount); payable-=offset; receivable+=amount-offset
                } else if(kind in listOf("بدهی","دریافت وجه","دریافت کالا","خرید نسیه")) {
                    val offset=minOf(receivable,amount); receivable-=offset; payable+=amount-offset
                }
                if(settled>0 && kind in listOf("طلب","فروش نسیه","تحویل کالا")) { val offset=minOf(receivable,settled);receivable-=offset }
                if(settled>0 && kind in listOf("بدهی","خرید نسیه","دریافت کالا")) { val offset=minOf(payable,settled);payable-=offset }
            }
        }
        return Pair(receivable,payable)
    }
    fun people(q: String = ""): List<Person> {
        val out= mutableListOf<Person>()
        readableDatabase.rawQuery("SELECT id,name,phone,address,relation,notes,COALESCE(photo_data,''),second_phone,national_id,birth_date,job,workplace,source,credit_rating,tags,location,father_name,landline,email,group_name,roles FROM people WHERE is_deleted=0 AND (name LIKE ? OR phone LIKE ? OR second_phone LIKE ? OR national_id LIKE ? OR tags LIKE ? OR job LIKE ? OR workplace LIKE ? OR email LIKE ? OR group_name LIKE ? OR roles LIKE ?) ORDER BY name", arrayOf("%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%")).use { c ->
            while(c.moveToNext()) { val id=c.getLong(0); val b=balances(id); out.add(Person(id,c.getString(1),c.getString(2) ?: "",c.getString(3) ?: "",c.getString(4) ?: "",c.getString(5) ?: "",c.getString(6) ?: "",b.first-b.second,b.first,b.second,c.getString(7) ?: "",c.getString(8) ?: "",c.getString(9) ?: "",c.getString(10) ?: "",c.getString(11) ?: "",c.getString(12) ?: "",c.getString(13) ?: "",c.getString(14) ?: "",c.getString(15) ?: "",c.getString(16) ?: "",c.getString(17) ?: "",c.getString(18) ?: "",c.getString(19) ?: "سایر افراد و طرف‌حساب‌ها",c.getString(20) ?: "")) }
        }
        return out
    }
    fun personDisplayMode(id:Long):Int {
        readableDatabase.rawQuery("SELECT display_mode FROM people WHERE id=?",arrayOf(id.toString())).use { c ->
            return if(c.moveToFirst()) c.getInt(0).coerceIn(1,5) else 4
        }
    }
    fun setPersonDisplayMode(id:Long,mode:Int) {
        require(mode in 1..5)
        writableDatabase.execSQL("UPDATE people SET display_mode=? WHERE id=?",arrayOf(mode,id))
        audit("تغییر تنظیم نمایش شخص","شخص",id,"حالت نمایش: $mode")
    }
    fun addPerson(name: String, phone: String, address: String, relation: String, notes: String, photoData:String=""): Long {
        val id = writableDatabase.insertOrThrow("people", null, android.content.ContentValues().apply { put("name",name); put("phone",phone); put("address",address); put("relation",relation); put("notes",notes); put("photo_data",photoData); put("created_at",System.currentTimeMillis()) })
        audit("ایجاد", "شخص", id, name)
        return id
    }
    fun setPersonPhoto(id:Long,data:String) {
        writableDatabase.execSQL("UPDATE people SET photo_data=? WHERE id=?",arrayOf(data,id))
        audit("تغییر عکس شخص","شخص",id,if(data.isBlank())"حذف عکس" else "ثبت عکس")
    }
    fun updatePersonExtra(id:Long, secondPhone:String, nationalId:String, birthDate:String, job:String, workplace:String, source:String, rating:String, tags:String, location:String, fatherName:String="", landline:String="", email:String="", groupName:String="سایر افراد و طرف‌حساب‌ها", roles:String="") {
        writableDatabase.execSQL("UPDATE people SET second_phone=?,national_id=?,birth_date=?,job=?,workplace=?,source=?,credit_rating=?,tags=?,location=?,father_name=?,landline=?,email=?,group_name=?,roles=? WHERE id=?",arrayOf(secondPhone,nationalId,birthDate,job,workplace,source,rating,tags,location,fatherName,landline,email,groupName,roles,id))
        audit("ویرایش مشخصات تکمیلی","شخص",id,"تکمیل پرونده")
    }
    fun duplicatePeople(name:String,phone:String,nationalId:String,excludeId:Long=0):List<String> {
        val out=mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name,phone,national_id FROM people WHERE is_deleted=0 AND id<>? AND ((?<>'' AND national_id=?) OR (?<>'' AND (phone=? OR second_phone=?)) OR (?<>'' AND name=?))",arrayOf(excludeId.toString(),nationalId,nationalId,phone,phone,phone,name,name)).use { c -> while(c.moveToNext()) out.add("${c.getString(0)} • ${c.getString(1)} • ${c.getString(2)}") }
        return out.distinct()
    }
    fun addDocument(personId:Long,title:String,data:String) { writableDatabase.execSQL("INSERT INTO person_documents(person_id,title,data,created_at) VALUES(?,?,?,?)",arrayOf(personId,title,data,System.currentTimeMillis())); audit("افزودن مدرک","شخص",personId,title) }
    fun documents(personId:Long):List<Pair<Long,String>> { val out=mutableListOf<Pair<Long,String>>(); readableDatabase.rawQuery("SELECT id,title FROM person_documents WHERE person_id=? ORDER BY id DESC",arrayOf(personId.toString())).use { c->while(c.moveToNext())out.add(Pair(c.getLong(0),c.getString(1)))};return out }
    fun documentData(id:Long):String? { readableDatabase.rawQuery("SELECT data FROM person_documents WHERE id=?",arrayOf(id.toString())).use { c->return if(c.moveToFirst())c.getString(0) else null } }
    fun deleteDocument(id:Long) { writableDatabase.delete("person_documents","id=?",arrayOf(id.toString())) }
    fun addReminder(personId:Long,title:String,note:String,at:Long):Long { writableDatabase.execSQL("INSERT INTO person_reminders(person_id,title,note,remind_at,created_at) VALUES(?,?,?,?,?)",arrayOf(personId,title,note,at,System.currentTimeMillis()));val id=DatabaseUtils.longForQuery(readableDatabase,"SELECT last_insert_rowid()",null);audit("ثبت یادآوری","شخص",personId,title);return id }
    fun reminders(personId:Long):List<Triple<Long,String,Long>> { val out=mutableListOf<Triple<Long,String,Long>>(); readableDatabase.rawQuery("SELECT id,title,remind_at FROM person_reminders WHERE person_id=? AND is_done=0 ORDER BY remind_at",arrayOf(personId.toString())).use { c->while(c.moveToNext())out.add(Triple(c.getLong(0),c.getString(1),c.getLong(2)))};return out }
    fun completeReminder(id:Long) { writableDatabase.execSQL("UPDATE person_reminders SET is_done=1 WHERE id=?",arrayOf(id)) }
    fun archivePerson(id:Long) {
        writableDatabase.execSQL("UPDATE people SET is_deleted=1 WHERE id=? AND is_deleted=0",arrayOf(id))
        audit("بایگانی", "شخص", id, "پرونده از فهرست فعال خارج شد؛ سوابق مالی حفظ شدند")
    }
    fun restorePerson(id:Long) {
        writableDatabase.execSQL("UPDATE people SET is_deleted=0 WHERE id=? AND is_deleted=1",arrayOf(id))
        audit("بازیابی", "شخص", id, "بازگشت پرونده به فهرست فعال")
    }
    fun deletedPeople():List<Person> {
        val out=mutableListOf<Person>()
        readableDatabase.rawQuery("SELECT id,name,phone,address,relation,notes,COALESCE(photo_data,''),second_phone,national_id,birth_date,job,workplace,source,credit_rating,tags,location,father_name,landline,email,group_name,roles FROM people WHERE is_deleted=1 ORDER BY name",null).use { c ->
            while(c.moveToNext()) { val id=c.getLong(0); val b=balances(id); out.add(Person(id,c.getString(1),c.getString(2) ?: "",c.getString(3) ?: "",c.getString(4) ?: "",c.getString(5) ?: "",c.getString(6) ?: "",b.first-b.second,b.first,b.second,c.getString(7) ?: "",c.getString(8) ?: "",c.getString(9) ?: "",c.getString(10) ?: "",c.getString(11) ?: "",c.getString(12) ?: "",c.getString(13) ?: "",c.getString(14) ?: "",c.getString(15) ?: "",c.getString(16) ?: "",c.getString(17) ?: "",c.getString(18) ?: "",c.getString(19) ?: "سایر افراد و طرف‌حساب‌ها",c.getString(20) ?: "")) }
        }
        return out
    }
    fun personName(id:Long):String { readableDatabase.rawQuery("SELECT name FROM people WHERE id=?",arrayOf(id.toString())).use { c -> return if(c.moveToFirst()) c.getString(0) else "" } }
    fun personTransactionCount(id:Long):Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM transactions WHERE person_id=?",arrayOf(id.toString())).use { c -> return if(c.moveToFirst()) c.getInt(0) else 0 }
    }
    fun addTx(personId: Long?, kind: String, amount: Long, note: String, account: String, createdAt:Long):Long {
        val id = writableDatabase.insertOrThrow("transactions", null, android.content.ContentValues().apply { if(personId==null) putNull("person_id") else put("person_id",personId); put("kind",kind); put("amount",amount); put("note",note); put("account",account.ifBlank { "نقدی" }); put("created_at",createdAt) })
        if(personId!=null) {
            addPersonSectionLink(personId,"ledger","طرف‌حساب دفتر حساب")
            if(kind in listOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")) addPersonSectionLink(personId,"finance","طرف‌حساب امور مالی")
        }
        audit("ثبت", "تراکنش", id, "$kind - $amount")
        return id
    }
    private fun audit(action:String,target:String,id:Long,details:String) { writableDatabase.execSQL("INSERT INTO audit_log(action,target,target_id,details,created_at) VALUES(?,?,?,?,?)", arrayOf(action,target,id,details,System.currentTimeMillis())) }
    fun summary(): Summary {
        val totals=cashTotals(0L,Long.MAX_VALUE);val inc=totals.first;val exp=totals.second
        val ps=people(); val cash=accountBalances(true).sumOf{it.second}
        return Summary(inc,exp,cash,ps.sumOf{if(it.balance>0) it.balance else 0L},ps.sumOf{if(it.balance<0) -it.balance else 0L})
    }
    fun transactions(personId: Long? = null, limit: Int = 300): List<Tx> {
        val out= mutableListOf<Tx>()
        val where=if(personId==null) "t.is_deleted=0" else "t.is_deleted=0 AND t.person_id=?"
        val args=if(personId==null) null else arrayOf(personId.toString())
        readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id WHERE $where ORDER BY t.created_at DESC,t.id DESC LIMIT $limit",args).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }
        return out
    }
    fun cashBalanceBefore(timestamp:Long):Long = accounts().sumOf { accountBalanceBefore(it,timestamp) }
    fun transactionsBetween(start:Long,endExclusive:Long):List<Tx> {
        val out= mutableListOf<Tx>()
        readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id LEFT JOIN finance_accounts a ON a.name=t.account WHERE t.is_deleted=0 AND t.created_at>=? AND t.created_at<? AND t.created_at>=COALESCE(a.opening_at,0) ORDER BY t.created_at DESC,t.id DESC",arrayOf(start.toString(),endExclusive.toString())).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }
        return out
    }
    fun deleteTx(id:Long) { writableDatabase.execSQL("UPDATE transactions SET is_deleted=1 WHERE id=?",arrayOf(id)); audit("حذف نرم", "تراکنش", id, "انتقال به سطل بازیابی") }
    fun restoreTx(id:Long) { writableDatabase.execSQL("UPDATE transactions SET is_deleted=0 WHERE id=?",arrayOf(id)); audit("بازیابی", "تراکنش", id, "بازیابی از سطل") }
    fun deletedTx(): List<Tx> {
        val out= mutableListOf<Tx>(); readableDatabase.rawQuery("SELECT t.id,t.person_id,COALESCE(p.name,'عمومی'),t.kind,t.amount,t.note,t.created_at,t.account FROM transactions t LEFT JOIN people p ON p.id=t.person_id WHERE t.is_deleted=1 ORDER BY t.created_at DESC",null).use { c -> while(c.moveToNext()) out.add(Tx(c.getLong(0),if(c.isNull(1)) null else c.getLong(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5) ?: "",c.getLong(6),c.getString(7) ?: "نقدی")) }; return out
    }
}

private object MoneyDisplay {
    var unit: String = "تومان"
    var separator: Boolean = true
    var persianDigits: Boolean = true
}
private fun fmt(n: Long): String {
    // Use BigInteger so converting large toman balances to rial cannot overflow Long.
    val value = BigInteger.valueOf(n).let { if (MoneyDisplay.unit == "ریال") it.multiply(BigInteger.TEN) else it }
    val raw = if (MoneyDisplay.separator) DecimalFormat("#,###").format(value) else value.toString()
    return if (MoneyDisplay.persianDigits) raw.map { ch -> if (ch in '0'..'9') ('۰'.code + (ch.code-'0'.code)).toChar() else ch }.joinToString("") else raw
}
private fun moneyUnit(): String = MoneyDisplay.unit
// Accept Persian, Arabic-Indic and English digits in every numeric field.
private fun parseLongDigits(input: String): Long? {
    val normalized = input.trim().filterNot { it == ',' || it == '٬' || it == '،' || it == '，' || it.isWhitespace() }.map { ch ->
        when (ch) {
            in '۰'..'۹' -> ('0'.code + ch.code - '۰'.code).toChar()
            in '٠'..'٩' -> ('0'.code + ch.code - '٠'.code).toChar()
            else -> ch
        }
    }.joinToString("")
    return normalized.toLongOrNull()
}
private fun jalali(millis:Long):String {
    val cal=Calendar.getInstance().apply { timeInMillis=millis }; val gy=cal.get(Calendar.YEAR); val gm=cal.get(Calendar.MONTH)+1; val gd=cal.get(Calendar.DAY_OF_MONTH)
    val gdm=arrayOf(0,31,if(isLeap(gy))29 else 28,31,30,31,30,31,31,30,31,30,31)
    var gy2=gy-1600; var gm2=gm-1; var gd2=gd-1
    var gdn=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400
    for(i in 0 until gm2) gdn+=gdm[i+1]
    gdn+=gd2
    var jdn=gdn-79; val jnp=jdn/12053; jdn%=12053
    var jy=979+33*jnp+4*(jdn/1461); jdn%=1461
    if(jdn>=366){jy+=(jdn-1)/365; jdn=(jdn-1)%365}
    val jm=if(jdn<186) 1+(jdn/31).toInt() else 7+((jdn-186)/30).toInt()
    val jd=if(jdn<186) 1+(jdn%31).toInt() else 1+((jdn-186)%30).toInt()
    return "%04d/%02d/%02d".format(Locale.US,jy,jm,jd)
}
private fun isLeap(y:Int)= (y%4==0 && y%100!=0)||y%400==0
private fun jalaliToMillis(jy:Int,jm:Int,jd:Int):Long? {
    if(jy<1200 || jy>1600 || jm !in 1..12 || jd !in 1..31) return null
    val base=Calendar.getInstance().apply { clear(); set(jy+621,Calendar.MARCH,18,0,0,0) }
    var start:Calendar?=null
    for(offset in 0..5) {
        val candidate=(base.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH,offset) }
        val label=jalali(candidate.timeInMillis)
        if(label=="%04d/01/01".format(Locale.US,jy)){start=candidate;break}
    }
    val first=start ?: return null
    val maxDay=if(jm<=6)31 else if(jm<=11)30 else if(isJalaliLeap(jy))30 else 29
    if(jd>maxDay) return null
    val dayOffset=if(jm<=6)(jm-1)*31+(jd-1) else 186+(jm-7)*30+(jd-1)
    first.add(Calendar.DAY_OF_MONTH,dayOffset)
    return first.timeInMillis
}
private fun isJalaliLeap(year:Int):Boolean {
    val a=jalaliToMillisRawStart(year) ?: return false
    val b=jalaliToMillisRawStart(year+1) ?: return false
    return (b-a)/86400000L>365
}
private fun jalaliToMillisRawStart(jy:Int):Long? {
    val base=Calendar.getInstance().apply { clear(); set(jy+621,Calendar.MARCH,18,0,0,0) }
    for(offset in 0..5) { val c=(base.clone() as Calendar).apply{add(Calendar.DAY_OF_MONTH,offset)}; if(jalali(c.timeInMillis)=="%04d/01/01".format(Locale.US,jy)) return c.timeInMillis }
    return null
}
private fun jalaliInput(millis:Long):String = jalali(millis)


class MainActivity : Activity() {
    private lateinit var db: LedgerDb
    private var peopleFilter = 0 // 0 همه، 1 طلبکار، 2 بدهکار، 3 تسویه‌شده
    private var peopleSort = 0 // 0 نام، 1 بیشترین طلب، 2 بیشترین بدهی، 3 بیشترین مانده خالص
    private val requestCreateBackup = 4101
    private var pendingBackupType:String = "both"
    private val requestRestoreBackup = 4102
    private val requestPickContact = 4103
    private val requestTakePersonPhoto = 4104
    private val requestChoosePersonPhoto = 4105
    private val requestChooseTxDocument = 4121
    private var pendingTxDocumentId:Long?=null
    private var activePersonName:EditText?=null
    private var activePersonPhone:EditText?=null
    private var activePersonPhotoData:String=""
    private var activePersonPhotoPreview:ImageView?=null
    private lateinit var root: LinearLayout
    private val green=0xff21634a.toInt(); private val red=0xffa74636.toInt(); private val bg=0xfff4f7f4.toInt(); private val pale=0xffe8f1eb.toInt()
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); loadMoneySettings(); val peoplePrefs=getSharedPreferences("people_list",Context.MODE_PRIVATE); peopleFilter=peoplePrefs.getInt("filter",0).coerceIn(0,3); peopleSort=peoplePrefs.getInt("sort",0).coerceIn(0,3); db=LedgerDb(this); showHome()}
    private fun loadMoneySettings(){
        val p=getSharedPreferences("money_display",Context.MODE_PRIVATE)
        MoneyDisplay.unit=p.getString("unit","تومان") ?: "تومان"
        MoneyDisplay.separator=p.getBoolean("separator",true)
        MoneyDisplay.persianDigits=p.getBoolean("persian_digits",true)
    }
    private fun saveMoneySettings(unit:String,separator:Boolean,persian:Boolean){
        getSharedPreferences("money_display",Context.MODE_PRIVATE).edit().putString("unit",unit).putBoolean("separator",separator).putBoolean("persian_digits",persian).apply()
        MoneyDisplay.unit=unit; MoneyDisplay.separator=separator; MoneyDisplay.persianDigits=persian
    }
    private fun showMoneySettings(){
        base("تنظیمات نمایش مبالغ"){showHome()}
        val box=card()
        box.addView(text("واحد نمایش مبلغ",16f,green,true))
        val unit=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("تومان","ریال"));setSelection(if(MoneyDisplay.unit=="ریال")1 else 0)}
        val separator=CheckBox(this).apply{text="نمایش جداکننده هزارگان";isChecked=MoneyDisplay.separator}
        val digits=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("ارقام فارسی","ارقام انگلیسی"));setSelection(if(MoneyDisplay.persianDigits)0 else 1)}
        box.addView(unit);box.addView(separator);box.addView(text("شیوه نمایش ارقام",16f,green,true));box.addView(digits)
        box.addView(text("مبالغ در پایگاه داده تغییر نمی‌کنند؛ فقط شیوه نمایش آن‌ها عوض می‌شود. ورود مبالغ همچنان بر اساس تومان است.",13f))
        root.addView(box)
        root.addView(btn("ذخیره تنظیمات"){saveMoneySettings(unit.selectedItem.toString(),separator.isChecked,digits.selectedItemPosition==0);toast("تنظیمات ذخیره شد");showHome()})
        root.addView(btn("بازگشت بدون ذخیره"){showHome()})
    }
    private fun base(title:String, back:(()->Unit)?=null){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,12,16,10);layoutDirection=View.LAYOUT_DIRECTION_RTL;setBackgroundColor(bg)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        if(back!=null) head.addView(btn("‹") { back() },LinearLayout.LayoutParams(52,-2))
        head.addView(text(title,22f,green,true),LinearLayout.LayoutParams(0,-2,1f)); root.addView(head); setContentView(root)
    }
    private fun text(s:String,size:Float=15f,color:Int=0xff26332b.toInt(),bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);if(bold)typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL;setPadding(4,7,4,7)}
    private fun btn(s:String,action:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setOnClickListener{action()}}
    private fun field(hint:String,number:Boolean=false)=EditText(this).apply{this.hint=hint;textSize=15f;setSingleLine(true);layoutDirection=View.LAYOUT_DIRECTION_RTL;if(number)inputType=InputType.TYPE_CLASS_NUMBER}
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,8,12,8);setBackgroundColor(-1)}
    private fun line(parent:LinearLayout){parent.addView(View(this).apply{setBackgroundColor(0xffe1e7e2.toInt())},LinearLayout.LayoutParams(-1,1))}
    private fun showHome(){
        base("مدیریت زندگی ۲.۰")
        val s=db.summary(); val box=card().apply{setBackgroundColor(pale)}
        box.addView(text("خلاصه امور مالی",17f,green,true)); box.addView(text("دریافت: ${fmt(s.income)} ${moneyUnit()}     پرداخت: ${fmt(s.expense)} ${moneyUnit()}",15f)); box.addView(text("مانده نقدی: ${fmt(s.balance)} ${moneyUnit()}",17f,if(s.balance>=0)green else red,true)); box.addView(text("طلب از اشخاص: ${fmt(s.receivable)} ${moneyUnit()}   |   بدهی به اشخاص: ${fmt(s.payable)} ${moneyUnit()}",14f))
        root.addView(box); root.addView(text("انتخاب بخش",17f,green,true))
        root.addView(btn("📚 فهرست کامل ۱۰۲ شاخه و زیرشاخه‌ها") { showProgramCatalog() })
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; nav.addView(btn("امور مالی") { showFinance() },LinearLayout.LayoutParams(0,-2,1f)); nav.addView(btn("اشخاص و دفتر حساب") { showPeople() },LinearLayout.LayoutParams(0,-2,1f)); root.addView(nav)
        root.addView(btn("＋ ثبت دریافت / پرداخت / درآمد / هزینه") { financeEntryDialog() })
        root.addView(btn("＋ افزودن شخص") { addPersonDialog() })
        root.addView(btn("مدیریت صندوق‌ها و حساب‌ها") { showAccounts() })
        root.addView(btn("مدیریت اتصال اطلاعات اشخاص به بخش‌ها") { showPersonConnectionSettings() })
        root.addView(btn("سطل بازیابی تراکنش‌ها") { showTrash() })
        root.addView(btn("تنظیمات نمایش مبالغ") { showMoneySettings() })
        root.addView(btn("پشتیبان‌گیری و بازیابی اطلاعات") { showBackup() })
        root.addView(text("آخرین تراکنش‌ها",17f,green,true)); val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; sc.addView(list); root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.transactions(null,20); if(rows.isEmpty())list.addView(text("هنوز تراکنشی ثبت نشده است.")) else rows.forEach{list.addView(txCard(it,false))}
    }
    private fun catalogPrefs() = getSharedPreferences("catalog_customization", Context.MODE_PRIVATE)
    private fun catalogJson(key:String):JSONObject = try { JSONObject(catalogPrefs().getString(key,"{}") ?: "{}") } catch(_:Exception) { JSONObject() }
    private fun catalogArray(key:String):JSONArray = try { JSONArray(catalogPrefs().getString(key,"[]") ?: "[]") } catch(_:Exception) { JSONArray() }
    private fun saveCatalogJson(key:String,obj:JSONObject){catalogPrefs().edit().putString(key,obj.toString()).apply()}
    private fun featureParents():JSONObject = catalogJson("feature_parents")
    private fun favoriteIds():MutableSet<Int>{val a=catalogArray("favorite_ids");return (0 until a.length()).mapNotNull{a.optInt(it,-1).takeIf{x->x>0}}.toMutableSet()}
    private fun catalogFeatureName(id:Int,default:String):String = catalogJson("feature_names").optString(id.toString(),default)
    private fun catalogFeatureIcon(id:Int,default:String):String = catalogJson("feature_icons").optString(id.toString(),default)
    private fun catalogFeatureColor(id:Int):Int = catalogJson("feature_colors").optInt(id.toString(),0xff263b50.toInt())
    private fun sectionDisplayName(sec:ProgramCatalogSection):String = catalogJson("section_names").optString(sec.number.toString(),sec.title)
    private fun sectionDisplayIcon(sec:ProgramCatalogSection):String = catalogJson("section_icons").optString(sec.number.toString(),sec.icon)
    private fun sectionDisplayColor(sec:ProgramCatalogSection):Int = catalogJson("section_colors").optInt(sec.number.toString(),0xffd8e9f8.toInt())
    private fun catalogSectionsForUi():List<ProgramCatalogSection>{
        val parents=featureParents(); val fav=favoriteIds()
        val base=ProgramCatalog.sections.filter{it.number!=104}.map{sec->
            val fs=ProgramCatalog.sections.flatMap{owner->owner.features.filter{f->(parents.optInt(f.first.toString(),owner.number)==sec.number) && !fav.contains(f.first)}}
            sec.copy(title=sectionDisplayName(sec),icon=sectionDisplayIcon(sec),features=fs)
        }
        val favorites=ProgramCatalog.sections.flatMap{it.features}.filter{fav.contains(it.first)}
        val order=catalogArray("section_order");val rank=(0 until order.length()).associate{order.optInt(it) to it}
        return base.sortedBy{rank[it.number]?:Int.MAX_VALUE} + ProgramCatalogSection(104,"منتخب‌ها","⭐",favorites)
    }
    private fun setFeatureFavorite(id:Int,enabled:Boolean){
        val fav=favoriteIds(); if(enabled)fav.add(id) else fav.remove(id)
        val a=JSONArray();fav.sorted().forEach{a.put(it)};catalogPrefs().edit().putString("favorite_ids",a.toString()).apply()
        val parents=featureParents(); if(enabled){val previous=catalogJson("feature_previous_parent");previous.put(id.toString(),parents.optInt(id.toString(),ProgramCatalog.sections.firstOrNull{sec->sec.features.any{it.first==id}}?.number?:1));saveCatalogJson("feature_previous_parent",previous);parents.put(id.toString(),104)} else {val previous=catalogJson("feature_previous_parent");val original=previous.optInt(id.toString(),ProgramCatalog.sections.firstOrNull{sec->sec.features.any{it.first==id}}?.number?:1);parents.put(id.toString(),original);previous.remove(id.toString());saveCatalogJson("feature_previous_parent",previous)};saveCatalogJson("feature_parents",parents)
        catalogHistory("favorite",id,"${if(enabled)"منتخب‌ها" else "بخش اصلی"}")
    }
    private fun moveCatalogFeature(id:Int,destination:Int){
        val from=featureParents().optInt(id.toString(),ProgramCatalog.sections.firstOrNull{sec->sec.features.any{it.first==id}}?.number ?: 1)
        val parents=featureParents();if(destination==104){val previous=catalogJson("feature_previous_parent");previous.put(id.toString(),from);saveCatalogJson("feature_previous_parent",previous)};parents.put(id.toString(),destination);saveCatalogJson("feature_parents",parents)
        val fav=favoriteIds();if(destination==104)fav.add(id) else {fav.remove(id);val previous=catalogJson("feature_previous_parent");previous.remove(id.toString());saveCatalogJson("feature_previous_parent",previous)};val a=JSONArray();fav.sorted().forEach{a.put(it)};catalogPrefs().edit().putString("favorite_ids",a.toString()).apply()
        catalogHistory("move",id,"$from → $destination")
    }
    private fun catalogHistory(action:String,id:Int,detail:String){
        val a=catalogArray("history");a.put(JSONObject().put("action",action).put("feature_id",id).put("detail",detail).put("at",System.currentTimeMillis()));catalogPrefs().edit().putString("history",a.toString()).apply()
    }
    private fun editCatalogSection(sec:ProgramCatalogSection,refresh:()->Unit){
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8)}
        val name=EditText(this).apply{hint="نام نمایشی بخش";setText(sectionDisplayName(sec))};val icon=EditText(this).apply{hint="آیکون یا ایموجی";setText(sectionDisplayIcon(sec))}
        layout.addView(name);layout.addView(icon)
        val colors=linkedMapOf("آبی" to 0xffd8e9f8.toInt(),"سبز" to 0xffd9efdf.toInt(),"طلایی" to 0xffffedc2.toInt(),"بنفش" to 0xffe9ddf7.toInt(),"صورتی" to 0xffffe0e8.toInt(),"خاکستری" to 0xffe5e7eb.toInt())
        var chosen=sectionDisplayColor(sec);val colorButton=Button(this).apply{text="انتخاب رنگ";isAllCaps=false;setOnClickListener{AlertDialog.Builder(this@MainActivity).setTitle("رنگ بخش").setItems(colors.keys.toTypedArray()){_,i->chosen=colors.values.elementAt(i);setBackgroundColor(chosen)}.show()}}
        layout.addView(colorButton)
        AlertDialog.Builder(this).setTitle("شخصی‌سازی بخش ${sec.number}").setView(layout).setNegativeButton("انصراف",null).setNeutralButton("بازگشت به پیش‌فرض"){_,_->listOf("section_names","section_icons","section_colors").forEach{key->val o=catalogJson(key);o.remove(sec.number.toString());saveCatalogJson(key,o)};refresh()}.setPositiveButton("پیش‌نمایش"){_,_->
            val n=name.text.toString().trim();val ic=icon.text.toString().trim();if(n.isEmpty()||ic.isEmpty()){toast("نام و آیکون نباید خالی باشند");return@setPositiveButton}
            AlertDialog.Builder(this).setTitle("پیش‌نمایش تغییرات").setMessage("$ic  $n\nرنگ انتخابی: $chosen\nشناسه بخش ${sec.number} بدون تغییر می‌ماند.").setNegativeButton("بازگشت به ویرایش",null).setPositiveButton("تأیید و ذخیره"){_,_->saveCatalogJson("section_names",catalogJson("section_names").put(sec.number.toString(),n));saveCatalogJson("section_icons",catalogJson("section_icons").put(sec.number.toString(),ic));saveCatalogJson("section_colors",catalogJson("section_colors").put(sec.number.toString(),chosen));catalogHistory("section_style",sec.number,"$n / $ic / $chosen");refresh()}.show()
        }.show()
    }
    private fun editCatalogFeature(id:Int,defaultName:String,defaultIcon:String,refresh:()->Unit){
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8)}
        val name=EditText(this).apply{hint="نام نمایشی قابلیت";setText(catalogFeatureName(id,defaultName))};val icon=EditText(this).apply{hint="آیکون";setText(catalogFeatureIcon(id,defaultIcon))};layout.addView(name);layout.addView(icon)
        val colors=linkedMapOf("آبی" to 0xff263b50.toInt(),"سبز" to 0xff247447.toInt(),"قرمز" to 0xffa83232.toInt(),"بنفش" to 0xff7040a0.toInt(),"نارنجی" to 0xffa65c12.toInt(),"خاکستری" to 0xff60656d.toInt());var chosen=catalogFeatureColor(id)
        val color=Button(this).apply{text="انتخاب رنگ قابلیت";isAllCaps=false;setOnClickListener{AlertDialog.Builder(this@MainActivity).setTitle("رنگ قابلیت").setItems(colors.keys.toTypedArray()){_,i->chosen=colors.values.elementAt(i);setTextColor(chosen)}.show()}};layout.addView(color)
        AlertDialog.Builder(this).setTitle("تنظیم قابلیت شماره $id").setView(layout).setNegativeButton("انصراف",null).setNeutralButton("بازگشت به پیش‌فرض"){_,_->listOf("feature_names","feature_icons","feature_colors").forEach{key->val o=catalogJson(key);o.remove(id.toString());saveCatalogJson(key,o)};refresh()}.setPositiveButton("پیش‌نمایش"){_,_->if(name.text.toString().isBlank()||icon.text.toString().isBlank()){toast("نام و آیکون لازم است");return@setPositiveButton};val n=name.text.toString().trim();val ic=icon.text.toString().trim();AlertDialog.Builder(this).setTitle("پیش‌نمایش قابلیت").setMessage("$ic  $id. $n\nرنگ: $chosen\nشناسه قابلیت ثابت می‌ماند.").setNegativeButton("بازگشت به ویرایش",null).setPositiveButton("تأیید و ذخیره"){_,_->saveCatalogJson("feature_names",catalogJson("feature_names").put(id.toString(),n));saveCatalogJson("feature_icons",catalogJson("feature_icons").put(id.toString(),ic));saveCatalogJson("feature_colors",catalogJson("feature_colors").put(id.toString(),chosen));catalogHistory("feature_style",id,"$n / $ic / $chosen");refresh()}.show()}.show()
    }
    private fun showMoveFeatureDialog(id:Int,refresh:()->Unit){
        val sections=catalogSectionsForUi().filter{it.number!=104};val labels=sections.map{"${it.number}. ${it.title}"}.toTypedArray()
        AlertDialog.Builder(this).setTitle("انتقال قابلیت $id به بخش مقصد").setItems(labels){_,which->val dest=sections[which];AlertDialog.Builder(this).setMessage("قابلیت با شناسه ثابت $id از بخش فعلی به «${dest.title}» منتقل شود؟ داده و شناسه تغییر نمی‌کند.").setNegativeButton("انصراف",null).setPositiveButton("تأیید انتقال"){_,_->moveCatalogFeature(id,dest.number);refresh()}.show()}.setNegativeButton("انصراف",null).show()
    }
    private fun showProgramCatalog(query:String="", expanded:MutableSet<Int> = mutableSetOf()){
        base("فهرست کامل امکانات برنامه"){showHome()}
        root.setBackgroundColor(0xffeaf3fb.toInt())
        root.addView(text("۱۰۲ شاخه فعال • زیرشاخه‌های ثبت‌شده • شناسه‌های پایه ۱ تا ۵۲۵ ثابت هستند",13f,0xff365b7d.toInt(),true))
        root.addView(btn("⚙️ مدیریت ظاهر و چیدمان بخش‌ها") { showCatalogManagement() })
        val search=field("جست‌وجوی نام بخش یا قابلیت");search.setText(query);root.addView(search)
        root.addView(btn("🔎 جست‌وجو") { val q=search.text.toString().trim();val matches=catalogSectionsForUi().filter{sec->q.isNotEmpty()&&(sec.title.contains(q,true)||sec.features.any{catalogFeatureName(it.first,it.second).contains(q,true)})}.map{it.number}.toMutableSet();showProgramCatalog(q,matches) })
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};actions.addView(btn("بازکردن همه"){showProgramCatalog(query,catalogSectionsForUi().map{it.number}.toMutableSet())},LinearLayout.LayoutParams(0,-2,1f));actions.addView(btn("بستن همه"){showProgramCatalog(query,mutableSetOf())},LinearLayout.LayoutParams(0,-2,1f));root.addView(actions)
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,4,0,12)};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val q=query.trim();val sections=catalogSectionsForUi();val matches=sections.filter{sec->q.isEmpty()||sec.title.contains(q,true)||sec.features.any{catalogFeatureName(it.first,it.second).contains(q,true)}}
        if(matches.isEmpty())list.addView(text("موردی با این عبارت پیدا نشد.",14f,red,true))
        matches.forEach{sec->
            val opened=expanded.contains(sec.number);val card=card().apply{setBackgroundColor(0xfff8fbff.toInt())}
            val header=Button(this).apply{text="${sec.icon}  بخش ${sec.number}. ${sec.title}   ${if(opened)"⌃" else "⌄"}";isAllCaps=false;textSize=15f;gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL;setTextColor(0xff234d72.toInt());setBackgroundColor(if(sec.number==104)0xffffedc2.toInt() else sectionDisplayColor(ProgramCatalog.sections.firstOrNull{it.number==sec.number}?:sec));setOnClickListener{val next=expanded.toMutableSet();if(opened)next.remove(sec.number)else next.add(sec.number);showProgramCatalog(query,next)}}
            card.addView(header)
            if(opened){
                if(sec.number!=104)card.addView(btn("تنظیم نام، آیکون و رنگ این بخش"){editCatalogSection(sec){showProgramCatalog(query,expanded)}})
                if(sec.features.isEmpty())card.addView(text("فعلاً خالی است؛ قابلیت‌های پرکاربرد را خودتان به منتخب‌ها منتقل کنید.",13f,0xff54718c.toInt()))
                val titleMatches=q.isNotEmpty()&&sec.title.contains(q,true);val shown=if(q.isEmpty()||titleMatches)sec.features else sec.features.filter{catalogFeatureName(it.first,it.second).contains(q,true)}
                shown.forEach{feature->
                    val id=feature.first;val defaultIcon=featureIcon(feature.second);val label=catalogFeatureName(id,feature.second);val icon=catalogFeatureIcon(id,defaultIcon)
                    val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,6,8,6)}
                    row.addView(text("$icon  $id. $label",13f,catalogFeatureColor(id)))
                    val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
                    controls.addView(btn(if(sec.number==104)"↩ بازگرداندن" else "⭐ منتخب‌ها"){if(sec.number==104)setFeatureFavorite(id,false) else setFeatureFavorite(id,true);showProgramCatalog(query,expanded)},LinearLayout.LayoutParams(0,-2,1f))
                    controls.addView(btn("⇄ انتقال"){showMoveFeatureDialog(id){showProgramCatalog(query,expanded)}},LinearLayout.LayoutParams(0,-2,1f))
                    controls.addView(btn("✏️ تنظیم"){editCatalogFeature(id,feature.second,defaultIcon){showProgramCatalog(query,expanded)}},LinearLayout.LayoutParams(0,-2,1f))
                    row.addView(controls);card.addView(row);line(card)
                }
                card.addView(text("${shown.size} قابلیت",11f,0xff54718c.toInt()))
            }else if(q.isNotEmpty()){val count=if(sec.title.contains(q,true))sec.features.size else sec.features.count{catalogFeatureName(it.first,it.second).contains(q,true)};card.addView(text("$count نتیجه مرتبط؛ برای نمایش لمس کن",11f,0xff54718c.toInt()))}
            list.addView(card);line(list)
        }
        root.addView(btn("مشاهده تاریخچه تغییرات ساختاری"){showCatalogHistory()});root.addView(btn("بازگشت به صفحه اصلی"){showHome()})
    }
    private fun showCatalogManagement(){
        base("مدیریت ساختار و ظاهر بخش‌ها"){showProgramCatalog()}
        root.addView(text("تغییرات فقط روی نام و نمایش کاتالوگ اثر دارد؛ شناسه قابلیت‌ها ثابت می‌ماند.",13f))
        val ordered=catalogSectionsForUi().filter{it.number!=104}.toMutableList();ordered.forEachIndexed{index,sec->val c=card();c.addView(text("${sec.icon} بخش ${sec.number}: ${sec.title}",15f,green,true));c.addView(btn("شخصی‌سازی این بخش"){editCatalogSection(sec){showCatalogManagement()}});val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};controls.addView(btn("↑ بالاتر"){if(index>0){val list=ordered.map{it.number}.toMutableList();val x=list.removeAt(index);list.add(index-1,x);val a=JSONArray();list.forEach{a.put(it)};catalogPrefs().edit().putString("section_order",a.toString()).apply();catalogHistory("section_order",sec.number,"انتقال به جایگاه ${index}");showCatalogManagement()}} ,LinearLayout.LayoutParams(0,-2,1f));controls.addView(btn("↓ پایین‌تر"){if(index<ordered.lastIndex){val list=ordered.map{it.number}.toMutableList();val x=list.removeAt(index);list.add(index+1,x);val a=JSONArray();list.forEach{a.put(it)};catalogPrefs().edit().putString("section_order",a.toString()).apply();catalogHistory("section_order",sec.number,"انتقال به جایگاه ${index+2}");showCatalogManagement()}},LinearLayout.LayoutParams(0,-2,1f));c.addView(controls);root.addView(c)}
        root.addView(btn("بازگشت به فهرست"){showProgramCatalog()})
    }
    private fun showCatalogHistory(){
        base("تاریخچه تغییرات کاتالوگ"){showProgramCatalog()};val a=catalogArray("history");if(a.length()==0)root.addView(text("هنوز تغییری ثبت نشده است.")) else for(i in a.length()-1 downTo 0){val o=a.optJSONObject(i)?:continue;root.addView(text("${Date(o.optLong("at"))} | ${o.optString("action")} | شناسه ${o.optInt("feature_id")} | ${o.optString("detail")}",13f))};root.addView(btn("بازگشت"){showProgramCatalog()})
    }

    private fun showFinance(){
        base("امور مالی و حسابداری")
        val s=db.summary(); val b=card().apply{setBackgroundColor(pale)}; b.addView(text("دریافت‌ها: ${fmt(s.income)} ${moneyUnit()}",16f,green,true)); b.addView(text("پرداخت‌ها: ${fmt(s.expense)} ${moneyUnit()}",16f,red,true)); b.addView(text("مانده نقدی: ${fmt(s.balance)} ${moneyUnit()}",17f,green,true)); root.addView(b)
        root.addView(btn("＋ ثبت دریافت وجه") { financeEntryDialog("دریافت وجه") }); root.addView(btn("＋ ثبت پرداخت وجه") { financeEntryDialog("پرداخت وجه") }); root.addView(btn("＋ ثبت درآمد مستقل") { financeEntryDialog("درآمد") }); root.addView(btn("＋ ثبت هزینه مستقل") { financeEntryDialog("هزینه") }); root.addView(btn("مدیریت صندوق‌ها و حساب‌ها") { showAccounts() }); root.addView(btn("چک و سفته و سررسیدها") { showInstruments() }); root.addView(btn("مدیریت اقساط") { showInstallments() }); root.addView(btn("مغایرت‌گیری و سوابق آن") { reconcileDialog() }); root.addView(btn("گزارش بازه‌ای روزانه / ماهانه / سالانه") { reportDialog() }); root.addView(btn("بازگشت به خانه") { showHome() })
        root.addView(text("دفتر گردش نقدی",17f,green,true)); val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.transactions().filter{it.kind in listOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")}; if(rows.isEmpty())list.addView(text("گردش نقدی خالی است.")) else rows.forEach{list.addView(txCard(it,true))}
    }
    private fun showPeople(q:String="", filter:Int=peopleFilter, sort:Int=peopleSort, groupFilter:String?=null){
        peopleFilter=filter.coerceIn(0,3); peopleSort=sort.coerceIn(0,3)
        getSharedPreferences("people_list",Context.MODE_PRIVATE).edit().putInt("filter",peopleFilter).putInt("sort",peopleSort).apply()
        base("اشخاص و دفتر حساب")
        root.addView(btn("＋ افزودن شخص جدید") { addPersonDialog() }); root.addView(btn("پرونده‌های بایگانی‌شده") { showArchivedPeople() })
        val search=field("جست‌وجوی نام، تلفن، کد ملی یا برچسب");search.setText(q);root.addView(search);root.addView(btn("جست‌وجو") { showPeople(search.text.toString(),peopleFilter,peopleSort) })
        val filterNames=arrayOf("همه اشخاص","فقط طلبکاران","فقط بدهکاران","فقط تسویه‌شده‌ها")
        val sortNames=arrayOf("نام: الف تا ی","بیشترین طلب","بیشترین بدهی","بیشترین مانده خالص")
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        controls.addView(btn("فیلتر: ${filterNames[peopleFilter]}") { peopleFilterDialog(q) },LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(btn("مرتب‌سازی: ${sortNames[peopleSort]}") { peopleSortDialog(q) },LinearLayout.LayoutParams(0,-2,1f))
        root.addView(controls)
        root.addView(btn("گروه اشخاص: ${groupFilter ?: "همه گروه‌ها"}") { peopleGroupDialog(q,groupFilter) })
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val all=db.people(q).let { rows -> if(groupFilter==null) rows else rows.filter{it.groupName==groupFilter} }
        val filtered=when(peopleFilter){1->all.filter{it.receivable>0};2->all.filter{it.payable>0};3->all.filter{it.balance==0L};else->all}
        val people=when(peopleSort){1->filtered.sortedWith(compareByDescending<Person>{it.receivable}.thenBy{it.name});2->filtered.sortedWith(compareByDescending<Person>{it.payable}.thenBy{it.name});3->filtered.sortedWith(compareByDescending<Person>{kotlin.math.abs(it.balance)}.thenBy{it.name});else->filtered.sortedBy{it.name}}
        list.addView(text("${people.size} شخص از ${all.size} نتیجه جست‌وجو",12f))
        if(people.isEmpty()) list.addView(text(if(all.isEmpty())"شخصی با این مشخصات ثبت نشده است." else "در این فیلتر شخصی پیدا نشد.")) else people.forEach { p ->
            val c=card()
            val heading=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
            if(p.photoData.isNotBlank()) heading.addView(personPhotoView(p.photoData,52),LinearLayout.LayoutParams(52,52))
            heading.addView(text(p.name,18f,green,true),LinearLayout.LayoutParams(0,-2,1f))
            heading.addView(btn("⚙ نمایش بر اساس") { personDisplaySettings(p) })
            c.addView(heading)
            when(db.personDisplayMode(p.id)) {
                1 -> c.addView(text("طلب: ${fmt(p.receivable)} ${moneyUnit()}",15f,green,true))
                2 -> c.addView(text("بدهی: ${fmt(p.payable)} ${moneyUnit()}",15f,red,true))
                3 -> c.addView(text(netBalanceLabel(p),15f,if(p.balance<0)red else green,true))
                4 -> {
                    c.addView(text("طلب: ${fmt(p.receivable)} ${moneyUnit()}",14f,green,true))
                    c.addView(text("بدهی: ${fmt(p.payable)} ${moneyUnit()}",14f,red,true))
                    c.addView(text(netBalanceLabel(p),15f,if(p.balance<0)red else green,true))
                }
                5 -> c.addView(text("طلب ${fmt(p.receivable)}  |  بدهی ${fmt(p.payable)}  |  ${if(p.balance<0)"بدهکار" else if(p.balance>0)"طلبکار" else "تسویه"} ${fmt(kotlin.math.abs(p.balance))} ${moneyUnit()}",13f))
            }
            if(p.groupName.isNotBlank()) c.addView(text("گروه: ${p.groupName}",12f,0xff52635a.toInt()))
            if(p.roles.isNotBlank() || p.relation.isNotBlank()) c.addView(text("نقش‌ها: ${(listOf(p.relation)+p.roles.split(',')).filter{it.isNotBlank()}.distinct().joinToString("، ")}",12f,0xff52635a.toInt()))
            if(p.phone.isNotBlank()) c.addView(text(p.phone,13f))
            c.addView(btn("پرونده و گردش حساب") { personPage(p.id) })
            list.addView(c); line(list)
        }
        root.addView(btn("بازگشت به خانه") { showHome() })
    }
    private fun peopleGroupDialog(q:String,current:String?){
        val options=arrayOf("همه گروه‌ها","اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده")
        val selected=options.indexOf(current ?: "همه گروه‌ها").coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("گروه‌بندی اشخاص").setSingleChoiceItems(options,selected){dialog,which->dialog.dismiss();showPeople(q,peopleFilter,peopleSort,if(which==0)null else options[which])}.setNegativeButton("انصراف",null).show()
    }
    private fun peopleFilterDialog(q:String){
        val options=arrayOf("همه اشخاص","فقط طلبکاران (مانده طلب مثبت)","فقط بدهکاران (مانده بدهی مثبت)","فقط تسویه‌شده‌ها (مانده صفر)")
        AlertDialog.Builder(this).setTitle("فیلتر فهرست اشخاص").setSingleChoiceItems(options,peopleFilter){dialog,which->dialog.dismiss();showPeople(q,which,peopleSort)}.setNegativeButton("انصراف",null).show()
    }
    private fun peopleSortDialog(q:String){
        val options=arrayOf("نام: الف تا ی","بیشترین طلب","بیشترین بدهی","بیشترین مانده خالص")
        AlertDialog.Builder(this).setTitle("مرتب‌سازی اشخاص").setSingleChoiceItems(options,peopleSort){dialog,which->dialog.dismiss();showPeople(q,peopleFilter,which)}.setNegativeButton("انصراف",null).show()
    }
    private fun netBalanceLabel(p:Person):String = when {
        p.balance>0 -> "مانده خالص: ${fmt(p.balance)} ${moneyUnit()} طلب"
        p.balance<0 -> "مانده خالص: ${fmt(-p.balance)} ${moneyUnit()} بدهی"
        else -> "مانده خالص: تسویه"
    }
    private fun personDisplaySettings(p:Person) {
        val options=arrayOf(
            "۱. فقط طلب",
            "۲. فقط بدهی",
            "۳. فقط مانده خالص",
            "۴. طلب + بدهی + مانده خالص",
            "۵. نمایش فشرده در یک خط"
        )
        val current=db.personDisplayMode(p.id)-1
        AlertDialog.Builder(this).setTitle("نمایش بر اساس • ${p.name}")
            .setSingleChoiceItems(options,current) { dialog,which ->
                db.setPersonDisplayMode(p.id,which+1)
                dialog.dismiss()
                showPeople()
            }
            .setNegativeButton("انصراف",null).show()
    }
    private fun decodePersonPhoto(data:String,targetSize:Int):Bitmap? {
        return try {
            val bytes=Base64.decode(data,Base64.DEFAULT)
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds)
            var sample=1
            while(bounds.outWidth/sample>targetSize*2 || bounds.outHeight/sample>targetSize*2) sample*=2
            val options=BitmapFactory.Options().apply{inSampleSize=sample}
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,options)
        } catch(_:Exception){null}
    }
    private fun personPhotoView(data:String,size:Int):ImageView {
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(pale) }
        image.setImageBitmap(decodePersonPhoto(data,size))
        image.layoutParams=LinearLayout.LayoutParams(size,size)
        return image
    }
    private fun encodePersonPhoto(bitmap:Bitmap):String {
        val maxSide=900
        val scale=minOf(1f,maxSide.toFloat()/maxOf(bitmap.width,bitmap.height))
        val resized=if(scale<1f) Bitmap.createScaledBitmap(bitmap,(bitmap.width*scale).toInt().coerceAtLeast(1),(bitmap.height*scale).toInt().coerceAtLeast(1),true) else bitmap
        val bytes=ByteArrayOutputStream();resized.compress(Bitmap.CompressFormat.JPEG,82,bytes)
        if(resized!==bitmap) resized.recycle()
        return Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP)
    }
    private fun refreshActivePhoto(){
        val data=activePersonPhotoData
        activePersonPhotoPreview?.setImageBitmap(if(data.isNotBlank()) decodePersonPhoto(data,112) else null)
    }
    private fun savePersonPhoto(uri:Uri):String {
        val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
        contentResolver.openInputStream(uri).use { input -> if(input==null) throw IllegalStateException("خواندن عکس ممکن نیست"); BitmapFactory.decodeStream(input,null,bounds) }
        if(bounds.outWidth<=0 || bounds.outHeight<=0) throw IllegalArgumentException("فایل عکس معتبر نیست")
        var sample=1
        while(bounds.outWidth/sample>1800 || bounds.outHeight/sample>1800) sample*=2
        val options=BitmapFactory.Options().apply{inSampleSize=sample}
        val bitmap=contentResolver.openInputStream(uri).use { input -> if(input==null) throw IllegalStateException("خواندن عکس ممکن نیست"); BitmapFactory.decodeStream(input,null,options) ?: throw IllegalArgumentException("خواندن عکس ناموفق بود") }
        return encodePersonPhoto(bitmap)
    }
    private fun saveCameraPhoto(bitmap:Bitmap):String = encodePersonPhoto(bitmap)
    private fun personPhotoControls(box:LinearLayout){
        val preview=ImageView(this).apply { layoutParams=LinearLayout.LayoutParams(112,112).apply{gravity=Gravity.CENTER}; scaleType=ImageView.ScaleType.CENTER_CROP; setBackgroundColor(pale) }
        activePersonPhotoPreview=preview; box.addView(preview)
        box.addView(btn("انتخاب از مخاطبین گوشی") {
            try { startActivityForResult(Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI),requestPickContact) }
            catch(e:Exception){toast("دسترسی به مخاطبین گوشی ممکن نیست")}
        })
        box.addView(btn("گرفتن عکس با دوربین") {
            try { startActivityForResult(Intent("android.media.action.IMAGE_CAPTURE"),requestTakePersonPhoto) }
            catch(e:Exception){toast("دوربین در دسترس نیست")}
        })
        box.addView(btn("بارگذاری عکس از گالری یا فایل‌ها") {
            try { val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"};startActivityForResult(intent,requestChoosePersonPhoto) }
            catch(e:Exception){toast("انتخاب عکس ممکن نیست")}
        })
    }
    private val connectionSections= linkedMapOf("finance" to "امور مالی و حسابداری","ledger" to "دفتر حساب","invoices" to "فاکتورها و صورتحساب‌ها","sales" to "خرید و فروش","contracts" to "قراردادها و تعهدات","instruments" to "چک، سفته و اقساط","bank_accounts" to "حساب‌های بانکی","family" to "خانواده و بستگان","friends" to "دوستان و آشنایان","reminders" to "یادآوری‌ها و پیگیری‌ها","documents" to "اسناد و مدارک","other" to "سایر بخش‌ها")
    private fun sectionTitle(key:String)=connectionSections[key] ?: key
    private fun showPersonConnectionSettings(){
        base("مدیریت اتصال اطلاعات اشخاص"){showHome()}
        root.addView(text("یک پرونده مرکزی برای هر شخص؛ بخش‌ها از همان پرونده اطلاعات موردنیاز را فراخوانی می‌کنند.",13f))
        connectionSections.forEach { (key,title) ->
            val c=card();c.addView(text(title,16f,green,true))
            val settings=db.sectionFieldSettings(key)
            c.addView(text("فیلدهای قابل نمایش: ${settings.count{it.third}} از ${settings.size}",12f))
            c.addView(btn("تنظیم فیلدهای این بخش") { editSectionFields(key) })
            c.addView(btn("مدیریت اشخاص متصل (${db.sectionPeople(key).size})") { showSectionPeople(key) })
            root.addView(c);line(root)
        }
        root.addView(btn("بازگشت به صفحه اصلی"){showHome()})
    }
    private fun showSectionPeople(sectionKey:String){
        base("اشخاص • ${sectionTitle(sectionKey)}"){showPersonConnectionSettings()}
        root.addView(text("این فهرست از بانک مرکزی اشخاص خوانده می‌شود. هر شخص فقط با شناسه ثابت خودش به این بخش متصل می‌شود.",13f))
        root.addView(btn("＋ اتصال شخص موجود از بانک مرکزی") { chooseCentralPersonForSection(sectionKey) })
        val linked=db.sectionPeople(sectionKey)
        if(linked.isEmpty()) root.addView(text("هنوز شخصی به این بخش متصل نشده است."))
        linked.forEach { item ->
            val c=card();c.addView(text(item.second,15f,green,true));c.addView(btn("بازکردن پرونده مرکزی شخص") { personPage(item.first) });root.addView(c);line(root)
        }
        root.addView(btn("بازگشت به مدیریت اتصال‌ها") { showPersonConnectionSettings() })
    }
    private fun chooseCentralPersonForSection(sectionKey:String){
        val people=db.people()
        if(people.isEmpty()){toast("ابتدا شخص را در بانک مرکزی اشخاص ثبت کنید");return}
        val labels=people.map { "${it.name}  •  ${it.phone}" }
        AlertDialog.Builder(this).setTitle("انتخاب از بانک مرکزی اشخاص").setItems(labels.toTypedArray()){_,which->
            val p=people[which]
            if(db.hasPersonSectionLink(p.id,sectionKey)){toast("این شخص قبلاً به این بخش متصل شده است");return@setItems}
            val role=field("نقش شخص در این بخش؛ مثلاً خریدار یا فروشنده")
            val note=field("توضیحات تکمیلی")
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0);addView(text("شخص انتخاب‌شده: ${p.name}",14f,green,true));addView(role);addView(note)}
            AlertDialog.Builder(this).setTitle("ثبت اتصال به ${sectionTitle(sectionKey)}").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ثبت اتصال"){_,_->
                if(db.hasPersonSectionLink(p.id,sectionKey)){toast("این اتصال قبلاً ثبت شده است")}else{db.addPersonSectionLink(p.id,sectionKey,role.text.toString().trim(),note.text.toString().trim());toast("اتصال شخص با شناسه مرکزی ثبت شد");showSectionPeople(sectionKey)}
            }.show()
        }.setNegativeButton("انصراف",null).show()
    }
    private fun editSectionFields(sectionKey:String){
        base("تنظیم فیلدها • ${sectionTitle(sectionKey)}"){showPersonConnectionSettings()}
        root.addView(text("انتخاب کن کدام مشخصات از پرونده مرکزی در این بخش نمایش داده شود. تغییرات فقط تنظیم نمایش هستند و اطلاعات اصلی شخص را حذف نمی‌کنند.",13f))
        val settings=db.sectionFieldSettings(sectionKey)
        settings.forEach { item ->
            val check=CheckBox(this).apply{text=item.second;isChecked=item.third;setTextSize(15f);setOnCheckedChangeListener{_,checked->db.setSectionFieldVisible(sectionKey,item.first,checked)}}
            root.addView(check);line(root)
        }
        root.addView(btn("بازگشت به فهرست بخش‌ها"){showPersonConnectionSettings()})
    }
    private fun addPersonSectionLinkDialog(p:Person){
        val keys=connectionSections.keys.toList();val labels=keys.map{sectionTitle(it)}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val section=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,labels)}
        val role=field("نقش یا نوع ارتباط در این بخش؛ مثلاً خریدار، فروشنده، طرف قرارداد")
        val note=field("توضیحات تکمیلی")
        box.addView(text("بخش مقصد"));box.addView(section);box.addView(role);box.addView(note)
        AlertDialog.Builder(this).setTitle("اتصال پرونده ${p.name}").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ثبت اتصال"){_,_->
            db.addPersonSectionLink(p.id,keys[section.selectedItemPosition],role.text.toString().trim(),note.text.toString().trim());personPage(p.id)
        }.show()
    }
    private fun addPersonDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val n=field("نام و نام خانوادگی");val father=field("نام پدر");val ph=field("شماره تماس");val second=field("شماره تماس دوم");val landline=field("تلفن ثابت");val email=field("پست الکترونیکی");val rel=field("نوع ارتباط اصلی");val roles=field("نقش‌های دیگر با ویرگول؛ مشتری، فروشنده، دوست...");val group=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده"))};val ad=field("نشانی کامل");val note=field("توضیحات");val nid=field("کد ملی",true);val birth=field("تاریخ تولد شمسی (مثلاً ۱۳۶۵/۰۵/۲۰)");val job=field("شغل");val workplace=field("محل کار");val source=field("منبع آشنایی");val tags=field("برچسب‌ها با ویرگول: مشتری، فروشنده...");val location=field("موقعیت مکانی یا نشانی تکمیلی");val rating=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("عادی","معتبر","نیازمند احتیاط","نامشخص"))}
        activePersonName=n;activePersonPhone=ph;activePersonPhotoData=""
        personPhotoControls(box);box.addView(text("گروه اصلی"));box.addView(group);listOf(n,father,ph,second,landline,email,nid,birth,rel,roles,ad,location,job,workplace,source,tags,note).forEach{box.addView(it)};box.addView(text("درجه اعتبار"));box.addView(rating)
        val formScroll=ScrollView(this);formScroll.addView(box)
        AlertDialog.Builder(this).setTitle("افزودن شخص").setView(formScroll).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->
            if(n.text.toString().trim().isEmpty()) toast("نام را وارد کنید") else {val duplicates=db.duplicatePeople(n.text.toString().trim(),ph.text.toString().trim(),nid.text.toString().trim());if(duplicates.isNotEmpty()){AlertDialog.Builder(this).setTitle("احتمال شخص تکراری").setMessage(duplicates.joinToString("\n")+"\nآیا با وجود این شباهت ثبت شود؟").setNegativeButton("بازبینی",null).setPositiveButton("ثبت به هر حال"){_,_->saveNewPerson(n,ph,ad,rel,note,second,nid,birth,job,workplace,source,rating,tags,location,father,landline,email,group,roles)}.show()}else saveNewPerson(n,ph,ad,rel,note,second,nid,birth,job,workplace,source,rating,tags,location,father,landline,email,group,roles)}
        }.show()
    }
    private fun saveNewPerson(n:EditText,ph:EditText,ad:EditText,rel:EditText,note:EditText,second:EditText,nid:EditText,birth:EditText,job:EditText,workplace:EditText,source:EditText,rating:Spinner,tags:EditText,location:EditText,father:EditText,landline:EditText,email:EditText,group:Spinner,roles:EditText){
        val id=db.addPerson(n.text.toString().trim(),ph.text.toString().trim(),ad.text.toString().trim(),rel.text.toString().trim(),note.text.toString().trim(),activePersonPhotoData)
        db.updatePersonExtra(id,second.text.toString().trim(),nid.text.toString().trim(),birth.text.toString().trim(),job.text.toString().trim(),workplace.text.toString().trim(),source.text.toString().trim(),rating.selectedItem.toString(),tags.text.toString().trim(),location.text.toString().trim(),father.text.toString().trim(),landline.text.toString().trim(),email.text.toString().trim(),group.selectedItem.toString(),roles.text.toString().trim())
        showPeople()
    }
    private fun personPage(id:Long){
        val p=db.people().firstOrNull{it.id==id}?:return showPeople()
        val opening=db.personOpeningBalance(id)
        base(p.name){showPeople()}
        if(p.photoData.isNotBlank()) root.addView(personPhotoView(p.photoData,120),LinearLayout.LayoutParams(120,120).apply{gravity=Gravity.CENTER})
        val c=card().apply{setBackgroundColor(pale)}
        c.addView(text("طلب از شخص: ${fmt(p.receivable)} ${moneyUnit()}",15f,green,true))
        c.addView(text("بدهی به شخص: ${fmt(p.payable)} ${moneyUnit()}",15f,red,true))
        c.addView(text(if(p.balance>0)"مانده خالص: ${fmt(p.balance)} ${moneyUnit()} طلب" else if(p.balance<0)"مانده خالص: ${fmt(-p.balance)} ${moneyUnit()} بدهی" else "مانده خالص: تسویه",17f,green,true))
        root.addView(c)
        val details=card();details.addView(text("اطلاعات پرونده",16f,green,true));listOf("نام پدر: ${p.fatherName}","شماره تماس: ${p.phone}","شماره دوم: ${p.secondPhone}","تلفن ثابت: ${p.landline}","ایمیل: ${p.email}","گروه اصلی: ${p.groupName}","نقش‌ها: ${p.roles}","کد ملی: ${p.nationalId}","تاریخ تولد: ${p.birthDate}","نوع ارتباط: ${p.relation}","شغل: ${p.job}","محل کار: ${p.workplace}","نشانی: ${p.address}","موقعیت: ${p.location}","منبع آشنایی: ${p.source}","اعتبار: ${p.rating}","برچسب‌ها: ${p.tags}","یادداشت: ${p.notes}").filter{it.substringAfter(": ").isNotBlank()}.forEach{details.addView(text(it,13f))};root.addView(details)
        val links=db.personSectionLinks(p.id)
        val linksCard=card();linksCard.addView(text("اتصال این پرونده به بخش‌های برنامه",16f,green,true))
        if(links.isEmpty()) linksCard.addView(text("هنوز اتصال اختصاصی به بخش‌های دیگر ثبت نشده است.",12f)) else links.forEach { link -> linksCard.addView(text("${sectionTitle(link.first)} • ${link.second}",13f)) }
        linksCard.addView(btn("＋ تعریف اتصال به یک بخش") { addPersonSectionLinkDialog(p) });root.addView(linksCard)
        root.addView(btn("＋ افزودن مدرک یا تصویر به پرونده") { addPersonDocument(p) })
        root.addView(btn("مشاهده مدارک (${db.documents(p.id).size})") { showPersonDocuments(p) })
        root.addView(btn("＋ ثبت یادآوری تماس یا پیگیری") { addPersonReminder(p) })
        db.reminders(p.id).forEach { rem -> root.addView(btn("یادآوری: ${rem.second} • ${jalali(rem.third)} (انجام شد)") { db.completeReminder(rem.first);personPage(p.id) }) }
        root.addView(btn("اشتراک‌گذاری خلاصه پرونده") { sharePerson(p) })
        root.addView(btn("تهیه گزارش PDF پرونده") { exportPersonPdf(p) })
        if(opening!=null) {
            val openingCard=card()
            openingCard.addView(text("مانده اول دوره فعال: ${fmt(opening.amount)} ${moneyUnit()} ${opening.balanceType}",15f,green,true))
            openingCard.addView(text("تاریخ مبنا: ${jalali(opening.baseDate)}",13f))
            if(opening.description.isNotBlank()) openingCard.addView(text("توضیحات: ${opening.description}",13f))
            root.addView(openingCard)
        } else {
            root.addView(text("برای این شخص هنوز مانده اول دوره ثبت نشده است.",13f))
        }
        root.addView(btn(if(opening==null)"ثبت مانده اول دوره" else "ثبت / اصلاح مانده اول دوره") { personOpeningDialog(p,opening) })
        root.addView(btn("＋ ثبت عملیات حساب این شخص") { personEntryDialog(p) })
        root.addView(btn("ویرایش مشخصات شخص") { editPersonInfo(p) })
        root.addView(btn("بایگانی پرونده شخص") { archivePersonConfirm(p) })
        root.addView(text("گردش حساب",17f,green,true))
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.transactions(id)
        if(rows.isEmpty()) list.addView(text("گردش حساب خالی است."))
        else if(opening==null) rows.forEach{list.addView(txCard(it,true))}
        else {
            val currentRows=rows.filter{it.createdAt>=opening.baseDate}
            val historicalRows=rows.filter{it.createdAt<opening.baseDate}
            if(currentRows.isEmpty()) list.addView(text("از تاریخ مبنا تاکنون تراکنشی ثبت نشده است."))
            else currentRows.forEach{list.addView(txCard(it,true))}
            if(historicalRows.isNotEmpty()) {
                list.addView(text("سوابق پیش از تاریخ مبنا (${historicalRows.size})",15f,red,true))
                list.addView(text("این تراکنش‌ها برای حفظ تاریخچه نمایش داده می‌شوند، اما در مانده جاری محاسبه نمی‌شوند.",12f))
                historicalRows.forEach{list.addView(txCard(it,true))}
            }
        }
    }
    private fun personOpeningDialog(p:Person,current:PersonOpening?) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val amount=field("مبلغ مانده اول دوره به تومان",true).apply{if(current!=null)setText(current.amount.toString())}
        val type=Spinner(this).apply{
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("طلب","بدهی"))
            if(current!=null)setSelection(if(current.balanceType=="بدهی")1 else 0)
        }
        val note=field("توضیحات").apply{if(current!=null)setText(current.description)}
        val date=dateFields(box,current?.baseDate ?: System.currentTimeMillis(),"تاریخ مبنای مانده اول دوره")
        box.addView(text("نوع مانده"));box.addView(type);box.addView(amount);box.addView(note)
        AlertDialog.Builder(this).setTitle(if(current==null)"ثبت مانده اول دوره ${p.name}" else "اصلاح مانده اول دوره ${p.name}")
            .setMessage("تراکنش‌های قبل از تاریخ مبنا در مانده جاری محاسبه نمی‌شوند، اما در تاریخچه باقی می‌مانند. هر اصلاح، سابقه قبلی را حفظ می‌کند.")
            .setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره") { _,_->
                val a=parseLongDigits(amount.text.toString())
                val at=readDate(date)
                if(a==null || a<0L) { toast("مبلغ معتبر وارد کنید"); return@setPositiveButton }
                if(at==null) { toast("تاریخ شمسی معتبر وارد کنید"); return@setPositiveButton }
                try {
                    db.setPersonOpeningBalance(p.id,a,type.selectedItem.toString(),at,note.text.toString().trim())
                    personPage(p.id)
                } catch(e:Exception) { toast("ثبت مانده اول دوره ناموفق بود: ${e.message ?: "خطا"}") }
            }.show()
    }
    private fun archivePersonConfirm(p:Person) {
        val count=db.personTransactionCount(p.id)
        val msg=if(count>0) "این پرونده $count تراکنش دارد. با بایگانی، فقط از فهرست فعال خارج می‌شود و تمام گردش حساب و سوابق مالی حفظ می‌شوند. هر زمان بخواهید قابل بازیابی است." else "این پرونده از فهرست فعال خارج می‌شود و هر زمان بخواهید قابل بازیابی است."
        AlertDialog.Builder(this).setTitle("بایگانی پرونده ${p.name}").setMessage(msg).setNegativeButton("انصراف",null).setPositiveButton("بایگانی") { _,_-> db.archivePerson(p.id); showPeople() }.show()
    }
    private fun showArchivedPeople() {
        base("پرونده‌های بایگانی‌شده") { showPeople() }
        val sc=ScrollView(this); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; sc.addView(list); root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val rows=db.deletedPeople()
        if(rows.isEmpty()) list.addView(text("پرونده بایگانی‌شده‌ای وجود ندارد.")) else rows.forEach { p ->
            val c=card(); c.addView(text(p.name,17f,green,true)); c.addView(text("تراکنش‌های ثبت‌شده: ${db.personTransactionCount(p.id)}"));
            c.addView(text(if(p.balance>0) "مانده طلب: ${fmt(p.balance)} ${moneyUnit()}" else if(p.balance<0) "مانده بدهی: ${fmt(-p.balance)} ${moneyUnit()}" else "مانده خالص: صفر"))
            if(p.groupName.isNotBlank()) c.addView(text("گروه: ${p.groupName}",12f,0xff52635a.toInt()))
            if(p.roles.isNotBlank() || p.relation.isNotBlank()) c.addView(text("نقش‌ها: ${(listOf(p.relation)+p.roles.split(',')).filter{it.isNotBlank()}.distinct().joinToString("، ")}",12f,0xff52635a.toInt()))
            if(p.phone.isNotBlank()) c.addView(text(p.phone,13f))
            c.addView(btn("بازیابی پرونده") { AlertDialog.Builder(this).setTitle("بازیابی ${p.name}؟").setMessage("پرونده دوباره در فهرست اشخاص فعال نمایش داده می‌شود و سوابق قبلی آن حفظ خواهد شد.").setNegativeButton("انصراف",null).setPositiveButton("بازیابی") { _,_-> db.restorePerson(p.id); showArchivedPeople() }.show() })
            list.addView(c); line(list)
        }
        root.addView(btn("بازگشت به اشخاص") { showPeople() })
    }
    private fun editPersonInfo(p:Person){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val n=field("نام",false).apply{setText(p.name)};val father=field("نام پدر").apply{setText(p.fatherName)};val ph=field("شماره تماس").apply{setText(p.phone)};val landline=field("تلفن ثابت").apply{setText(p.landline)};val email=field("پست الکترونیکی").apply{setText(p.email)};val roles=field("نقش‌های دیگر با ویرگول").apply{setText(p.roles)};val group=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده"));setSelection(arrayOf("اشخاص منتخب/طرف‌حساب‌ها","سایر افراد و طرف‌حساب‌ها","افراد خانواده").indexOf(p.groupName).coerceAtLeast(0))};val rel=field("نوع ارتباط").apply{setText(p.relation)};val ad=field("نشانی").apply{setText(p.address)};val note=field("توضیحات").apply{setText(p.notes)};val second=field("شماره تماس دوم").apply{setText(p.secondPhone)};val nid=field("کد ملی",true).apply{setText(p.nationalId)};val birth=field("تاریخ تولد شمسی").apply{setText(p.birthDate)};val job=field("شغل").apply{setText(p.job)};val workplace=field("محل کار").apply{setText(p.workplace)};val source=field("منبع آشنایی").apply{setText(p.source)};val tags=field("برچسب‌ها با ویرگول").apply{setText(p.tags)};val location=field("موقعیت مکانی یا نشانی تکمیلی").apply{setText(p.location)};val rating=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("عادی","معتبر","نیازمند احتیاط","نامشخص"));setSelection(arrayOf("عادی","معتبر","نیازمند احتیاط","نامشخص").indexOf(p.rating).coerceAtLeast(0))}
        activePersonName=n;activePersonPhone=ph;activePersonPhotoData=p.photoData
        personPhotoControls(box);refreshActivePhoto();box.addView(text("گروه اصلی"));box.addView(group);listOf(n,father,ph,second,landline,email,nid,birth,rel,roles,ad,location,job,workplace,source,tags,note).forEach{box.addView(it)};box.addView(text("درجه اعتبار"));box.addView(rating)
        box.addView(btn("حذف عکس شخص") { activePersonPhotoData="";activePersonPhotoPreview?.setImageDrawable(null) })
        val formScroll=ScrollView(this);formScroll.addView(box)
        AlertDialog.Builder(this).setTitle("ویرایش شخص").setView(formScroll).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->
            db.writableDatabase.execSQL("UPDATE people SET name=?,phone=?,relation=?,address=?,notes=?,photo_data=? WHERE id=?",arrayOf(n.text.toString(),ph.text.toString(),rel.text.toString(),ad.text.toString(),note.text.toString(),activePersonPhotoData,p.id));db.updatePersonExtra(p.id,second.text.toString().trim(),nid.text.toString().trim(),birth.text.toString().trim(),job.text.toString().trim(),workplace.text.toString().trim(),source.text.toString().trim(),rating.selectedItem.toString(),tags.text.toString().trim(),location.text.toString().trim(),father.text.toString().trim(),landline.text.toString().trim(),email.text.toString().trim(),group.selectedItem.toString(),roles.text.toString().trim())
            db.writableDatabase.execSQL("INSERT INTO audit_log(action,target,target_id,details,created_at) VALUES(?,?,?,?,?)",arrayOf("ویرایش","شخص",p.id,n.text.toString(),System.currentTimeMillis()));personPage(p.id)
        }.show()
    }
    private var pendingDocumentPersonId:Long=0L
    private fun addPersonDocument(p:Person){
        pendingDocumentPersonId=p.id
        val title=field("عنوان مدرک؛ مانند کارت ملی، قرارداد، برگه مشخصات")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};box.addView(title)
        AlertDialog.Builder(this).setTitle("افزودن مدرک به پرونده").setView(box).setNegativeButton("انصراف",null).setNeutralButton("عکس با دوربین"){_,_->
            pendingDocumentTitle=title.text.toString().trim().ifBlank{"مدرک شخص"}
            try{startActivityForResult(Intent("android.media.action.IMAGE_CAPTURE"),4112)}catch(e:Exception){toast("دوربین در دسترس نیست")}
        }.setPositiveButton("انتخاب از گالری / فایل‌ها"){_,_->
            pendingDocumentTitle=title.text.toString().trim().ifBlank{"مدرک شخص"}
            try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},4110)}catch(e:Exception){toast("انتخاب فایل ممکن نیست")}
        }.show()
    }
    private var pendingDocumentTitle="مدرک شخص"
    private fun showPersonDocuments(p:Person){
        val docs=db.documents(p.id)
        if(docs.isEmpty()){toast("مدرکی برای این شخص ثبت نشده است");return}
        AlertDialog.Builder(this).setTitle("مدارک ${p.name}").setItems(docs.map{it.second}.toTypedArray()){_,which->
            val item=docs[which];val data=db.documentData(item.first) ?: return@setItems
            val image=personPhotoView(data,260).apply{layoutParams=LinearLayout.LayoutParams(260,260).apply{gravity=Gravity.CENTER}}
            AlertDialog.Builder(this).setTitle(item.second).setView(image).setNegativeButton("بستن",null).setPositiveButton("حذف مدرک"){_,_->db.deleteDocument(item.first);personPage(p.id)}.show()
        }.setNegativeButton("بستن",null).show()
    }
    private fun addPersonReminder(p:Person){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val title=field("عنوان یادآوری؛ مثلاً تماس برای تسویه")
        val note=field("توضیحات")
        val date=dateFields(box,System.currentTimeMillis(),"تاریخ یادآوری شمسی")
        box.addView(title);box.addView(note)
        AlertDialog.Builder(this).setTitle("یادآوری برای ${p.name}").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره یادآوری"){_,_->
            val at=readDate(date);if(title.text.toString().isBlank()||at==null){toast("عنوان و تاریخ معتبر وارد کنید");return@setPositiveButton}
            val reminderId=db.addReminder(p.id,title.text.toString().trim(),note.text.toString().trim(),at);schedulePersonReminder(p.id,reminderId,p.name,title.text.toString().trim(),at);personPage(p.id)
        }.show()
    }
    private fun schedulePersonReminder(personId:Long,reminderId:Long,personName:String,title:String,day:Long){
        try{
            val alarm=getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent=Intent(this,PersonReminderReceiver::class.java).apply{putExtra("person_name",personName);putExtra("reminder_title",title);putExtra("reminder_id",reminderId)}
            val pending=PendingIntent.getBroadcast(this,(reminderId%Int.MAX_VALUE).toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val at=day+9L*60L*60L*1000L
            if(at>System.currentTimeMillis()) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending)
            if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),4120)
        }catch(e:Exception){toast("یادآوری ذخیره شد؛ تنظیم هشدار خودکار ممکن نشد")}
    }
    private fun sharePerson(p:Person){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,12,24,12)}
        val scroll=ScrollView(this).apply{addView(box)}
        val choices=linkedMapOf<String,Pair<String,String>>()
        fun addChoice(key:String,label:String,value:String,checked:Boolean=false){
            val cb=CheckBox(this).apply{text=label;isChecked=checked}
            box.addView(cb); choices[key]=Pair(value,"")
            cb.tag=key
        }
        addChoice("name","نام و نام خانوادگی",p.name,true)
        addChoice("phone","شماره تماس اصلی",p.phone,true)
        addChoice("second_phone","شماره تماس دوم",p.secondPhone)
        addChoice("landline","تلفن ثابت",p.landline)
        addChoice("email","ایمیل",p.email)
        addChoice("address","نشانی",p.address)
        addChoice("job","شغل و محل کار",listOf(p.job,p.workplace).filter{it.isNotBlank()}.joinToString(" • "))
        addChoice("national_id","کد ملی (اطلاعات حساس)",p.nationalId)
        addChoice("birth","تاریخ تولد",p.birthDate)
        addChoice("roles","گروه و نقش‌ها",listOf(p.groupName,p.roles).filter{it.isNotBlank()}.joinToString(" • "))
        addChoice("notes","توضیحات",p.notes)
        val accountRows=mutableListOf<String>()
        try{db.readableDatabase.rawQuery("SELECT bank_name,owner_name,account_number,card_number,iban FROM finance_accounts WHERE is_deleted=0 AND is_active=1 AND owner_person_id=? ORDER BY id",arrayOf(p.id.toString())).use{c->while(c.moveToNext()){
            val parts=listOf(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4)).filter{!it.isNullOrBlank()}
            if(parts.isNotEmpty()) accountRows.add(parts.joinToString(" | "))
        }}}catch(_:Exception){}
        val accountCheck=CheckBox(this).apply{text="اطلاعات حساب‌های بانکی متصل (${accountRows.size})؛ شامل شماره حساب/کارت/شبا";isChecked=false;isEnabled=accountRows.isNotEmpty()}
        box.addView(accountCheck)
        AlertDialog.Builder(this).setTitle("انتخاب اطلاعات برای اشتراک‌گذاری").setView(scroll)
            .setNegativeButton("انصراف",null).setPositiveButton("پیش‌نمایش") { _,_->
                val lines=mutableListOf("اطلاعات انتخاب‌شده پرونده: ${p.name}")
                for(i in 0 until box.childCount){val v=box.getChildAt(i);if(v is CheckBox && v.isChecked && v!==accountCheck){val key=v.tag as? String ?: continue;val value=choices[key]?.first.orEmpty();if(value.isNotBlank())lines.add("${v.text}: $value")}}
                if(accountCheck.isChecked) accountRows.forEachIndexed{index,row->lines.add("حساب بانکی ${index+1}: $row")}
                val preview=lines.joinToString("\n")
                AlertDialog.Builder(this).setTitle("پیش‌نمایش اطلاعات قابل ارسال").setMessage(preview)
                    .setNegativeButton("بازگشت به انتخاب",null)
                    .setPositiveButton("تأیید و اشتراک‌گذاری"){_,_->
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,preview),"اشتراک‌گذاری اطلاعات انتخاب‌شده"))
                    }.show()
            }.show()
    }
    private var pendingPdfPerson:Person?=null
    private fun exportPersonPdf(p:Person){
        pendingPdfPerson=p
        try{
            val pdf=PdfDocument();val pageInfo=PdfDocument.PageInfo.Builder(595,842,1).create();val page=pdf.startPage(pageInfo)
            val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(28,28,28,28)}
            val title=TextView(this).apply{text="پرونده شخص: ${p.name}";textSize=20f;setTypeface(null,1);textDirection=View.TEXT_DIRECTION_RTL;gravity=Gravity.RIGHT}
            content.addView(title)
            listOf("نام پدر: ${p.fatherName}","شماره تماس: ${p.phone}","شماره دوم: ${p.secondPhone}","تلفن ثابت: ${p.landline}","ایمیل: ${p.email}","گروه اصلی: ${p.groupName}","نقش‌ها: ${p.roles}","کد ملی: ${p.nationalId}","تاریخ تولد: ${p.birthDate}","نوع ارتباط: ${p.relation}","شغل: ${p.job}","محل کار: ${p.workplace}","نشانی: ${p.address}","موقعیت: ${p.location}","منبع آشنایی: ${p.source}","اعتبار: ${p.rating}","برچسب‌ها: ${p.tags}","طلب: ${fmt(p.receivable)} ${moneyUnit()}","بدهی: ${fmt(p.payable)} ${moneyUnit()}","مانده خالص: ${fmt(p.balance)} ${moneyUnit()}","یادداشت: ${p.notes}").forEach{line->content.addView(TextView(this).apply{text=line;textSize=13f;textDirection=View.TEXT_DIRECTION_RTL;gravity=Gravity.RIGHT;setPadding(0,7,0,7)})}
            val w=540;val h=780;content.measure(View.MeasureSpec.makeMeasureSpec(w,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(h,View.MeasureSpec.AT_MOST));content.layout(0,0,w,content.measuredHeight.coerceAtMost(h));content.draw(page.canvas);pdf.finishPage(page)
            val file=File(cacheDir,"person_${p.id}.pdf");FileOutputStream(file).use{pdf.writeTo(it)};pdf.close()
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/pdf";putExtra(Intent.EXTRA_TITLE,"پرونده-${p.name}.pdf")};startActivityForResult(intent,4111)
        }catch(e:Exception){toast("ساخت PDF ناموفق بود: ${e.message ?: "خطا"}")}
    }
    private fun personEntryDialog(p:Person){
        val types=arrayOf("طلب","بدهی","دریافت وجه","پرداخت وجه","دریافت کالا","تحویل کالا","فروش نسیه","خرید نسیه")
        entryDialog("ثبت عملیات برای ${p.name}",types,p.id)
    }
    private fun financeEntryDialog(preselect:String?=null){
        val types=arrayOf("دریافت وجه","پرداخت وجه","درآمد","هزینه")
        entryDialog("ثبت تراکنش مالی",types,null,preselect)
    }
    private fun dateFields(parent:LinearLayout, initial:Long, label:String="تاریخ شمسی"):Triple<EditText,EditText,EditText> {
        val parts=jalali(initial).split("/"); val y=field("سال شمسی",true).apply{setText(parts[0])}; val m=field("ماه",true).apply{setText(parts[1])}; val d=field("روز",true).apply{setText(parts[2])}
        parent.addView(text("$label (سال / ماه / روز)")); val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; row.addView(y,LinearLayout.LayoutParams(0,-2,1.3f));row.addView(m,LinearLayout.LayoutParams(0,-2,1f));row.addView(d,LinearLayout.LayoutParams(0,-2,1f));parent.addView(row)
        return Triple(y,m,d)
    }
    private fun readDate(fields:Triple<EditText,EditText,EditText>):Long? = jalaliToMillis(parseLongDigits(fields.first.text.toString())?.toInt()?:-1,parseLongDigits(fields.second.text.toString())?.toInt()?:-1,parseLongDigits(fields.third.text.toString())?.toInt()?:-1)
    private fun entryDialog(title:String,types:Array<String>,personId:Long?,preselect:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val sp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types);if(preselect!=null)setSelection(types.indexOf(preselect).coerceAtLeast(0))};val amount=field("مبلغ کل عملیات به تومان",true);val note=field("شرح / توضیحات");val account=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,db.accounts())};val peopleForEntry=if(personId==null) db.people("") else emptyList();val personOptions=listOf("بدون طرف‌حساب")+peopleForEntry.map{"${it.name}${if(it.phone.isBlank())"" else " • ${it.phone}"} • شناسه ${it.id}"};val personPicker=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,personOptions)};val methods=arrayOf("نقدی","کارت‌به‌کارت","واریز بانکی","چک","سفته","دریافت کالا/جنس","تهاتر","نسیه/تسویه بعدی");val method=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,methods)};val settled=field("مبلغ روش اول",true);val methods2=arrayOf("بدون روش دوم")+methods;val method2=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,methods2)};val settled2=field("مبلغ روش دوم (در صورت تسویه ترکیبی)",true);val reference=field("شماره پیگیری / شماره چک یا سفته");val details=field("جزئیات تسویه یا کالای دریافتی");val itemName=field("نام کالا (در صورت دریافت کالا)");val itemQty=field("تعداد کالا",true);val itemUnit=field("واحد کالا؛ کیلو، عدد و ...");val itemPrice=field("قیمت توافقی هر واحد به تومان",true);val bank=field("بانک صادرکننده (در صورت چک/سفته)");val date=dateFields(box,System.currentTimeMillis());val due=dateFields(box,System.currentTimeMillis(),"سررسید چک/سفته (در صورت نیاز)");box.addView(text("نوع عملیات"));box.addView(sp);if(personId==null){box.addView(text("انتخاب طرف‌حساب از بانک مرکزی اشخاص (اختیاری)"));box.addView(personPicker)};box.addView(amount);box.addView(note);box.addView(text("روش تسویه اول"));box.addView(method);box.addView(settled);box.addView(text("روش تسویه دوم؛ برای حالت ترکیبی"));box.addView(method2);box.addView(settled2);box.addView(reference);box.addView(details);box.addView(text("جزئیات کالای دریافتی (در صورت وجود)"));box.addView(itemName);box.addView(itemQty);box.addView(itemUnit);box.addView(itemPrice);box.addView(bank);box.addView(text("صندوق یا حساب بانکی"));box.addView(account)
        AlertDialog.Builder(this).setTitle(title).setView(box).setNegativeButton("انصراف",null).setPositiveButton("ثبت تراکنش"){_,_->val a=parseLongDigits(amount.text.toString());val whenAt=readDate(date);if(a==null||a<=0){toast("مبلغ معتبر وارد کنید");return@setPositiveButton};if(whenAt==null){toast("تاریخ شمسی معتبر وارد کنید");return@setPositiveButton};val methodName=methods[method.selectedItemPosition];val paid=parseLongDigits(settled.text.toString()) ?: if(methodName=="نسیه/تسویه بعدی")0L else a;val method2Name=methods2[method2.selectedItemPosition];val paid2=parseLongDigits(settled2.text.toString()) ?: 0L;if(paid<0||paid2<0||paid+paid2>a){toast("مجموع مبالغ تسویه نباید از مبلغ کل بیشتر باشد");return@setPositiveButton};if(types[sp.selectedItemPosition] in listOf("دریافت وجه","پرداخت وجه") && paid+paid2==0L){toast("برای دریافت یا پرداخت وجه، مبلغ تسویه‌شده باید بیشتر از صفر باشد");return@setPositiveButton};if(paid2>0&&method2Name=="بدون روش دوم"){toast("برای مبلغ روش دوم، روش تسویه دوم را انتخاب کنید");return@setPositiveButton};val needsInstrument=methodName=="چک"||methodName=="سفته"||(paid2>0&&(method2Name=="چک"||method2Name=="سفته"));val dueAt=if(needsInstrument)readDate(due) else null;if(needsInstrument&&(dueAt==null||dueAt<whenAt)){toast("برای چک یا سفته، سررسید معتبر و بعد از تاریخ عملیات وارد کنید");return@setPositiveButton};val goods="کالا: ${itemName.text}; تعداد: ${itemQty.text} ${itemUnit.text}; قیمت واحد: ${itemPrice.text}";val fullDetails=listOf(details.text.toString().trim(),goods).filter{it.isNotBlank() && it!="کالا: ; تعداد:  ; قیمت واحد: "}.joinToString(" | ");val operationPersonId=personId ?: peopleForEntry.getOrNull(personPicker.selectedItemPosition-1)?.id;val txId=db.addTx(operationPersonId,types[sp.selectedItemPosition],a,note.text.toString().trim(),account.selectedItem?.toString() ?: "نقدی",whenAt);if(paid>0)db.addSettlement(txId,methodName,paid,reference.text.toString().trim(),fullDetails);if(paid2>0)db.addSettlement(txId,method2Name,paid2,"",fullDetails);if((methodName=="چک"||methodName=="سفته")&&paid>0)db.addInstrument(txId,operationPersonId,methodName,reference.text.toString().trim(),bank.text.toString().trim(),operationPersonId?.let{db.personName(it)}?:"",paid,whenAt,dueAt!!,fullDetails);if(paid2>0&&(method2Name=="چک"||method2Name=="سفته"))db.addInstrument(txId,operationPersonId,method2Name,"",bank.text.toString().trim(),operationPersonId?.let{db.personName(it)}?:"",paid2,whenAt,dueAt!!,fullDetails);if(operationPersonId==null)showFinance()else personPage(operationPersonId)}.show()
    }
    private fun editTxDialog(t:Tx) {
        val types=if(t.personId==null) arrayOf("دریافت وجه","پرداخت وجه","درآمد","هزینه") else arrayOf("طلب","بدهی","دریافت وجه","پرداخت وجه","دریافت کالا","تحویل کالا","فروش نسیه","خرید نسیه")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val kind=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types);setSelection(types.indexOf(t.kind).coerceAtLeast(0))}
        val amount=field("مبلغ به تومان",true).apply{setText(t.amount.toString())};val note=field("شرح / توضیحات").apply{setText(t.note)};val date=dateFields(box,t.createdAt)
        val account=Spinner(this).apply{val items=db.accounts();adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);setSelection(items.indexOf(t.account).coerceAtLeast(0))}
        box.addView(text("نوع عملیات"));box.addView(kind);box.addView(amount);box.addView(note);box.addView(text("صندوق یا حساب"));box.addView(account)
        AlertDialog.Builder(this).setTitle("ویرایش تراکنش").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره تغییرات"){_,_->val a=parseLongDigits(amount.text.toString());if(a==null||a<=0){toast("مبلغ معتبر وارد کنید");return@setPositiveButton};val whenAt=readDate(date);if(whenAt==null){toast("تاریخ شمسی معتبر وارد کنید");return@setPositiveButton};try{db.updateTx(t.id,types[kind.selectedItemPosition],a,note.text.toString().trim(),account.selectedItem?.toString() ?: "نقدی",whenAt);if(t.personId==null)showFinance() else personPage(t.personId)}catch(e:Exception){toast(e.message?:"ویرایش ناموفق")}}.show()
    }
    private fun reportDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val today=System.currentTimeMillis();val from=dateFields(box,today,"از تاریخ");val to=dateFields(box,today,"تا تاریخ")
        AlertDialog.Builder(this).setTitle("گزارش بازه‌ای") .setView(box).setNegativeButton("انصراف",null).setPositiveButton("نمایش گزارش"){_,_->
            val start=readDate(from);val end=readDate(to)
            if(start==null||end==null||end<start){toast("بازه تاریخ معتبر نیست");return@setPositiveButton}
            val endExclusive=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis
            showReport(start,endExclusive)
        }.show()
    }
    private fun showReport(start:Long,endExclusive:Long){
        base("گزارش مالی بازه انتخابی"){showFinance()}
        val rows=db.transactionsBetween(start,endExclusive)
        val totals=db.cashTotals(start,endExclusive);val income=totals.first;val expense=totals.second
        val opening=db.cashBalanceBefore(start); val closing=opening+income-expense
        val box=card().apply{setBackgroundColor(pale)}
        box.addView(text("از ${jalali(start)} تا ${jalali(endExclusive-1)}",14f,green,true))
        box.addView(text("مانده اول دوره: ${fmt(opening)} ${moneyUnit()}",15f,green,true))
        box.addView(text("تعداد تراکنش‌ها: ${rows.size}",14f))
        box.addView(text("مجموع دریافت و درآمد: ${fmt(income)} ${moneyUnit()}",15f,green,true))
        box.addView(text("مجموع پرداخت و هزینه: ${fmt(expense)} ${moneyUnit()}",15f,red,true))
        box.addView(text("خالص گردش نقدی این بازه: ${fmt(income-expense)} ${moneyUnit()}",15f,if(income>=expense)green else red,true))
        box.addView(text("مانده پایان دوره: ${fmt(closing)} ${moneyUnit()}",17f,if(closing>=0)green else red,true));root.addView(box)
        val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        if(rows.isEmpty())list.addView(text("در این بازه تراکنشی ثبت نشده است.")) else rows.forEach{list.addView(txCard(it,true));line(list)}
    }

    private fun showInstruments() {
        base("چک، سفته و سررسیدها"){showFinance()}
        root.addView(text("ابزارهای مالی ثبت‌شده؛ وضعیت اولیه هر مورد در انتظار است.",13f))
        val rows=db.instrumentRows()
        if(rows.isEmpty()) root.addView(text("هنوز چک یا سفته‌ای ثبت نشده است.")) else rows.forEach { item -> val c=card();c.addView(text(item.second,14f));c.addView(btn("تغییر وضعیت") { val statuses=arrayOf("در انتظار","وصول‌شده","پرداخت‌شده","برگشتی","باطل‌شده");AlertDialog.Builder(this).setTitle("وضعیت ابزار مالی").setItems(statuses){_,which->db.updateInstrumentStatus(item.first,statuses[which]);showInstruments()}.show() });root.addView(c);line(root) }
        root.addView(btn("بازگشت به امور مالی"){showFinance()})
    }
    private fun showInstallments() {
        base("مدیریت اقساط"){showFinance()}
        val rows=db.installmentRows()
        if(rows.isEmpty()) root.addView(text("برنامه قسط فعالی ثبت نشده است.")) else rows.forEach { item -> val c=card();c.addView(text(item.second,14f));c.addView(btn("ثبت پرداخت قسط") { val amount=field("مبلغ پرداخت‌شده به تومان",true);AlertDialog.Builder(this).setTitle("پرداخت قسط").setView(amount).setNegativeButton("انصراف",null).setPositiveButton("ثبت"){_,_->val a=parseLongDigits(amount.text.toString());if(a==null||a<=0){toast("مبلغ معتبر نیست");return@setPositiveButton};try{db.payInstallment(item.first,a);showInstallments()}catch(e:Exception){toast(e.message?:"ثبت پرداخت ناموفق")}}.show() });root.addView(c);line(root) }
        root.addView(btn("＋ ثبت برنامه اقساط"){installmentDialog()})
        root.addView(btn("بازگشت به امور مالی"){showFinance()})
    }
    private fun installmentDialog() {
        val ps=db.people(); if(ps.isEmpty()){toast("ابتدا یک شخص ثبت کنید");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val person=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,ps.map{it.name})}
        val title=field("عنوان قسط یا قرارداد");val total=field("مبلغ کل به تومان",true);val each=field("مبلغ هر قسط به تومان",true);val interval=field("فاصله اقساط به روز",true).apply{setText("30")};val notes=field("توضیحات");val date=dateFields(box,System.currentTimeMillis(),"تاریخ اولین سررسید")
        box.addView(text("شخص"));box.addView(person);box.addView(title);box.addView(total);box.addView(each);box.addView(interval);box.addView(notes)
        AlertDialog.Builder(this).setTitle("ثبت برنامه اقساط").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->val t=parseLongDigits(total.text.toString());val e=parseLongDigits(each.text.toString());val days=parseLongDigits(interval.text.toString())?.toInt();val at=readDate(date);if(title.text.isBlank()||t==null||e==null||days==null||at==null){toast("همه مقادیر ضروری را درست وارد کنید");return@setPositiveButton};try{db.addInstallment(ps[person.selectedItemPosition].id,title.text.toString(),t,e,days,at,notes.text.toString());showInstallments()}catch(ex:Exception){toast(ex.message?:"ثبت ناموفق")}}.show()
    }
    private fun reconcileDialog() {
        val accounts=db.accounts();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val account=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts)}
        val from=dateFields(box,System.currentTimeMillis(),"از تاریخ");val to=dateFields(box,System.currentTimeMillis(),"تا تاریخ");val statement=field("مانده صورت‌حساب بانک به تومان",true);val notes=field("توضیحات / علت اختلاف")
        box.addView(text("حساب مورد بررسی"));box.addView(account);box.addView(statement);box.addView(notes)
        AlertDialog.Builder(this).setTitle("مغایرت‌گیری حساب").setView(box).setNegativeButton("انصراف",null).setPositiveButton("مقایسه و ذخیره نتیجه"){_,_->val start=readDate(from);val end=readDate(to);val amount=parseLongDigits(statement.text.toString());if(start==null||end==null||end<start||amount==null){toast("تاریخ یا مانده صورت‌حساب معتبر نیست");return@setPositiveButton};val endX=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis;val result=db.reconcile(account.selectedItem.toString(),start,endX,amount,notes.text.toString());AlertDialog.Builder(this).setTitle(if(result.second==0L)"حساب مطابقت دارد" else "مغایرت شناسایی شد").setMessage("مانده محاسبه‌شده دفتر: ${fmt(result.first)} ${moneyUnit()}\nاختلاف صورت‌حساب با دفتر: ${fmt(result.second)} ${moneyUnit()}\n\nاین نتیجه ذخیره شد؛ اصلاح خودکار تراکنش‌ها انجام نمی‌شود.").setPositiveButton("متوجه شدم"){_,_->showReconcileHistory()}.show()}.show()
    }
    private fun showReconcileHistory() {
        base("سوابق مغایرت‌گیری"){showFinance()};val rows=db.reconciliationHistory();if(rows.isEmpty())root.addView(text("سابقه‌ای وجود ندارد")) else rows.forEach{root.addView(card().apply{addView(text(it,14f))});line(root)}
        root.addView(btn("مغایرت‌گیری جدید"){reconcileDialog()})
    }

    private fun showAccounts() {
        base("صندوق‌ها و حساب‌ها"){showHome()}
        root.addView(text("مانده هر حساب بر اساس دریافت‌ها و پرداخت‌های ثبت‌شده",13f))
        db.accountBalances().forEach { item -> val c=card();c.addView(text(item.first,17f,green,true));val detail=db.accountDetails(item.first);if(detail.isNotBlank())c.addView(text(detail,12f));c.addView(text("مانده: ${fmt(item.second)} ${moneyUnit()}",16f,if(item.second>=0)green else red,true));c.addView(btn("ثبت / اصلاح مانده اول دوره") { openingBalanceDialog(item.first) });c.addView(btn("گزارش این حساب") { accountReportDialog(item.first) });c.addView(btn("غیرفعال‌کردن حساب") { AlertDialog.Builder(this).setMessage("حساب برای ثبت‌های جدید غیرفعال شود؟ سوابق و تراکنش‌های قبلی حفظ می‌شوند.").setNegativeButton("انصراف",null).setPositiveButton("غیرفعال کن"){_,_->db.setAccountActive(item.first,false);showAccounts()}.show() });root.addView(c);line(root) }
        root.addView(btn("⇄ انتقال وجه بین دو حساب") { transferDialog() })
        root.addView(btn("سوابق اصلاح مانده اول دوره") { showOpeningHistory() })
        val inactive=db.inactiveAccounts()
        if(inactive.isNotEmpty()) { root.addView(text("حساب‌های غیرفعال",15f,red,true));inactive.forEach { name -> root.addView(btn("فعال‌سازی دوباره: $name") { db.setAccountActive(name,true);showAccounts() }) } }
        root.addView(btn("＋ افزودن صندوق یا حساب بانکی") {
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
            val name=field("عنوان دلخواه حساب؛ مثلاً بانک ملی شخصی");val bank=field("نام بانک");val types=arrayOf("صندوق","حساب جاری","پس‌انداز","کوتاه‌مدت","بلندمدت","کارت بانکی","سایر");val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types)};val number=field("شماره حساب");val cardNo=field("شماره کارت");val iban=field("شماره شبا");val owner=field("نام صاحب حساب (در صورت نیاز)");val ownerPeople=db.people();val ownerLink=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("بدون اتصال به پرونده شخص")+ownerPeople.map{it.name})};val notes=field("توضیحات")
            box.addView(name);box.addView(bank);box.addView(text("نوع حساب"));box.addView(type);box.addView(number);box.addView(cardNo);box.addView(iban);box.addView(owner);box.addView(text("اتصال به پرونده مرکزی صاحب حساب (اختیاری)"));box.addView(ownerLink);box.addView(notes)
            AlertDialog.Builder(this).setTitle("ثبت حساب مستقل").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->val ownerId=if(ownerLink.selectedItemPosition==0)null else ownerPeople[ownerLink.selectedItemPosition-1].id;if(db.addAccount(name.text.toString(),bank.text.toString(),types[type.selectedItemPosition],number.text.toString(),cardNo.text.toString(),iban.text.toString(),owner.text.toString(),ownerId,notes.text.toString()))showAccounts()else toast("عنوان خالی یا تکراری است")}.show()
        })
        root.addView(btn("بازگشت به خانه"){showHome()})
    }
    private fun showOpeningHistory() {
        base("سوابق اصلاح مانده اول دوره"){showAccounts()}
        val rows=mutableListOf<String>()
        db.readableDatabase.rawQuery("SELECT account,old_balance,old_at,new_balance,new_at,reason,changed_at FROM account_opening_history ORDER BY id DESC LIMIT 100",null).use { c -> while(c.moveToNext()) rows.add("${c.getString(0)}\nقبلی: ${fmt(c.getLong(1))} در ${jalali(c.getLong(2))}\nجدید: ${fmt(c.getLong(3))} در ${jalali(c.getLong(4))}${if(c.getString(5).isNullOrBlank())"" else "\nعلت: ${c.getString(5)}"}") }
        if(rows.isEmpty())root.addView(text("سابقه‌ای ثبت نشده است.")) else rows.forEach{root.addView(card().apply{addView(text(it,14f))});line(root)}
    }
    private fun openingBalanceDialog(account:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val existing=db.accountOpening(account);val amount=field("مانده اول دوره به تومان",true).apply{setText(existing.first.toString())};val reason=field("علت ثبت یا اصلاح (اختیاری)"); val date=dateFields(box,if(existing.second>0)existing.second else System.currentTimeMillis(),"تاریخ مبنای مانده")
        box.addView(text("مبلغ مثبت برای موجودی و مبلغ منفی برای کسری/بدهی وارد شود. تغییر تاریخ مبنا، محاسبه گردش‌های قدیمی‌تر را تغییر می‌دهد."));box.addView(amount);box.addView(reason)
        AlertDialog.Builder(this).setTitle("مانده اول دوره • $account").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ذخیره"){_,_->val a=parseLongDigits(amount.text.toString());val at=readDate(date);if(a==null||at==null){toast("مبلغ یا تاریخ معتبر نیست");return@setPositiveButton};db.setOpeningBalance(account,a,at,reason.text.toString());showAccounts()}.show()
    }
    private fun transferDialog() {
        val accounts=db.accounts();if(accounts.size<2){toast("برای انتقال، ابتدا حداقل دو حساب بسازید");return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)}
        val from=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts)}
        val to=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,accounts);setSelection(1)}
        val amount=field("مبلغ انتقال به تومان",true);val note=field("شرح انتقال");val date=dateFields(box,System.currentTimeMillis())
        box.addView(text("از حساب"));box.addView(from);box.addView(text("به حساب"));box.addView(to);box.addView(amount);box.addView(note)
        AlertDialog.Builder(this).setTitle("انتقال وجه بین حساب‌ها").setView(box).setNegativeButton("انصراف",null).setPositiveButton("ثبت انتقال"){_,_->val a=parseLongDigits(amount.text.toString());val at=readDate(date);if(from.selectedItemPosition==to.selectedItemPosition){toast("حساب مبدأ و مقصد باید متفاوت باشند");return@setPositiveButton};if(a==null||a<=0||at==null){toast("مبلغ یا تاریخ معتبر نیست");return@setPositiveButton};try{db.transfer(from.selectedItem.toString(),to.selectedItem.toString(),a,note.text.toString().trim(),at);showAccounts()}catch(e:Exception){toast(e.message?:"ثبت انتقال ناموفق بود")}}.show()
    }
    private fun accountReportDialog(account:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,0,16,0)};val today=System.currentTimeMillis();val from=dateFields(box,today,"از تاریخ");val to=dateFields(box,today,"تا تاریخ")
        AlertDialog.Builder(this).setTitle("گزارش حساب • $account").setView(box).setNegativeButton("انصراف",null).setPositiveButton("نمایش"){_,_->val start=readDate(from);val end=readDate(to);if(start==null||end==null||end<start){toast("بازه تاریخ معتبر نیست");return@setPositiveButton};val endX=Calendar.getInstance().apply{timeInMillis=end;add(Calendar.DAY_OF_MONTH,1)}.timeInMillis;showAccountReport(account,start,endX)}.show()
    }
    private fun showAccountReport(account:String,start:Long,endExclusive:Long) {
        base("گزارش حساب • $account"){showAccounts()}
        val opening=db.accountBalanceBefore(account,start);val accountBaseDate=db.accountOpeningAt(account);val rows=db.transactionsBetween(start,endExclusive).filter{it.account==account && it.createdAt>=accountBaseDate};val totals=db.cashTotals(start,endExclusive,account);val income=totals.first;val expense=totals.second
        val transfers=db.accountTransfers(account,start,endExclusive);val transferTotals=db.accountTransferTotals(account,start,endExclusive);val transferIn=transferTotals.first;val transferOut=transferTotals.second
        val box=card().apply{setBackgroundColor(pale)};box.addView(text("از ${jalali(start)} تا ${jalali(endExclusive-1)}",14f,green,true));box.addView(text("مانده اول دوره: ${fmt(opening)} ${moneyUnit()}",15f,green,true));box.addView(text("دریافت و درآمد: ${fmt(income)} ${moneyUnit()}"));box.addView(text("پرداخت و هزینه: ${fmt(expense)} ${moneyUnit()}"));box.addView(text("واریز از حساب‌های دیگر: ${fmt(transferIn)} ${moneyUnit()}"));box.addView(text("انتقال به حساب‌های دیگر: ${fmt(transferOut)} ${moneyUnit()}"));val closing=opening+income-expense+transferIn-transferOut;box.addView(text("مانده پایان دوره: ${fmt(closing)} ${moneyUnit()}",17f,if(closing>=0)green else red,true));root.addView(box)
        root.addView(text("تراکنش‌های حساب (${rows.size})",16f,green,true));val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));if(rows.isEmpty())list.addView(text("تراکنش نقدی در این بازه وجود ندارد."))else rows.forEach{list.addView(txCard(it,true));line(list)}
        root.addView(text("انتقال‌های بین حسابی",16f,green,true));if(transfers.isEmpty())root.addView(text("انتقالی در این بازه ثبت نشده است."))else transfers.forEach{root.addView(text(it,13f))}
    }

    private fun txCard(t:Tx,allowDelete:Boolean):LinearLayout{
        val c=card();val color=when(t.kind){"دریافت وجه","درآمد","طلب","پرداخت وجه","تحویل کالا","فروش نسیه"->green;else->red};c.addView(text("${t.kind}  •  ${fmt(t.amount)} ${moneyUnit()}",16f,color,true));c.addView(text("${t.personName}  |  ${jalali(t.createdAt)}  |  ${t.account}",12f,0xff68736b.toInt()));if(t.note.isNotBlank())c.addView(text(t.note,14f));val settlement=db.settlementSummary(t.id);if(settlement.isNotBlank())c.addView(text("روش/جزئیات تسویه: $settlement",12f,0xff53645a.toInt()));val docs=db.txDocuments(t.id);if(docs.isNotEmpty())c.addView(btn("مشاهده ${docs.size} پیوست") { showTxDocuments(t.id) });if(allowDelete)c.addView(btn("افزودن عکس/مدرک به تراکنش") { pendingTxDocumentId=t.id;try{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="image/*"},requestChooseTxDocument)}catch(e:Exception){toast("انتخاب فایل ممکن نیست")} });if(allowDelete)c.addView(btn("ویرایش تراکنش") { editTxDialog(t) });if(allowDelete)c.addView(btn("انتقال به سطل بازیابی") { AlertDialog.Builder(this).setMessage("این تراکنش به سطل بازیابی منتقل شود؟").setNegativeButton("انصراف",null).setPositiveButton("انتقال"){_,_->db.deleteTx(t.id);if(t.personId==null)showFinance()else personPage(t.personId)}.show() });return c
    }
    private fun showTxDocuments(txId:Long) {
        val docs=db.txDocuments(txId);if(docs.isEmpty()){toast("پیوستی ثبت نشده است");return}
        AlertDialog.Builder(this).setTitle("پیوست‌های تراکنش").setItems(docs.map{it.second}.toTypedArray()){_,which->val item=docs[which];val data=db.txDocumentData(item.first)?:return@setItems;val image=personPhotoView(data,260).apply{layoutParams=LinearLayout.LayoutParams(260,260).apply{gravity=Gravity.CENTER}};AlertDialog.Builder(this).setTitle(item.second).setView(image).setNegativeButton("بستن",null).setPositiveButton("حذف پیوست"){_,_->db.deleteTxDocument(item.first);toast("پیوست حذف شد")}.show()}.setNegativeButton("بستن",null).show()
    }
    private fun showTrash(){base("سطل بازیابی"){showHome()};val sc=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));val rows=db.deletedTx();if(rows.isEmpty())list.addView(text("سطل بازیابی خالی است.")) else rows.forEach{t->val c=card();c.addView(text("${t.kind} - ${fmt(t.amount)} ${moneyUnit()}",15f));c.addView(text(t.note));c.addView(btn("بازیابی تراکنش") { db.restoreTx(t.id);showTrash() });list.addView(c);line(list)}}

    private fun showBackup(){
        base("پشتیبان‌گیری و بازیابی اطلاعات"){showHome()}
        root.addView(text("نوع پشتیبان را پیش از ساخت انتخاب کنید. فایل خروجی نوع و محتوای خود را در مشخصات داخلی ثبت می‌کند.",14f))
        root.addView(btn("ساخت پشتیبان با انتخاب نوع") {
            val labels=arrayOf("فقط تنظیمات برنامه","فقط اطلاعات و داده‌ها","تنظیمات و اطلاعات با هم")
            AlertDialog.Builder(this).setTitle("نوع پشتیبان‌گیری").setItems(labels){_,which->
                pendingBackupType=when(which){0->"settings";1->"data";else->"both"}
                val summary=when(pendingBackupType){"settings"->"تنظیمات ظاهری بخش‌ها، منتخب‌ها، ترجیحات نمایش و فیلتر/مرتب‌سازی فهرست اشخاص";"data"->"پایگاه داده، پرونده‌ها، تراکنش‌ها، سوابق و پیوست‌های ذخیره‌شده در پایگاه داده";else->"همه تنظیمات و همه اطلاعات و داده‌های برنامه"}
                AlertDialog.Builder(this).setTitle("پیش‌نمایش محتویات پشتیبان").setMessage("نوع: ${labels[which]}\n\nمحتوا: $summary\n\nرمزهای بانکی و اطلاعات ورود محرمانه در این بسته قرار نمی‌گیرند.").setNegativeButton("انصراف",null).setPositiveButton("انتخاب محل ذخیره"){_,_->
                    val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip";putExtra(Intent.EXTRA_TITLE,"Modiriat_Zendegi_${pendingBackupType}_${System.currentTimeMillis()}.mzb")};startActivityForResult(intent,requestCreateBackup)
                }.show()
            }.show()
        })
        root.addView(btn("بازیابی از فایل پشتیبان") {
            AlertDialog.Builder(this).setTitle("انتخاب فایل پشتیبان").setMessage("ابتدا نوع و سلامت فایل بررسی می‌شود. پیش از هر جایگزینی، محتوای آن و اثر بازیابی به شما نمایش داده خواهد شد.").setNegativeButton("انصراف",null).setPositiveButton("انتخاب فایل"){_,_->val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"};startActivityForResult(intent,requestRestoreBackup)}.show()
        })
        root.addView(text("راهنما",16f,green,true))
        root.addView(text("• فایل پشتیبان جدید با قالب بسته فشرده و مشخصات نوع محتوا ساخته می‌شود و رمزگذاری نشده است؛ آن را در محل امن نگهداری کنید.\n• تنظیمات و داده‌ها مستقل از یکدیگر قابل پشتیبان‌گیری هستند.\n• هنگام بازیابی، فقط گروه موجود در فایل و انتخاب‌شده جایگزین می‌شود؛ گروه دیگر دست‌نخورده می‌ماند.\n• فایل را در محل امن نگهداری کنید.",13f))
        root.addView(btn("بازگشت به خانه"){showHome()})
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK) return
        when(requestCode){
            4112 -> { val bitmap=data?.extras?.get("data") as? Bitmap ?: return;try{db.addDocument(pendingDocumentPersonId,pendingDocumentTitle,encodePersonPhoto(bitmap));personPage(pendingDocumentPersonId)}catch(e:Exception){toast("ثبت تصویر مدرک ناموفق بود")};return }
            4110 -> { val uri=data?.data ?: return; try{val encoded=savePersonPhoto(uri);db.addDocument(pendingDocumentPersonId,pendingDocumentTitle,encoded);personPage(pendingDocumentPersonId)}catch(e:Exception){toast("ثبت مدرک ناموفق بود")};return }
            4111 -> { val uri=data?.data ?: return; try{val p=pendingPdfPerson ?: return;val file=File(cacheDir,"person_${p.id}.pdf");contentResolver.openOutputStream(uri,"w").use{out->if(out==null)throw IllegalStateException("فایل مقصد باز نشد");FileInputStream(file).use{it.copyTo(out)}};toast("گزارش PDF ذخیره شد")}catch(e:Exception){toast("ذخیره PDF ناموفق بود")};return }
            requestPickContact -> {
                val uri=data?.data ?: return
                try { contentResolver.query(uri,arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER),null,null,null)?.use { c -> if(c.moveToFirst()){activePersonName?.setText(c.getString(0) ?: "");activePersonPhone?.setText(c.getString(1) ?: "")} } }
                catch(e:Exception){toast("خواندن مخاطب انتخاب‌شده ناموفق بود")}
                return
            }
            requestTakePersonPhoto -> {
                val bitmap=data?.extras?.get("data") as? Bitmap ?: run{toast("دوربین عکسی برنگرداند");return}
                try { activePersonPhotoData=saveCameraPhoto(bitmap);refreshActivePhoto() } catch(e:Exception){toast("ذخیره عکس ناموفق بود")}
                return
            }
            requestChoosePersonPhoto -> {
                val uri=data?.data ?: return
                try { activePersonPhotoData=savePersonPhoto(uri);refreshActivePhoto() } catch(e:Exception){toast("بارگذاری عکس ناموفق بود")}
                return
            }
            requestChooseTxDocument -> {
                val uri=data?.data ?: return
                val txId=pendingTxDocumentId ?: return
                try { val encoded=savePersonPhoto(uri);db.addTxDocument(txId,"پیوست ${db.txDocuments(txId).size+1}",encoded);toast("پیوست تراکنش ذخیره شد");val tx=db.transactions().firstOrNull{it.id==txId};if(tx!=null){if(tx.personId==null)showFinance()else personPage(tx.personId)} } catch(e:Exception){toast("ذخیره پیوست ناموفق بود: ${e.message ?: "خطا"}")}
                pendingTxDocumentId=null
                return
            }
        }
        val uri=data?.data ?: return
        when(requestCode){
            requestCreateBackup -> exportBackup(uri)
            requestRestoreBackup -> inspectBackup(uri)
        }
    }

    private val backupPreferenceNames=listOf("catalog_customization","money_display","people_list")
    private fun collectBackupSettings():JSONObject{
        val all=JSONObject()
        backupPreferenceNames.forEach{name->
            val obj=JSONObject();getSharedPreferences(name,Context.MODE_PRIVATE).all.forEach{(k,v)->when(v){is String->obj.put(k,JSONObject().put("type","string").put("value",v));is Boolean->obj.put(k,JSONObject().put("type","boolean").put("value",v));is Int->obj.put(k,JSONObject().put("type","int").put("value",v));is Long->obj.put(k,JSONObject().put("type","long").put("value",v));is Float->obj.put(k,JSONObject().put("type","float").put("value",v.toDouble()));is Set<*>->{val a=JSONArray();v.filterIsInstance<String>().forEach{a.put(it)};obj.put(k,JSONObject().put("type","string_set").put("value",a))};else->{}}};all.put(name,obj)
        };return all
    }
    private fun restoreBackupSettings(settings:JSONObject){
        backupPreferenceNames.forEach{name->val obj=settings.optJSONObject(name)?:return@forEach;val edit=getSharedPreferences(name,Context.MODE_PRIVATE).edit().clear();val keys=obj.keys();while(keys.hasNext()){val k=keys.next();val item=obj.optJSONObject(k)?:continue;when(item.optString("type")){"string"->edit.putString(k,item.optString("value"));"boolean"->edit.putBoolean(k,item.optBoolean("value"));"int"->edit.putInt(k,item.optInt("value"));"long"->edit.putLong(k,item.optLong("value"));"float"->edit.putFloat(k,item.optDouble("value").toFloat());"string_set"->{val a=item.optJSONArray("value")?:JSONArray();val set=(0 until a.length()).map{a.optString(it)}.toSet();edit.putStringSet(k,set)}}};if(!edit.commit())throw IllegalStateException("ذخیره تنظیمات بازیابی‌شده ناموفق بود")}
    }
    private fun exportBackup(uri:Uri){
        val temp=File(cacheDir,"backup_${System.currentTimeMillis()}.mzb")
        try{
            val type=pendingBackupType
            if(type!="settings") {db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use{};db.close()}
            val manifest=JSONObject().put("format","ModiriatZendegiBackup").put("format_version",1).put("app_version","0.19.0").put("database_version",if(type!="settings")11 else JSONObject.NULL).put("created_at",System.currentTimeMillis()).put("type",type).put("contains_settings",type!="data").put("contains_data",type!="settings")
            ZipOutputStream(FileOutputStream(temp)).use{zip->
                zip.putNextEntry(ZipEntry("manifest.json"));zip.write(manifest.toString().toByteArray(Charsets.UTF_8));zip.closeEntry()
                if(type!="settings") {val dbFile=getDatabasePath("ledger.db");if(!dbFile.exists())throw IllegalStateException("پایگاه داده پیدا نشد");zip.putNextEntry(ZipEntry("ledger.db"));FileInputStream(dbFile).use{it.copyTo(zip)};zip.closeEntry()}
                if(type!="data") {zip.putNextEntry(ZipEntry("settings.json"));zip.write(collectBackupSettings().toString().toByteArray(Charsets.UTF_8));zip.closeEntry()}
            }
            contentResolver.openOutputStream(uri,"w").use{out->if(out==null)throw IllegalStateException("فایل مقصد باز نشد");FileInputStream(temp).use{it.copyTo(out)};out.flush()}
            toast("پشتیبان ${when(type){"settings"->"تنظیمات";"data"->"داده‌ها";else->"کامل"}} ساخته شد")
        }catch(e:Exception){toast("ساخت پشتیبان ناموفق بود: ${e.message?:"خطا"}")}
        finally{temp.delete();try{db.close()}catch(_:Exception){};db=LedgerDb(this);showBackup()}
    }
    private fun inspectBackup(uri:Uri){
        val dir=File(cacheDir,"restore_${System.currentTimeMillis()}");dir.mkdirs()
        try{
            contentResolver.openInputStream(uri).use{input->if(input==null)throw IllegalArgumentException("فایل خوانده نشد");ZipInputStream(input).use{zip->var entry=zip.nextEntry;while(entry!=null){if(entry.name !in setOf("manifest.json","settings.json","ledger.db"))throw IllegalArgumentException("محتوای ناشناخته در فایل پشتیبان");if(!entry.isDirectory){val out=File(dir,entry.name);if(out.exists())throw IllegalArgumentException("ورودی تکراری در فایل پشتیبان");FileOutputStream(out).use{zip.copyTo(it)};if(out.length()>536870912L)throw IllegalArgumentException("اندازه فایل پشتیبان بیش از حد مجاز است")};zip.closeEntry();entry=zip.nextEntry}}}
            val manifestFile=File(dir,"manifest.json");if(!manifestFile.exists())throw IllegalArgumentException("قالب فایل پشتیبان شناخته نشد؛ نسخه‌های قدیمی SQLite در این مرحله بازیابی نمی‌شوند")
            val m=JSONObject(manifestFile.readText());if(m.optString("format")!="ModiriatZendegiBackup"||m.optInt("format_version")!=1)throw IllegalArgumentException("نسخه قالب پشتیبان پشتیبانی نمی‌شود")
            val hasSettings=m.optBoolean("contains_settings");val hasData=m.optBoolean("contains_data");if(!hasSettings&&!hasData)throw IllegalArgumentException("فایل هیچ محتوای قابل بازیابی ندارد")
            if(hasSettings&&!File(dir,"settings.json").exists())throw IllegalArgumentException("بخش تنظیمات ناقص است")
            if(hasSettings){val settingsCheck=JSONObject(File(dir,"settings.json").readText());if(backupPreferenceNames.any{!settingsCheck.has(it)})throw IllegalArgumentException("فهرست تنظیمات پشتیبان ناقص است")}
            if(hasData){val dbFile=File(dir,"ledger.db");if(!dbFile.exists())throw IllegalArgumentException("بخش اطلاعات ناقص است");val check=SQLiteDatabase.openDatabase(dbFile.absolutePath,null,SQLiteDatabase.OPEN_READONLY);try{var integrity="";check.rawQuery("PRAGMA integrity_check",null).use{c->if(c.moveToFirst())integrity=c.getString(0)};if(integrity!="ok")throw IllegalArgumentException("سلامت پایگاه داده تأیید نشد");val found=mutableSetOf<String>();check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'",null).use{c->while(c.moveToNext())found.add(c.getString(0))};if(!found.containsAll(setOf("people","transactions","finance_accounts","audit_log")))throw IllegalArgumentException("ساختار پایگاه داده ناقص است");if(check.version>11)throw IllegalArgumentException("پشتیبان متعلق به نسخه جدیدتری است")}finally{check.close()}}
            val desc=buildString{append("نوع فایل: ");append(when{hasSettings&&hasData->"تنظیمات و اطلاعات با هم";hasSettings->"فقط تنظیمات";else->"فقط اطلاعات و داده‌ها"});append("\nنسخه برنامه: ");append(m.optString("app_version"));append("\nتاریخ تهیه: ");append(Date(m.optLong("created_at")));append("\n\n") ;append(if(hasSettings)"تنظیمات برنامه بازیابی می‌شوند.\n" else "تنظیمات فعلی دست‌نخورده می‌مانند.\n");append(if(hasData)"پایگاه داده فعلی با داده‌های فایل جایگزین می‌شود.\n" else "اطلاعات و پایگاه داده فعلی دست‌نخورده می‌مانند.\n");append("پیش از جایگزینی، نسخه اضطراری از داده‌های فعلی نگهداری می‌شود.")}
            AlertDialog.Builder(this).setTitle("بررسی و تأیید بازیابی").setMessage(desc).setNegativeButton("انصراف"){_,_->dir.deleteRecursively()}.setPositiveButton("تأیید بازیابی"){_,_->restoreBackupPackage(dir,hasSettings,hasData)}.setOnCancelListener{dir.deleteRecursively()}.show()
        }catch(e:Exception){dir.deleteRecursively();toast("فایل پشتیبان قابل بازیابی نیست: ${e.message?:"خطا"}")}
    }
    private fun restoreBackupPackage(dir:File,hasSettings:Boolean,hasData:Boolean){
        val stamp=System.currentTimeMillis();var safety:File?=null
        try{
            if(hasData){
                val live=getDatabasePath("ledger.db");db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)",null).use{};db.close()
                safety=File(filesDir,"ledger_before_restore_$stamp.sqlite");if(live.exists())FileInputStream(live).use{input->FileOutputStream(safety!!).use{input.copyTo(it)}}
                File(live.path+"-wal").delete();File(live.path+"-shm").delete()
                val candidate=File(live.parentFile,"ledger_restore_candidate_$stamp.sqlite");FileInputStream(File(dir,"ledger.db")).use{input->FileOutputStream(candidate).use{input.copyTo(it)}}
                if(live.exists()&&!live.delete())throw IllegalStateException("آماده‌سازی پایگاه فعلی ناموفق بود");if(!candidate.renameTo(live))throw IllegalStateException("جایگزینی پایگاه داده ناموفق بود")
                db=LedgerDb(this);db.readableDatabase
            }
            if(hasSettings){val settings=JSONObject(File(dir,"settings.json").readText());restoreBackupSettings(settings)}
            toast("بازیابی بخش‌های انتخاب‌شده با موفقیت انجام شد");dir.deleteRecursively();showHome()
        }catch(e:Exception){
            try{db.close()}catch(_:Exception){}
            if(safety!=null&&safety!!.exists()){val live=getDatabasePath("ledger.db");File(live.path+"-wal").delete();File(live.path+"-shm").delete();if(live.exists())live.delete();FileInputStream(safety!!).use{input->FileOutputStream(live).use{input.copyTo(it)}}}
            db=LedgerDb(this);dir.deleteRecursively();toast("بازیابی ناموفق بود؛ نسخه اضطراری حفظ/بازگردانی شد: ${e.message?:"خطا"}");showBackup()
        }
    }

    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    @Deprecated("Deprecated in Android") override fun onBackPressed(){showHome()}
}

class PersonReminderReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel="person_reminders"
        if(android.os.Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel(channel,"یادآوری‌های اشخاص",NotificationManager.IMPORTANCE_DEFAULT))
        val title=intent.getStringExtra("reminder_title") ?: "یادآوری"
        val person=intent.getStringExtra("person_name") ?: ""
        val notification=if(android.os.Build.VERSION.SDK_INT>=26) Notification.Builder(context,channel) else Notification.Builder(context)
        if(android.os.Build.VERSION.SDK_INT<33 || context.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==android.content.pm.PackageManager.PERMISSION_GRANTED) manager.notify((intent.getLongExtra("reminder_id",System.currentTimeMillis())%Int.MAX_VALUE).toInt(),notification.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(person).setAutoCancel(true).build())
    }
}
